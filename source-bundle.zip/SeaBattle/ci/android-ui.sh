#!/usr/bin/env bash
set -eu
mkdir -p app/build/outputs/android-ui
collect() {
  timeout 15 adb logcat -d > app/build/outputs/android-ui/logcat.txt || true
  timeout 20 adb pull /sdcard/Download/seabattle-proofs app/build/outputs/android-ui/ || true
  cp /tmp/seabattle-ui-server.log app/build/outputs/android-ui/server.log || true
}
trap collect EXIT
adb logcat -c
bash gradlew :app:connectedDebugAndroidTest
