#!/usr/bin/env bash
set -eu
mkdir -p app/build/outputs/android-ui
collect() {
  adb logcat -d > app/build/outputs/android-ui/logcat.txt || true
  adb pull /sdcard/Download/seabattle-proofs app/build/outputs/android-ui/ || true
  cp /tmp/seabattle-ui-server.log app/build/outputs/android-ui/server.log || true
}
trap collect EXIT
bash gradlew :app:assembleDebug :app:assembleDebugAndroidTest
# Compare the reported entry path with the previous release on this same emulator.
if (
  set -e
  git show 3e48b13d8bca40eece3fd392589b114fa5fd32c5:source-bundle.zip > app/build/baseline.zip
  unzip -q app/build/baseline.zip -d app/build/baseline -x 'SeaBattle/.github/*'
  (cd app/build/baseline/SeaBattle && bash gradlew :app:assembleDebug)
  adb install -r app/build/baseline/SeaBattle/app/build/outputs/apk/debug/app-debug.apk
  adb install -r app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
  adb logcat -c
  adb shell am instrument -w -e class com.notebook.seabattle.EntrySmokeTest com.notebook.seabattle.test/androidx.test.runner.AndroidJUnitRunner > app/build/outputs/android-ui/baseline-instrumentation.txt
  adb logcat -d > app/build/outputs/android-ui/baseline-logcat.txt
) > app/build/outputs/android-ui/baseline-build.log 2>&1; then
  echo 'Baseline diagnostic completed; see instrumentation result.'
else
  echo 'Baseline diagnostic could not complete; current-version tests still required.' > app/build/outputs/android-ui/baseline-status.txt
fi
adb uninstall com.notebook.seabattle.test || true
adb uninstall com.notebook.seabattle || true
adb logcat -c
bash gradlew :app:connectedDebugAndroidTest
