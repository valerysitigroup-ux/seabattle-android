# v0.24 audio provenance

All three new effects are CC0 1.0. Source descriptions and licences checked on 2026-10-24.

* `hit_real_v24.wav`: Joseph SARDIN, [Explosion far Away #1](https://bigsoundbank.com/explosion-far-away-s1023.html). Actual outdoor recording of an agricultural gas cannon using Tascam DR-40 / Sennheiser ME66. A 1.8 s excerpt is used as the impact explosion.
* `flyby_real_v24.wav`: ReadeOnly, [rocket-whistle.wav](https://freesound.org/people/ReadeOnly/sounds/186933/). The author describes a short whistle from a fireworks recording. A 0.58 s excerpt is used on misses. It is an adapted real recorded whistle, **not** a field recording of a passing cannonball.
* `ship_sinking_v24.wav`: Thimras, [Ship sinking](https://opengameart.org/content/ship-sinking). A 3.2 s tail excerpt from a designed wooden-ship destruction/water soundscape. The author confirms that all source recordings were CC0 and describes editing in Reaper. This is a designed effect, **not** a recording of a real shipwreck.

Processing: mono downmix, 22050 Hz PCM16, DC removal, normalization, short fades. Exact excerpts, downloads and SHA256 hashes are in `v024-audio-manifest.json`. Run `build-v024.py` with NumPy and SoundFile to reproduce. Original download caches in `sources/` are excluded from source releases; the script retrieves them when absent.

Real gulls, real fireworks and the original synthesized sad pirate melody from v0.23 are retained. No film music or paid sound library is included. Listening on the user's physical phone has not been performed.
