# v0.24 audio provenance

All sources for these four effects are CC0 1.0. Source descriptions and licences checked on 2026-10-24.

* `hit_real_v24.wav`: mixed from two actual recordings: Joseph SARDIN, [Explosion far Away #1](https://bigsoundbank.com/explosion-far-away-s1023.html), an agricultural gas cannon using Tascam DR-40 / Sennheiser ME66; and utsuru, [Wood Crack 5](https://freesound.org/people/utsuru/sounds/183450/), cracking wood recorded with Zoom H4N. Both CC0. The 1.8 s impact combines the blast with prominent wooden cracking; it is a designed mix of recordings, not a documentary recording of a cannonball hitting a ship.
* `flyby_real_v24.wav`: ReadeOnly, [rocket-whistle.wav](https://freesound.org/people/ReadeOnly/sounds/186933/). The author describes a short whistle from a fireworks recording. A 0.58 s excerpt is used on misses. It is an adapted real recorded whistle, **not** a field recording of a passing cannonball.
* `ship_sinking_v24.wav`: Thimras, [Ship sinking](https://opengameart.org/content/ship-sinking). A 3.2 s tail excerpt from a designed wooden-ship destruction/water soundscape. The author confirms that all source recordings were CC0 and describes editing in Reaper. This is a designed effect, **not** a recording of a real shipwreck.
* `water_miss.wav`: Joseph SARDIN, [Splash, Big #3](https://bigsoundbank.com/splash-big-3-s1521.html), CC0. An actual large stone thrown into a water tank, recorded with SoundDevices MixPre-3 / Sennheiser ME66. A 2.4 s excerpt preserves the splash and bubbling water tail; it replaces the former synthesized short splash.

The firing cue gain is exactly one third of its former setting: 0.65 / 3 (about -9.54 dB amplitude gain). Impact, splash, whistle and sinking gains are separate. The sinking WAV is byte-for-byte unchanged after this volume/splash refinement: SHA256 `b7c055f12d0df94a74f2b1320c3f11cf0be3405a284705330e58fc4d1a779f2d`.

Processing: mono downmix, 22050 Hz PCM16, DC removal, normalization, short fades. Exact excerpts, downloads and SHA256 hashes are in `v024-audio-manifest.json`. Run `build-v024.py` with NumPy and SoundFile to reproduce. Original download caches in `sources/` are excluded from source releases; the script retrieves them when absent.

Real gulls, real fireworks and the original synthesized sad pirate melody from v0.23 are retained. No film music or paid sound library is included. Listening on the user's physical phone has not been performed.
