from pathlib import Path
import numpy as np
import soundfile as sf
import json,hashlib,urllib.request
base=Path(__file__).resolve().parent; source=base/'sources';source.mkdir(parents=True,exist_ok=True)
raw=base.parent/'app/src/main/res/raw'; rate=22050
logs=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):
 p=source/(name+'-original.mp3')
 if not p.exists():
  urls={'gulls':'https://cdn.freesound.org/previews/207/207130_2568776-hq.mp3','fireworks':'https://cdn.freesound.org/previews/455/455461_6886013-hq.mp3'}
  urllib.request.urlretrieve(urls[name],p)
 dest=p
 data,sr=sf.read(p,dtype='float32',always_2d=True);return data.mean(axis=1),sr,p,dest

def save(name,data,meta):
 data=np.asarray(data,dtype=np.float64);peak=float(np.max(np.abs(data)));gain=min(1,.80/max(peak,1e-8));data*=gain
 p=raw/name;sf.write(p,data,rate,subtype='PCM_16');logs.append(dict(file=name,seconds=len(data)/rate,sampleRate=rate,channels=1,peak=float(np.max(np.abs(data))),rms=float(np.sqrt(np.mean(data**2))),sha256=sha(p),**meta))

gulls,sr,orig,src=load('gulls');step=int(sr*.5);length=12
# Select an audible interval from the authentic bird recording, not a synthesized replacement.
starts=list(range(0,len(gulls)-sr*length,step));start=max(starts,key=lambda a:float(np.sqrt(np.mean(gulls[a:a+sr*length]**2))))
chunk=gulls[start:start+sr*length];t=np.arange(length*rate)/rate;record=np.interp(t,np.arange(len(chunk))/sr,chunk)
record*=.62/max(np.max(np.abs(record)),1e-8)
rng=np.random.default_rng(2301);noise=rng.normal(0,1,len(t));low=np.convolve(noise,np.ones(70)/70,mode='same');water=low*(.10+.04*np.sin(t*2*np.pi/3.5));fade=np.minimum(1,np.minimum(t/.10,(length-t)/.16))
save('real_sea_gulls_v23.wav',(record+water)*fade,dict(kind='Actual seagull field recording mixed with own low sea-noise layer',author='ahill86',title='SeaGulls.wav',page='https://freesound.org/people/ahill86/sounds/207130/',download='https://cdn.freesound.org/previews/207/207130_2568776-hq.mp3',license='CC0 1.0',sourceSha256=sha(orig),sourceClipStartSeconds=start/sr,sourceClipEndSeconds=start/sr+length,edits='HQ preview excerpt, stereo to mono, resample 22050, normalize, low synthesized wave layer, fade ends'))

fire,sr,orig,src=load('fireworks');block=int(sr*.05);peaks=np.array([np.sqrt(np.mean(fire[i:i+block]**2)) for i in range(0,len(fire)-block,block)]);peak=int(peaks.argmax())*block
start=max(0,min(peak-int(.13*sr),len(fire)-int(2.6*sr)));chunk=fire[start:start+int(2.6*sr)];t=np.arange(int(2.6*rate))/rate;out=np.interp(t,np.arange(len(chunk))/sr,chunk);out*=.78/max(np.max(np.abs(out)),1e-8);out*=np.minimum(1,np.minimum(t/.008,(2.6-t)/.2))
save('firework_real_v23.wav',out,dict(kind='Actual fireworks field recording',author='MilanKovanda',title='Fireworks in foreground',page='https://freesound.org/people/MilanKovanda/sounds/455461/',download='https://cdn.freesound.org/previews/455/455461_6886013-hq.mp3',license='CC0 1.0',sourceSha256=sha(orig),sourceClipStartSeconds=start/sr,sourceClipEndSeconds=start/sr+2.6,edits='HQ preview excerpt, stereo to mono, resample 22050, normalize and fade ends'))

# Original minor-key slow sea-chanty: reed melody, bowed low harmony and plucked bass.
t=np.arange(8*rate)/rate;music=np.zeros_like(t);notes=[62,65,64,62,57,60,58,57,55,57,53,50]
for i,note in enumerate(notes):
 q=t-i*.60;mask=(q>=0)&(q<.72);u=q[mask];f=440*2**((note-69)/12);phase=2*np.pi*f*(u+.0008*np.sin(2*np.pi*4.7*u));env=np.minimum(1,u/.06)*np.exp(-u*2.4)*np.minimum(1,(.72-u)/.12)
 reed=sum(np.sin(phase*h)/h**1.4 for h in range(1,7));music[mask]+=.19*reed*env
for i,note in enumerate([38,38,34,33]):
 q=t-i*1.8;mask=(q>=0)&(q<2.15);u=q[mask];f=440*2**((note-69)/12);env=np.minimum(1,u/.25)*np.exp(-u*.85)*np.minimum(1,(2.15-u)/.4)
 music[mask]+=.10*(np.sin(2*np.pi*f*u)+.3*np.sin(2*np.pi*f*2*u))*env
for i in range(12):
 q=t-i*.6;mask=(q>=0)&(q<.9);u=q[mask];f=73.416 if i<6 else 55.;music[mask]+=.075*np.sin(2*np.pi*f*u)*np.exp(-u*7)
# Short room reflections and a smooth farewell tail.
for d,g in [(int(.13*rate),.18),(int(.27*rate),.10)]:music[d:]+=music[:-d]*g
music*=np.minimum(1,np.minimum(t/.12,(8-t)/.6))
save('sad_pirate_v23.wav',music,dict(kind='Original synthesized slow minor pirate lament',license='Original project composition',edits='Own D-minor reed/bowed-string/plucked-bass synthesis, no existing film melody or third-party music'))
(base/'v023-audio-manifest.json').write_text(json.dumps(dict(files=logs),indent=2),encoding='utf8')
print(json.dumps([dict(file=x['file'],seconds=x['seconds'],rms=x['rms'],sourceStart=x.get('sourceClipStartSeconds')) for x in logs],indent=2))
