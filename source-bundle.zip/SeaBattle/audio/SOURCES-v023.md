# Audio sources v0.23

The runtime seagull loop now uses an actual bird recording. It does not use the synthesized gull calls from v0.22.

- **SeaGulls.wav**, ahill86, Freesound #207130. [Source and CC0 declaration](https://freesound.org/people/ahill86/sounds/207130/). The public HQ MP3 preview is used; the selected interval is 44–56 seconds. Converted to mono PCM16 at 22050 Hz, normalized, with fades and an original low sea-noise layer.
- **Fireworks in foreground**, MilanKovanda, Freesound #455461. [Source and CC0 declaration](https://freesound.org/people/MilanKovanda/sounds/455461/). The public HQ MP3 preview is used; an explosion interval is trimmed to 2.6 seconds, normalized and faded.
- **Sad pirate lament**, original project composition/synthesis: an eight-second slow minor-key melody with reed, bowed-low-string and plucked-bass timbres. It is not a film soundtrack or a recording of acoustic instruments.

Both recordings are published under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/). These credits are retained voluntarily. The exact source hashes, excerpts, edits, generated WAV hashes, peaks and RMS are recorded in `v023-audio-manifest.json`.

Reproduce with Python 3.12, NumPy and SoundFile (`python -m pip install numpy soundfile`; this delivery used SoundFile 0.14.0). Run `python audio/build-v023.py` from any directory. The script downloads the two public previews into the ignored `audio/sources/` cache if absent, then writes the WAVs and manifest. Source MP3s are not needed to compile or run the app and are omitted from the source bundle to keep it within GitHub's web-upload size limit. WAVs are included in the app sources.

`generate-v022.cjs` and its JSON are historical v0.22 synthesis provenance and are not the current runtime gull source.
