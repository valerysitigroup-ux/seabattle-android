"""Recorded CC0 effects; no API key or proprietary sound library is required."""
from pathlib import Path
import json, hashlib, urllib.request
import numpy as np
import soundfile as sf

base=Path(__file__).resolve().parent
cache=base/'sources'; cache.mkdir(exist_ok=True)
raw=base.parent/'app/src/main/res/raw'; rate=22050
entries=[]
sources={
 'explosion':dict(file='explosion-original.wav',url='https://bigsoundbank.com/UPLOAD/bwf-en/1023.wav',page='https://bigsoundbank.com/explosion-far-away-s1023.html',author='Joseph SARDIN',kind='Field recording of an agricultural gas cannon; used as a cannonball impact'),
 'whistle':dict(file='whistle-original.mp3',url='https://cdn.freesound.org/previews/186/186933_545448-hq.mp3',page='https://freesound.org/people/ReadeOnly/sounds/186933/',author='ReadeOnly',kind='Whistle excerpt from a fireworks recording; adapted as a passing cannonball, not a recording of a real cannonball'),
 'sinking':dict(file='sinking-original.ogg',url='https://opengameart.org/sites/default/files/ship_destroyed.ogg',page='https://opengameart.org/content/ship-sinking',author='Thimras',kind='Designed wooden-ship sinking soundscape assembled by its author from CC0 recordings; not a documentary recording of a shipwreck')
}

def effect(key,name,start,length,level):
 meta=sources[key]; p=cache/meta['file']
 if not p.exists(): urllib.request.urlretrieve(meta['url'],p)
 data,sr=sf.read(p,dtype='float32',always_2d=True); data=data.mean(axis=1)
 if start=='peak':
  # Place the onset before the strongest transient, preserving its recorded tail.
  start=max(0,min(float(np.argmax(np.abs(data)))/sr-.025,len(data)/sr-length))
 chunk=data[int(start*sr):int((start+length)*sr)]
 t=np.arange(round(length*rate))/rate
 out=np.interp(t,np.arange(len(chunk))/sr,chunk)
 out-=np.mean(out); out*=level/max(float(np.max(np.abs(out))),1e-8)
 out*=np.minimum(1,np.minimum(t/.005,(length-t)/.09))
 dest=raw/name; sf.write(dest,out,rate,subtype='PCM_16')
 entries.append(dict(**{**meta,'sourceFile':meta['file'],'file':name},license='CC0 1.0',sourceStartSeconds=start,seconds=length,sampleRate=rate,channels=1,decodedBytes=len(out)*2,peak=float(np.max(np.abs(out))),rms=float(np.sqrt(np.mean(out**2))),sourceSha256=hashlib.sha256(p.read_bytes()).hexdigest(),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),edits='Excerpt, mono downmix, resample to 22050 Hz, DC removal, normalize, short end fades'))

effect('explosion','hit_real_v24.wav','peak',1.8,.85)
effect('whistle','flyby_real_v24.wav','peak',.58,.75)
effect('sinking','ship_sinking_v24.wav',14.9,3.2,.80)
(base/'v024-audio-manifest.json').write_text(json.dumps(dict(files=entries),indent=2),encoding='utf8')
print(json.dumps(entries,indent=2))
