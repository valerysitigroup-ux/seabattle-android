"""Build a 20-second seamless sea bed from the existing game water sound, offline."""
from pathlib import Path
import hashlib,json,wave
import numpy as np

root=Path(__file__).resolve().parent.parent
raw=root/'app/src/main/res/raw'
source=raw/'sea_wash.wav'
with wave.open(str(source),'rb') as w:
    rate=w.getframerate()
    assert w.getnchannels()==1 and w.getsampwidth()==2
    data=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float64)/32768
count=rate*20
sea=np.zeros(count)
weights=np.zeros(count)
rng=np.random.default_rng(26024)
# Overlap differently stretched swells on a circular timeline. Smooth windows remove
# short-loop joins; circular placement keeps the end-to-start background transition smooth.
for start in np.arange(0,20,1.25):
    length=int(rate*rng.uniform(3.3,4.6))
    sample=np.interp(np.linspace(0,len(data)-1,length),np.arange(len(data)),data)
    window=np.sin(np.linspace(0,np.pi,length))**2
    indexes=(int(start*rate)+np.arange(length))%count
    sea[indexes]+=sample*window*rng.uniform(.85,1.15)
    weights[indexes]+=window
sea/=np.maximum(weights,.001)
sea-=sea.mean()
sea*=.50/max(np.max(np.abs(sea)),.001)
target=raw/'sea_ambient_v26.wav'
with wave.open(str(target),'wb') as w:
    w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate)
    w.writeframes(np.rint(sea*32767).astype('<i2').tobytes())
assert target.stat().st_size<1_000_000
manifest=dict(file=target.name,seconds=20,sample_rate=rate,channels=1,bits=16,
    source=source.name,description='Edited extension of the existing game sea wash, not a new field recording.',
    method='Deterministic circular overlap of smoothly stretched and windowed swells; no gulls.',
    sha256=hashlib.sha256(target.read_bytes()).hexdigest())
(root/'audio/v026-audio-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest))
