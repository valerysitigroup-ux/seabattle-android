const {randomBytes,randomInt}=require('node:crypto');
const {WebSocket}=require('ws');
const send=(ws,m)=>{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(m));};
function createLobby({rooms,state,closeRoom,inviteTtlMs=60000}) {
 const players=new Map(), invitations=new Map();
 const player=ws=>players.get(ws.lobbyId);
 const status=p=>p.ws.game?.code?'playing':p.invitation?'inviting':'available';
 function broadcast(){
  const roster=[...players.values()].map(p=>({id:p.id,name:p.name,status:status(p)}));
  for(const p of players.values())send(p.ws,{type:'presence',players:roster});
 }
 function finish(id,reason){
  const invitation=invitations.get(id);if(!invitation)return;
  clearTimeout(invitation.timer);invitations.delete(id);
  for(const pid of [invitation.from,invitation.to]){
   const p=players.get(pid);if(!p)continue;
   if(p.invitation===id)p.invitation=null;
   send(p.ws,{type:'invite_closed',id,reason});
  }
  broadcast();
 }
 function handle(ws,m){
  if(m.type==='hello'){
   const existing=player(ws);
   if(!existing&&players.size>=2000)throw Error('Сейчас много игроков. Попробуйте позже');
   if(existing&&(existing.invitation||ws.game.code))throw Error('Сначала завершите приглашение или партию');
   const id=existing?.id||randomBytes(8).toString('hex');
   const name=String(m.name||'').replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,24)||`Капитан ${id.slice(-4)}`;
   ws.lobbyId=id;players.set(id,{id,name,ws,invitation:null});
   send(ws,{type:'welcome',id,name,protocol:2});broadcast();return true;
  }
  if(!['presence','invite','answer','cancel_invite','leave'].includes(m.type))return false;
  const from=player(ws);if(!from)throw Error('Сначала войдите в список игроков');
  if(m.type==='presence'){broadcast();return true;}
  if(m.type==='leave'){
   if(ws.game.code)closeRoom(ws.game.code);
   else if(from.invitation)finish(from.invitation,'cancelled');
   broadcast();return true;
  }
  if(m.type==='invite'){
   const to=players.get(String(m.to));
   if(!to||to===from||to.ws.readyState!==WebSocket.OPEN||status(from)!=='available'||status(to)!=='available')throw Error('Игрок сейчас недоступен');
   const id=randomBytes(10).toString('hex');
   const invitation={id,from:from.id,to:to.id};
   invitation.timer=setTimeout(()=>finish(id,'expired'),inviteTtlMs);invitation.timer.unref();
   invitations.set(id,invitation);from.invitation=id;to.invitation=id;
   send(ws,{type:'invite_sent',id,to:{id:to.id,name:to.name}});
   send(to.ws,{type:'invitation',id,from:{id:from.id,name:from.name}});broadcast();return true;
  }
  const invitation=invitations.get(String(m.id));
  if(!invitation||![invitation.from,invitation.to].includes(from.id))throw Error('Приглашение уже недоступно');
  if(m.type==='cancel_invite'){finish(invitation.id,'cancelled');return true;}
  if(invitation.to!==from.id||typeof m.accept!=='boolean')throw Error('Ответить может только приглашённый игрок');
  if(!m.accept){finish(invitation.id,'declined');return true;}
  const a=players.get(invitation.from),b=players.get(invitation.to);
  if(!a||!b||a.ws.game.code||b.ws.game.code||rooms.size>=2000){finish(invitation.id,'unavailable');return true;}
  clearTimeout(invitation.timer);invitations.delete(invitation.id);a.invitation=null;b.invitation=null;
  let code;do{code=String(randomInt(100000,1000000));}while(rooms.has(code));
  const room={code,players:[{ws:a.ws,ships:null,shots:[]},{ws:b.ws,ships:null,shots:[]}],turn:0,finished:false};rooms.set(code,room);
  for(const [i,p] of [a,b].entries()){
   p.ws.game={code,idx:i};send(p.ws,{type:'arrange',room:code,opponent:{id:[b,a][i].id,name:[b,a][i].name}});
  }
  state(room);broadcast();return true;
 }
 function disconnected(ws){const p=player(ws);if(!p)return;players.delete(p.id);if(p.invitation)finish(p.invitation,'offline');broadcast();}
 function shutdown(){for(const v of invitations.values())clearTimeout(v.timer);invitations.clear();players.clear();}
 return {handle,broadcast,disconnected,shutdown};
}
module.exports={createLobby};
