// Server-authoritative fleets and shots. Rooms live only for this process.
const {WebSocketServer, WebSocket} = require('ws');
const {randomInt} = require('node:crypto');
const http = require('node:http');
const {valid} = require('./fleet');
const send = (ws, obj) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); };
function createServer({port = Number(process.env.PORT || 8080), host = process.env.HOST || '0.0.0.0'} = {}) {
 const httpServer=http.createServer((req,res)=> {
  res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
  res.end(JSON.stringify({service:'seabattle',status:'ok'}));
 });
 const wss = new WebSocketServer({server:httpServer,maxPayload:16384});
 const originalClose=wss.close.bind(wss);
 wss.close=callback=>originalClose(()=>httpServer.close(callback));
 const rooms = new Map();
 const waiting = new Set();
 function state(room) {
  room.players.forEach((p,i) => {
   if (!p) return;
   send(p.ws, {type:'state', room:room.code, player:i, ready:room.players.map(q => !!q?.ships),
    turn:room.turn, finished:room.finished, ownShots:p.shots, enemyShots:room.players[1-i]?.shots || []});
  });
 }
 function closeRoom(code) {
  const room = rooms.get(code);
  if (!room) return;
  rooms.delete(code); waiting.delete(code);
  for (const p of room.players) if (p) {
   send(p.ws, {type:'closed', message:'Соперник отключился. Создайте новую партию'});
   p.ws.close(1000, 'room closed');
  }
 }
 wss.on('connection', ws => {
  let code = null, idx = -1;
  ws.alive=true;
  ws.on('pong',()=>{ws.alive=true;});
  ws.on('error', () => { if (code) closeRoom(code); });
  ws.on('message', raw => {
   try {
    const m = JSON.parse(raw.toString());
    if (!m || typeof m !== 'object' || Array.isArray(m)) throw Error('Неверное сообщение');
    if(m.type==='match' && !code) {
     const found=[...waiting].map(c=>rooms.get(c)).find(r=>r && !r.finished && !r.players[1]);
     if(found) {
      found.players[1]={ws,ships:null,shots:[]};code=found.code;idx=1;waiting.delete(code);state(found);return;
     }
     if(rooms.size>=2000)throw Error('Сейчас много игроков. Попробуйте позже');
     let c;do{c=String(randomInt(100000,1000000));}while(rooms.has(c));
     rooms.set(c,{code:c,players:[{ws,ships:null,shots:[]},null],turn:0,finished:false});
     code=c;idx=0;waiting.add(c);state(rooms.get(c));return;
    }
    if (m.type === 'create' && !code) {
     if(rooms.size>=2000)throw Error('Сейчас много игроков. Попробуйте позже');
     let c; do { c = String(randomInt(100000,1000000)); } while (rooms.has(c));
     rooms.set(c, {code:c, players:[{ws,ships:null,shots:[]},null], turn:0, finished:false});
     code=c; idx=0; state(rooms.get(code)); return;
    }
    if (m.type === 'join' && !code) {
     const room = rooms.get(String(m.room));
     if (!room || room.players[1]) throw Error('Комната недоступна');
     room.players[1] = {ws,ships:null,shots:[]}; code=room.code; idx=1; waiting.delete(code); state(room); return;
    }
    const room = rooms.get(code);
    if (!room || room.players[idx]?.ws !== ws) throw Error('Сначала войдите в комнату');
    if (m.type === 'fleet') {
     if (room.players[idx].ships || room.finished || !valid(m.ships)) throw Error('Некорректный флот');
     room.players[idx].ships = m.ships; state(room); return;
    }
    if (m.type === 'shot') {
     if (room.finished || room.turn !== idx || room.players.some(p => !p?.ships)) throw Error('Сейчас не ваш ход');
     const {x,y} = m;
     if (!Number.isInteger(x) || !Number.isInteger(y) || x<0 || x>9 || y<0 || y>9) throw Error('Неверная клетка');
     const enemy = room.players[1-idx];
     if (enemy.shots.some(s => s.x===x && s.y===y)) throw Error('Повторный выстрел');
     const ship = enemy.ships.find(s => s.some(p => p[0]===x && p[1]===y));
     enemy.shots.push({x,y,hit:!!ship});
     const sunk = !!ship && ship.every(([a,b]) => enemy.shots.some(s => s.x===a && s.y===b));
     const won = enemy.ships.every(s => s.every(([a,b]) => enemy.shots.some(q => q.x===a && q.y===b)));
     send(ws, {type:'result', x,y,hit:!!ship,sunk,won});
     send(enemy.ws, {type:'incoming', x,y,hit:!!ship,sunk,won});
     if (won) room.finished=true; else if (!ship) room.turn=1-idx;
     state(room); return;
    }
    throw Error('Неизвестная команда');
   } catch (e) { send(ws, {type:'error', message:e.message}); }
  });
  ws.on('close', () => { if (code) closeRoom(code); });
 });
 const heartbeat=setInterval(()=> {
  for(const ws of wss.clients) {
   if(!ws.alive){ws.terminate();continue;}
   ws.alive=false;ws.ping();
  }
 },20000);
 heartbeat.unref();
 wss.on('close',()=>clearInterval(heartbeat));
 httpServer.listen(port,host);
 return wss;
}
if (require.main === module) {
 const server = createServer();
 server.on('listening', () => console.log('SeaBattle server on port ' + server.address().port));
}
module.exports = {valid, createServer};
