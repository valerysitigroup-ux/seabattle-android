const fleet = [4,3,3,2,2,2,1,1,1,1];
function valid(ships) {
 if (!Array.isArray(ships) || ships.length !== 10 || ships.some(s => !Array.isArray(s)) ||
     ships.map(s => s.length).sort((a,b) => b-a).join() !== fleet.join()) return false;
 const all = new Set();
 for (const s of ships) {
  if (s.some(p => !Array.isArray(p) || p.length !== 2 || !p.every(n => Number.isInteger(n) && n >= 0 && n < 10))) return false;
  const unique = new Set(s.map(p => p.join(',')));
  if (unique.size !== s.length) return false;
  if (s.length > 1 &&
      !(s.every(p => p[0] === s[0][0]) && Math.max(...s.map(p => p[1])) - Math.min(...s.map(p => p[1])) === s.length-1) &&
      !(s.every(p => p[1] === s[0][1]) && Math.max(...s.map(p => p[0])) - Math.min(...s.map(p => p[0])) === s.length-1)) return false;
  for (const [x,y] of s) {
   for (let dx=-1; dx<=1; dx++) for (let dy=-1; dy<=1; dy++) if (all.has(`${x+dx},${y+dy}`)) return false;
  }
  for (const p of s) all.add(p.join(','));
 }
 return true;
}
module.exports = {valid};
