const {test}=require('node:test');
const assert=require('node:assert/strict');
const {once}=require('node:events');
const WebSocket=require('ws');
const {createServer}=require('../index');
const {good}=require('./fixtures');

test('automatic matchmaking pairs two players, auto-ready fleets can start immediately',async t=>{
 const server=createServer({port:0,host:'127.0.0.1'});await once(server,'listening');
 const clients=[];t.after(async()=>{clients.forEach(c=>c.ws.terminate());await new Promise(r=>server.close(r));});
 async function player(){
  const ws=new WebSocket(`ws://127.0.0.1:${server.address().port}`);const queue=[];const waits=[];
  ws.on('message',raw=>{const m=JSON.parse(raw);const w=waits.shift();if(w)w(m);else queue.push(m);});
  await once(ws,'open');
  const c={ws,send:m=>ws.send(JSON.stringify(m)),next:()=>queue.length?Promise.resolve(queue.shift()):new Promise(r=>waits.push(r))};
  clients.push(c);return c;
 }
 const a=await player();a.send({type:'match'});const first=await a.next();
 assert.equal(first.player,0);assert.deepEqual(first.ready,[false,false]);
 a.send({type:'fleet',ships:good});assert.deepEqual((await a.next()).ready,[true,false]);
 const b=await player();b.send({type:'match'});
 const joinedA=await a.next();const joinedB=await b.next();
 assert.equal(joinedA.room,first.room);assert.equal(joinedB.room,first.room);assert.equal(joinedB.player,1);
 b.send({type:'fleet',ships:good});assert.deepEqual((await a.next()).ready,[true,true]);await b.next();
 a.send({type:'shot',x:0,y:0});assert.equal((await a.next()).hit,true);await a.next();await b.next();await b.next();
 const c=await player();c.send({type:'match'});assert.notEqual((await c.next()).room,first.room);
});
test('health endpoint is available for automatic hosting checks',async t=>{
 const s=createServer({port:0,host:'127.0.0.1'});await once(s,'listening');
 t.after(()=>new Promise(r=>s.close(r)));
 const response=await fetch(`http://127.0.0.1:${s.address().port}/health`);
 assert.equal(response.status,200);assert.equal((await response.json()).status,'ok');
});
