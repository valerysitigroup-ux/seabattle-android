const {test}=require('node:test');
const assert=require('node:assert/strict');
const {once}=require('node:events');
const WebSocket=require('ws');
const {createServer}=require('../index');
const {good}=require('./fixtures');
async function setup(t,options={}){
 const server=createServer({port:0,host:'127.0.0.1',...options});await once(server,'listening');const sockets=[];
 t.after(async()=>{sockets.forEach(s=>s.terminate());await new Promise(r=>server.close(r));});
 async function client(name){
  const ws=new WebSocket(`ws://127.0.0.1:${server.address().port}`);sockets.push(ws);const queue=[],waiters=[];
  ws.on('message',raw=>{const m=JSON.parse(raw),i=waiters.findIndex(w=>w.type===m.type&&w.predicate(m));if(i<0)queue.push(m);else{const [w]=waiters.splice(i,1);clearTimeout(w.timer);w.resolve(m);}});
  await once(ws,'open');
  const c={ws,send:m=>ws.send(JSON.stringify(m)),next(type,predicate=()=>true){const i=queue.findIndex(m=>m.type===type&&predicate(m));if(i>=0)return Promise.resolve(queue.splice(i,1)[0]);return new Promise((resolve,reject)=>{const w={type,predicate,resolve};w.timer=setTimeout(()=>{waiters.splice(waiters.indexOf(w),1);reject(Error('Timeout '+type));},4000);waiters.push(w);});}};
  c.send({type:'hello',name});const welcome=await c.next('welcome');c.id=welcome.id;c.name=welcome.name;return c;
 }
 const a=await client('Первый'),b=await client('Второй');return{a,b,client};
}
async function invite(a,b){a.send({type:'invite',to:b.id});const sent=await a.next('invite_sent');const received=await b.next('invitation');assert.equal(sent.id,received.id);return sent.id;}
async function accept(a,b){const id=await invite(a,b);b.send({type:'answer',id,accept:true});const ar=await a.next('arrange'),br=await b.next('arrange');assert.equal(ar.room,br.room);assert.equal(ar.opponent.id,b.id);assert.deepEqual((await a.next('state')).ready,[false,false]);await b.next('state');return ar.room;}
test('online roster contains only session id, display name and availability',async t=>{const {a,b}=await setup(t);const p=await a.next('presence',m=>m.players.length===2);assert.deepEqual(Object.keys(p.players[0]).sort(),['id','name','status']);assert.ok(p.players.every(q=>q.status==='available'));assert.ok(p.players.some(q=>q.id===b.id));});
test('invitation needs acceptance, then both players choose fleets before shots',async t=>{
 const {a,b}=await setup(t);await accept(a,b);a.send({type:'shot',x:0,y:0});assert.match((await a.next('error')).message,/ход/);
 a.send({type:'fleet',ships:good});const first=await a.next('state');assert.deepEqual(first.ready,[true,false]);assert.ok(!('ships' in first));await b.next('state');
 b.send({type:'fleet',ships:good});assert.deepEqual((await a.next('state')).ready,[true,true]);await b.next('state');
 a.send({type:'shot',x:0,y:0});assert.equal((await a.next('result')).hit,true);assert.equal((await b.next('incoming')).hit,true);
});
test('declining invitation returns both players to available',async t=>{const {a,b}=await setup(t);const id=await invite(a,b);b.send({type:'answer',id,accept:false});assert.equal((await a.next('invite_closed')).reason,'declined');await b.next('invite_closed');const roster=await a.next('presence',m=>m.players.every(p=>p.status==='available')&&m.players.length===2);assert.equal(roster.players.length,2);a.send({type:'shot',x:0,y:0});assert.match((await a.next('error')).message,/комнату/);});
test('only invited recipient can accept; self and busy invitations are rejected',async t=>{const {a,b,client}=await setup(t);a.send({type:'invite',to:a.id});await a.next('error');const id=await invite(a,b);a.send({type:'answer',id,accept:true});await a.next('error');const c=await client('Третий');c.send({type:'answer',id,accept:true});await c.next('error');c.send({type:'invite',to:b.id});await c.next('error');b.send({type:'answer',id,accept:true});await b.next('arrange');});
test('cancellation and expiry clear invitation without creating a match',async t=>{const {a,b}=await setup(t,{inviteTtlMs:120});let id=await invite(a,b);a.send({type:'cancel_invite',id});assert.equal((await b.next('invite_closed')).reason,'cancelled');await a.next('invite_closed');id=await invite(a,b);assert.equal((await b.next('invite_closed')).reason,'expired');assert.equal((await a.next('invite_closed')).id,id);});
test('disconnect cancels invitations and removes offline player from roster',async t=>{const {a,b}=await setup(t);await invite(a,b);b.ws.close();assert.equal((await a.next('invite_closed')).reason,'offline');const p=await a.next('presence',m=>m.players.length===1);assert.equal(p.players[0].id,a.id);});
test('leaving a friend match keeps the other player connected and able to invite again',async t=>{const {a,b}=await setup(t);await accept(a,b);a.send({type:'leave'});await a.next('closed');await b.next('closed');assert.equal(a.ws.readyState,WebSocket.OPEN);assert.equal(b.ws.readyState,WebSocket.OPEN);await invite(b,a);});
test('display names are bounded and duplicate names still have different session ids',async t=>{const {client}=await setup(t);const c=await client(' X'.repeat(40)+'\n'),d=await client(' X'.repeat(40)+'\n');assert.ok(c.name.length<=24);assert.equal(c.name,d.name);assert.notEqual(c.id,d.id);});
