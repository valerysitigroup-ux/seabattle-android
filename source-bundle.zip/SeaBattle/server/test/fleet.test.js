const {test} = require('node:test');
const assert = require('node:assert/strict');
const {valid} = require('../fleet');
const {good} = require('./fixtures');
test('valid standard manual fleet', () => assert.equal(valid(good), true));
test('reject diagonal touching', () => {
 const bad=structuredClone(good); bad[9]=[[5,6]]; assert.equal(valid(bad),false);
});
test('reject missing vessel', () => assert.equal(valid(good.slice(1)),false));
test('reject duplicate cells', () => {
 const bad=structuredClone(good); bad[0][3]=[2,0]; assert.equal(valid(bad),false);
});
test('reject out of bounds', () => {
 const bad=structuredClone(good); bad[9]=[[10,9]]; assert.equal(valid(bad),false);
});
test('reject malformed inputs without throwing', () => {
 for(const value of [null,{},[],Array(10).fill(null),[...good.slice(0,9),{}]]) assert.equal(valid(value),false);
});
test('reject bent and gapped vessels', () => {
 const bad=structuredClone(good); bad[0]=[[0,0],[1,0],[2,0],[2,1]]; assert.equal(valid(bad),false);
 bad[0]=[[0,0],[1,0],[2,0],[4,0]]; assert.equal(valid(bad),false);
});
test('reject overlap and side touching', () => {
 const bad=structuredClone(good); bad[9]=[[0,0]]; assert.equal(valid(bad),false);
 bad[9]=[[4,0]]; assert.equal(valid(bad),false);
});
test('reject non-integer coordinates and malformed cells', () => {
 const bad=structuredClone(good);
 for(const cell of [[1.5,9],['0',7],[0],null,[0,7,1]]) { bad[9]=[cell]; assert.equal(valid(bad),false); }
});
test('accept reversed vertical ships and reordered fleet', () => {
 const rotated=good.map(ship=>ship.map(([x,y])=>[y,x]).reverse()).reverse(); assert.equal(valid(rotated),true);
});
