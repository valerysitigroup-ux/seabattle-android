const {test} = require('node:test');
const assert = require('node:assert/strict');
const {once} = require('node:events');
const WebSocket = require('ws');
const {createServer} = require('../index');
const {good} = require('./fixtures');

async function session(t) {
 const server = createServer({port:0,host:'127.0.0.1'});
 await once(server,'listening');
 const sockets=[];
 t.after(async()=> { sockets.forEach(s=>s.terminate()); await new Promise(r=>server.close(r)); });
 async function client() {
  const ws = new WebSocket(`ws://127.0.0.1:${server.address().port}`);
  sockets.push(ws);
  const queue=[]; const waiters=[];
  ws.on('message',raw=> {
   const msg=JSON.parse(raw); const at=waiters.findIndex(w=>w.type===msg.type);
   if(at<0) queue.push(msg); else { const [w]=waiters.splice(at,1); clearTimeout(w.timer); w.resolve(msg); }
  });
  await once(ws,'open');
  return {
   ws, send:msg=>ws.send(JSON.stringify(msg)),
   next(type) {
    const at=queue.findIndex(m=>m.type===type);
    if(at>=0) return Promise.resolve(queue.splice(at,1)[0]);
    return new Promise((resolve,reject)=> {
     const waiter={type,resolve};
     waiter.timer=setTimeout(()=>{ const i=waiters.indexOf(waiter); if(i>=0)waiters.splice(i,1); reject(Error(`Timed out waiting for ${type}`)); },3000);
     waiters.push(waiter);
    });
   }
  };
 }
 const a=await client(); const b=await client();
 a.send({type:'create'}); const created=await a.next('state');
 assert.match(created.room,/^\d{6}$/);
 b.send({type:'join',room:created.room}); await a.next('state'); await b.next('state');
 return {a,b,client,room:created.room};
}
async function ready(a,b) {
 a.send({type:'fleet',ships:good}); await a.next('state'); await b.next('state');
 // Opponent uses a different, rotated manual layout.
 b.send({type:'fleet',ships:good.map(s=>s.map(([x,y])=>[y,x]))});
 const sa=await a.next('state'); const sb=await b.next('state');
 assert.deepEqual(sa.ready,[true,true]); assert.deepEqual(sb.ready,[true,true]);
 assert.ok(!('ships' in sa)); assert.ok(!('ships' in sb));
}
async function shot(attacker,defender,x,y) {
 attacker.send({type:'shot',x,y});
 const result=await attacker.next('result'); const incoming=await defender.next('incoming');
 const own=await attacker.next('state'); const other=await defender.next('state');
 assert.deepEqual(own.enemyShots,other.ownShots);
 assert.equal(result.hit,incoming.hit);
 return {result,state:own};
}
test('manual fleets, readiness, privacy, hit/sunk, miss and turn enforcement',async t=> {
 const {a,b,client,room}=await session(t);
 a.send({type:'shot',x:0,y:0}); assert.match((await a.next('error')).message,/ход/);
 const third=await client(); third.send({type:'join',room}); assert.match((await third.next('error')).message,/недоступна/);
 a.send({type:'fleet',ships:Array(10).fill(null)}); assert.match((await a.next('error')).message,/флот/);
 await ready(a,b);
 a.send({type:'fleet',ships:good}); assert.match((await a.next('error')).message,/флот/);
 b.send({type:'shot',x:0,y:0}); assert.match((await b.next('error')).message,/ход/);
 a.send({type:'shot',x:10,y:0}); assert.match((await a.next('error')).message,/клетка/);
 let r=await shot(a,b,0,0); assert.equal(r.result.hit,true); assert.equal(r.state.turn,0);
 // A1 is occupied in the manually submitted rotated fleet.
 assert.deepEqual(r.state.enemyShots,[{x:0,y:0,hit:true}]);
 a.send({type:'shot',x:0,y:0}); assert.match((await a.next('error')).message,/Повторный/);
 for(const y of [1,2,3]) r=await shot(a,b,0,y);
 assert.equal(r.result.sunk,true);
 r=await shot(a,b,9,9); assert.equal(r.result.hit,false); assert.equal(r.state.turn,1);
 r=await shot(b,a,9,9); assert.equal(r.state.turn,0);
});
test('full manual-fleet match reaches victory and blocks further shots',async t=> {
 const {a,b}=await session(t); await ready(a,b);
 let last;
 for(const [x,y] of good.flat().map(([x,y])=>[y,x])) last=await shot(a,b,x,y);
 assert.equal(last.result.won,true); assert.equal(last.result.sunk,true);
 assert.equal(last.state.finished,true); assert.equal(last.state.enemyShots.length,20);
 a.send({type:'shot',x:9,y:9}); assert.match((await a.next('error')).message,/ход/);
});
test('disconnect destroys room and notifies peer',async t=> {
 const {a,b,client,room}=await session(t);
 a.ws.close(); assert.match((await b.next('closed')).message,/отключился/);
 const c=await client(); c.send({type:'join',room}); assert.match((await c.next('error')).message,/недоступна/);
});
test('malformed JSON and null do not crash server',async t=> {
 const {a}=await session(t);
 a.ws.send('{'); await a.next('error');
 a.ws.send('null'); assert.match((await a.next('error')).message,/сообщение/);
 a.send({type:'unknown'}); assert.match((await a.next('error')).message,/Неизвестная/);
});
