# Морское оформление v0.17

Фон создан встроенным инструментом imagegen по запросу пользователя о комедийном мультяшном море в духе «Астерикса и Обеликса». Это новый фон, не кадр из фильма. Персонажи франшизы не использованы.

Файл: `app/src/main/res/drawable-nodpi/cartoon_sea_v17.png`.
Корабли, шахматные клетки, карандашные крестики, взрывы, моряки и пузыри нарисованы программно в OceanArt.kt, NotebookGrid.kt и SinkingScene.kt. Корабли имеют тени и цветовые градиенты; это объёмная мультяшная 2D-отрисовка, не трёхмерные модели.

## Точный запрос генерации фона

Use case: illustration-story. Asset type: final landscape background illustration for an Android naval battle game, not a UI mockup. Create a beautifully hand-drawn panoramic cartoon sea in the humorous Franco-Belgian animated adventure aesthetic of Asterix and Obelix: bold clean ink outlines, chunky charming rounded shapes, colorful cel-shaded turquoise Mediterranean water, rolling playful wave curls and white foam, warm sun, little distant rocky coastal islands and tiny coastal village silhouettes on the far horizon, soft puffy clouds, very cheerful playful cinematic animation mood. Landscape 16:9 composition. Horizon in top quarter. The central lower 75% should be mostly open turquoise water with varied but restrained wave patterns so two game boards can overlay legibly. Rich deep teal water at bottom and glowing turquoise near horizon, warm cream highlights. More detail at outer edges and top, less detail in central board area. No characters, no ships, no board, no grid, no lettering, no logos, no watermark. This is a polished actual background asset with painterly cel-shaded volume and bold ink outlines, no photorealism.


v0.18: корабли доработаны программно в OceanArt.kt: чёрные паруса с черепом и костями, красные флаги, пушки, объёмные палубы/борта. Пергамент меню рисуется в Parchment.kt, без внешних текстур. Число моряков равно числу палуб. Фон imagegen v0.17 не менялся.


v0.19: потопление перенесено на Canvas доски (SinkingScene.kt); пиратский флаг меню и праздник победы (PirateFinale.kt) нарисованы программно. Стиль корпуса сохранён: вид сбоку и немного сверху. Мелодия поражения — собственный синтез PCM16/22050 Гц; крик победы — Microsoft Zira Desktop, фраза Yo ho ho!, с пониженным тоном и хоровым наложением. Никакие новые внешние изображения не загружались.


v0.20: обожжённый морской пергамент рисуется программно в Parchment.kt, тёмная неровная кромка, волокна и роза ветров. Фрегаты в OceanArt.kt — собственная процедурная отрисовка палубы, древесины, пушек, кают, снастей и парусов с имитацией объёма и вида в три четверти; готовые внешние модели не использовались. water_miss.wav — собственный детерминированный синтез всплеска, PCM16 mono 22050 Гц, 0.72 с. Фон v0.17 и происхождение предыдущих звуков сохранены.
