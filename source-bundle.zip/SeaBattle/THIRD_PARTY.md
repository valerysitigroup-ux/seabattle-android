# Шрифт меню

Caveat Regular / Bold: Copyright 2014 The Caveat Project Authors.
SIL Open Font License 1.1. Полный текст включён в APK и исходники:
`app/src/main/assets/licenses/Caveat-OFL.txt`.

Официальный источник: https://github.com/googlefonts/caveat/tree/59745e818ef7973e11e70cb1358d0e902b56c5fc
Файлы `fonts/ttf/Caveat-Regular.ttf` и `fonts/ttf/Caveat-Bold.ttf` включены без изменения.
Поддержка кириллицы указана в метаданных Google Fonts:
https://github.com/google/fonts/blob/main/ofl/caveat/METADATA.pb
