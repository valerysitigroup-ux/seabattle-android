# Шрифт меню

Caveat Regular / Bold: Copyright 2014 The Caveat Project Authors.
SIL Open Font License 1.1. Полный текст включён в APK и исходники:
`app/src/main/assets/licenses/Caveat-OFL.txt`.

Официальный источник: https://github.com/googlefonts/caveat/tree/59745e818ef7973e11e70cb1358d0e902b56c5fc
Файлы `fonts/ttf/Caveat-Regular.ttf` и `fonts/ttf/Caveat-Bold.ttf` включены без изменения.
Поддержка кириллицы указана в метаданных Google Fonts:
https://github.com/google/fonts/blob/main/ofl/caveat/METADATA.pb

## v0.23 audio
Real seagull and firework recordings are CC0: ahill86, SeaGulls.wav, https://freesound.org/people/ahill86/sounds/207130/ ; MilanKovanda, Fireworks in foreground, https://freesound.org/people/MilanKovanda/sounds/455461/ . Exact excerpts, edits and hashes: audio/SOURCES-v023.md and audio/v023-audio-manifest.json. The sad pirate melody is an original synthesized composition.

## v0.24 audio
Four effects from CC0 sources: Joseph SARDIN (recorded cannon and large water splash), utsuru (recorded Wood Crack 5), ReadeOnly (recorded fireworks whistle), Thimras (designed wooden-ship sinking). See audio/SOURCES-v024.md and audio/v024-audio-manifest.json for sources, edits and hashes. The ship impact is a mix of the recorded blast and wood crack; the flyby is an adapted whistle recording, not an actual cannonball; sinking is a designed soundscape.

