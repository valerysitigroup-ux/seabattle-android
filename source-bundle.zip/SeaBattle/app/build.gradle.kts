plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.notebook.seabattle"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.notebook.seabattle"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "0.21"
        buildConfigField("String", "MATCH_SERVER_URL", "\"" + providers.gradleProperty("matchServerUrl").orElse(providers.environmentVariable("MATCH_SERVER_URL")).orElse("").get().also { require(it.isEmpty() || it.matches(Regex("wss://[A-Za-z0-9./:_-]+"))) } + "\"")
        buildConfigField("String", "SERVER_DIRECTORY", "\"https://raw.githubusercontent.com/valerysitigroup-ux/seabattle-android/main/server-config.json\"")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.10.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

