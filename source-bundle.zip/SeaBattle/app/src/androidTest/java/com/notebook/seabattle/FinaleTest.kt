package com.notebook.seabattle

import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.*
import org.junit.Assert.*

class FinaleTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun screen(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(15_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        prepareFullScreenProof(rule.activity)
    }
    private fun wrecked():BattleView {
        val board=Board.random();board.ships.flatMap {it.cells}.forEach {board.shoot(it)}
        return board.battleView(true)
    }
    @Test fun victoryCelebratesThenReturnsHomeOnce() {
        var returned=0
        val enemy=wrecked()
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПОБЕДА","Победа!",Board.random().battleView(true),enemy,false,{},onShot={},onMatchFinished={returned++})}}
        rule.mainClock.advanceTimeBy(4100)
        rule.onNodeWithTag("pirate-victory").assertIsDisplayed();rule.onNodeWithText("Victory").assertIsDisplayed()
        rule.mainClock.advanceTimeBy(1800);proof("pirate-victory-hats-cannons-fireworks")
        rule.onNodeWithTag("home-flag").assertIsDisplayed()
        rule.mainClock.advanceTimeBy(12000)
        rule.runOnIdle {assertEquals("Victory remains for fifteen seconds",0,returned)}
        rule.mainClock.advanceTimeBy(700)
        rule.runOnIdle {assertEquals(1,returned)}
    }
    @Test fun defeatShowsSinkingShipAndSadLifeboatThenReturnsHomeOnce() {
        var returned=0
        val own=wrecked()
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПОРАЖЕНИЕ","Флот потоплен",own,BattleView(),false,{},onShot={},onMatchFinished={returned++})}}
        rule.mainClock.advanceTimeBy(4100)
        rule.onNodeWithTag("match-finale").assertIsDisplayed();rule.onNodeWithText("Флот потоплен…").assertIsDisplayed()
        rule.onNodeWithTag("pirate-victory").assertDoesNotExist()
        rule.onNodeWithTag("pirate-defeat").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Подбитый корабль тонет. Грустные моряки сидят в лодке, опустив головы."))
        rule.mainClock.advanceTimeByFrame();proof("sad-defeat-ending")
        val early=rule.onNodeWithTag("defeat-submersion").fetchSemanticsNode().config[SemanticsProperties.StateDescription].removeSuffix("%").toInt()
        rule.mainClock.advanceTimeBy(4000)
        rule.runOnIdle {assertEquals("Defeat remains visible while ship sinks",0,returned)}
        val late=rule.onNodeWithTag("defeat-submersion").fetchSemanticsNode().config[SemanticsProperties.StateDescription].removeSuffix("%").toInt()
        assertTrue(early<20&&late>50)
        rule.mainClock.advanceTimeByFrame();proof("sad-defeat-submerged")
        rule.mainClock.advanceTimeBy(3600)
        rule.runOnIdle {assertEquals(1,returned)}
    }
    @Test fun endingAudioResourcesDecodeOnAndroid() {
        for((id,duration) in listOf(R.raw.pirate_victory to 1500..3500,R.raw.sad_pirate_v23 to 7500..8500,R.raw.water_miss to 2350..2450,R.raw.real_sea_gulls_v23 to 11000..13000,R.raw.firework_real_v23 to 2300..2900,R.raw.cannon_launch to 400..900,R.raw.hit_real_v24 to 1750..1850,R.raw.ship_sinking_v24 to 3150..3250)) {
            val player=MediaPlayer.create(rule.activity,id)
            assertNotNull(player)
            try {assertTrue(player.duration in duration)}finally{player.release()}
        }
    }
    @Test fun pirateHomeFlagLeavesFinaleOnce() {
        var returned=0
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {MatchFinale(MatchOutcome.WIN){returned++}}}
        rule.mainClock.advanceTimeBy(4100)
        rule.onNodeWithContentDescription("Главное меню").performClick()
        rule.runOnIdle {assertEquals(1,returned)}
        rule.mainClock.advanceTimeBy(20000)
        rule.runOnIdle {assertEquals("No delayed second navigation after the home flag",1,returned)}
    }
    @Test fun piratesLiftHatsWithTheirHandsAndReleaseThemIntoFlight() {
        var progress by mutableFloatStateOf(.15f/15)
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {RichPirateFinale(MatchOutcome.WIN,progress)}}
        rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("pirate-hand-throws").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Шляпа в руке"))
        proof("victory-hat-held")
        rule.runOnIdle {progress=.70f/15};rule.mainClock.advanceTimeBy(64);proof("victory-hat-lift")
        rule.runOnIdle {progress=1.20f/15};rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("pirate-hand-throws").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Шляпа отпущена рукой"))
        proof("victory-hat-release")
    }
}
