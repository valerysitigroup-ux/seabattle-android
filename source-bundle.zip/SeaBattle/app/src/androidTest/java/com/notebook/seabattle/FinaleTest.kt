package com.notebook.seabattle

import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.*
import org.junit.Assert.*

class FinaleTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun screen(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(5_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        prepareFullScreenProof(rule.activity)
    }
    private fun wrecked():BattleView {
        val board=Board.random();board.ships.flatMap {it.cells}.forEach {board.shoot(it)}
        return board.battleView(true)
    }
    @Test fun victoryCelebratesThenReturnsHomeOnce() {
        var returned=0
        val enemy=wrecked()
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПОБЕДА","Победа!",Board.random().battleView(true),enemy,false,{},onShot={},onMatchFinished={returned++})}}
        rule.mainClock.advanceTimeBy(4100)
        rule.onNodeWithTag("pirate-victory").assertIsDisplayed();rule.onNodeWithText("ЙО-ХО-ХО! ПОБЕДА!").assertIsDisplayed()
        rule.onRoot().captureToImage();proof("pirate-victory-hats-cannons-fireworks")
        rule.onNodeWithTag("home-flag").assertIsDisplayed()
        rule.mainClock.advanceTimeBy(14000)
        rule.runOnIdle {assertEquals("Victory remains for fifteen seconds",0,returned)}
        rule.mainClock.advanceTimeBy(700)
        rule.runOnIdle {assertEquals(1,returned)}
    }
    @Test fun defeatShowsShortEndingAndReturnsHomeOnce() {
        var returned=0
        val own=wrecked()
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПОРАЖЕНИЕ","Флот потоплен",own,BattleView(),false,{},onShot={},onMatchFinished={returned++})}}
        rule.mainClock.advanceTimeBy(4100)
        rule.onNodeWithTag("match-finale").assertIsDisplayed();rule.onNodeWithText("Флот потоплен…").assertIsDisplayed()
        rule.onNodeWithTag("pirate-victory").assertDoesNotExist()
        rule.onRoot().captureToImage();proof("sad-defeat-ending")
        rule.mainClock.advanceTimeBy(3300)
        rule.runOnIdle {assertEquals(1,returned)}
    }
    @Test fun endingAudioResourcesDecodeOnAndroid() {
        for((id,duration) in listOf(R.raw.pirate_victory to 1500..3500,R.raw.sad_defeat to 1500..3500,R.raw.water_miss to 500..1000)) {
            val player=MediaPlayer.create(rule.activity,id)
            assertNotNull(player)
            try {assertTrue(player.duration in duration)}finally{player.release()}
        }
    }
    @Test fun pirateHomeFlagLeavesFinaleOnce() {
        var returned=0
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {MatchFinale(MatchOutcome.WIN){returned++}}}
        rule.mainClock.advanceTimeBy(4100)
        rule.onNodeWithContentDescription("Главное меню").performClick()
        rule.runOnIdle {assertEquals(1,returned)}
        rule.mainClock.advanceTimeBy(20000)
        rule.runOnIdle {assertEquals("No delayed second navigation after the home flag",1,returned)}
    }
}
