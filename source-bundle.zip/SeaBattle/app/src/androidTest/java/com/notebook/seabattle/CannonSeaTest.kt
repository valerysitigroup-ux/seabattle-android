package com.notebook.seabattle

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import org.junit.*
import org.junit.Assert.*
import kotlin.random.Random

class CannonSeaTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun landscape(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(15_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        rule.waitForIdle();prepareFullScreenProof(rule.activity)
    }
    @Test fun cannonFliesBeforeHitAndMissAppearsOnlyAfterArrival() {
        val own=Board.random(Random(41)).battleView(true)
        var enemy by mutableStateOf(BattleView())
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ваш ход",own,enemy,true,{},onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {enemy=BattleView(shots=mapOf(Cell(4,4) to true))}
        rule.mainClock.advanceTimeBy(240)
        rule.onNodeWithTag("cannon-flight").assertIsDisplayed().assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Ваш выстрел. Источник скрыт. Цель Д5. Попадание"))
        rule.onNodeWithTag("enemy-turn-glow").assertDoesNotExist()
        rule.onNode(hasContentDescription("Д5, вода") and hasAnyAncestor(hasTestTag("enemy-board"))).assertExists()
        rule.mainClock.advanceTimeByFrame();proof("cannon-outgoing-flight")
        rule.mainClock.advanceTimeBy(600)
        rule.onNodeWithTag("cannon-flight").assertDoesNotExist()
        rule.onNodeWithTag("enemy-turn-glow").assertExists()
        rule.onNodeWithContentDescription("Д5, попадание").assertExists()
        rule.runOnIdle {enemy=enemy.copy(shots=enemy.shots+(Cell(8,7) to false))}
        rule.mainClock.advanceTimeBy(240)
        rule.onNodeWithTag("cannon-flight").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Ваш выстрел. Источник скрыт. Цель И8. Промах"))
        rule.onNodeWithContentDescription("И8, мимо").assertDoesNotExist()
        rule.mainClock.advanceTimeBy(600)
        rule.onNodeWithContentDescription("И8, мимо").assertExists()
        rule.onNodeWithTag("drawing-cross").assertExists()
        rule.mainClock.advanceTimeByFrame();proof("cannon-miss-water-cross")
    }
    @Test fun incomingFlightKeepsOwnShipUntilImpactThenSinksItOnBoard() {
        val ship=setOf(Cell(4,4))
        var own by mutableStateOf(BattleView(listOf(ship)))
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Соперник стреляет",own,BattleView(),false,{},onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {own=own.copy(shots=mapOf(Cell(4,4) to true),sunk=listOf(ship))}
        rule.mainClock.advanceTimeBy(240)
        rule.onNodeWithTag("cannon-flight").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Выстрел соперника. Источник скрыт. Цель Д5. Попадание"))
        rule.onNodeWithContentDescription("Д5, корабль").assertExists()
        rule.onNodeWithTag("inline-sinking").assertDoesNotExist()
        rule.mainClock.advanceTimeByFrame();proof("cannon-incoming-flight")
        rule.mainClock.advanceTimeBy(700)
        rule.onNodeWithTag("inline-sinking").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Палуб: 1. Моряков: 1"))
        rule.onNodeWithContentDescription("Д5, потопленный корабль").assertExists()
    }
    @Test fun oceanMovesUnderStableGridAndCellCoordinates() {
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {Box(Modifier.size(300.dp)){NotebookGrid(emptyList(),emptyMap(),false){}}}}
        rule.mainClock.advanceTimeBy(64)
        val before=rule.onNodeWithTag("moving-sea").captureToImage().toPixelMap()
        val cellBefore=rule.onNodeWithContentDescription("Д5, вода").fetchSemanticsNode().boundsInRoot
        rule.mainClock.advanceTimeBy(1600)
        val after=rule.onNodeWithTag("moving-sea").captureToImage().toPixelMap()
        var changed=0
        for(y in 1 until before.height step 3)for(x in 1 until before.width step 3)if(before[x,y]!=after[x,y])changed++
        assertTrue("The water must visibly move",changed>30)
        assertEquals(cellBefore,rule.onNodeWithContentDescription("Д5, вода").fetchSemanticsNode().boundsInRoot)
        rule.mainClock.advanceTimeByFrame();proof("living-sea-grid")
    }
    @Test fun quietSeaStopsOnMuteAndBackgroundAndResumesOnReturn() {
        val audio=GameAudio(rule.activity)
        try {
            rule.runOnUiThread {audio.startAmbience()}
            rule.waitUntil(10_000){audio.ambientPlaying}
            rule.runOnUiThread {audio.enabled=false};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.enabled=true};rule.waitUntil(5_000){audio.ambientPlaying}
            rule.runOnUiThread {audio.pause()};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.resume()};rule.waitUntil(5_000){audio.ambientPlaying}
            rule.runOnUiThread {audio.stopAmbience()};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.startAmbience()};rule.waitUntil(5_000){audio.ambientPlaying}
        }finally{rule.runOnUiThread {audio.release()}}
        assertFalse(audio.ambientPlaying)
    }
    @Test fun settledWreckRemainsOnSeabedAndItsHaloStaysClosed() {
        val ship=(3..6).map {Cell(it,4)}.toSet()
        var view by mutableStateOf(BattleView(listOf(ship)))
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ваш ход",BattleView(),view,true,{},onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {view=view.copy(shots=ship.associateWith {true},sunk=listOf(ship))}
        rule.mainClock.advanceTimeBy(6500)
        rule.onNodeWithTag("inline-sinking").assertDoesNotExist()
        rule.onNodeWithTag("seabed-wrecks").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"На дне: 1"))
        rule.onNodeWithContentDescription("Д5, потопленный корабль").assertExists()
        rule.onNodeWithContentDescription("В4, вокруг потопленного корабля, закрыто").assertIsNotEnabled()
        rule.mainClock.advanceTimeByFrame();proof("seabed-wreck-permanent")
    }
    @Test fun gullTogglePersistsWithoutMutingSeaAndOtherSounds() {
        val audio=GameAudio(rule.activity);val oldEnabled=audio.enabled;val oldGulls=audio.gullsEnabled
        try {
            rule.runOnUiThread {audio.enabled=true;audio.setGulls(true);audio.startAmbience()}
            rule.waitUntil(10_000){audio.ambientPlaying&&audio.gullsPlaying}
            rule.setContent {CompositionLocalProvider(LocalGameAudio provides audio){NotebookTheme {Parchment(Modifier.fillMaxSize()){Column{SoundButton()}}}}}
            rule.onNodeWithTag("gull-sound").performClick()
            assertFalse(audio.gullsPlaying);assertTrue(audio.ambientPlaying);assertTrue(audio.enabled)
            rule.onNodeWithText("Чайки: выкл").assertIsDisplayed();proof("sound-gulls-disabled")
            val reopened=GameAudio(rule.activity)
            try{assertFalse("The gull preference survives a new audio instance",reopened.gullsEnabled)}finally{rule.runOnUiThread {reopened.release()}}
            rule.runOnUiThread {audio.pause()};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.resume()};rule.waitUntil(5_000){audio.ambientPlaying};assertFalse(audio.gullsPlaying)
            rule.onNodeWithTag("gull-sound").performClick();rule.waitUntil(5_000){audio.gullsPlaying}
        }finally{rule.runOnUiThread {audio.enabled=oldEnabled;audio.setGulls(oldGulls);audio.release()}}
    }
    @Test fun everySoundHasAnIndependentSliderAndPersistedLevel() {
        val audio=GameAudio(rule.activity);val previous=GameSound.entries.associateWith {audio.level(it)}
        try {
            rule.setContent {CompositionLocalProvider(LocalGameAudio provides audio){NotebookTheme {SoundSettings{}}}}
            GameSound.entries.forEachIndexed {index,sound->
                val value=(index+1)/10f
                rule.onNodeWithTag("sound-level-${sound.key}").performScrollTo().performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.SetProgress){it(value)}
                assertEquals(value,audio.level(sound),.001f)
            }
            proof("sound-levels-bottom")
            rule.onNodeWithTag("sound-level-sea").performScrollTo();proof("sound-levels-top")
            val reopened=GameAudio(rule.activity)
            try {GameSound.entries.forEachIndexed {index,sound->assertEquals((index+1)/10f,reopened.level(sound),.001f)}}
            finally{rule.runOnUiThread {reopened.release()}}
        } finally {rule.runOnUiThread {previous.forEach {(sound,value)->audio.updateLevel(sound,value)};audio.release()}}
    }
    @Test fun activeFrameChangesSidesAndPublicFleetTallyDimsOnlySunkShips() {
        var turn by mutableStateOf(BattleTurn.PLAYER)
        var enemy by mutableStateOf(BattleView())
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ход соперника",Board.random().battleView(true),enemy,turn==BattleTurn.PLAYER,{},activeTurn=turn,onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("enemy-turn-glow").assertExists();rule.onNodeWithTag("own-turn-glow").assertDoesNotExist()
        val own=rule.onNodeWithTag("own-board").fetchSemanticsNode().boundsInRoot
        val right=rule.onNodeWithTag("enemy-board").fetchSemanticsNode().boundsInRoot
        val panel=rule.onNodeWithTag("enemy-fleet-panel").fetchSemanticsNode().boundsInRoot
        assertCellSpacing(own,right,rule.onRoot().fetchSemanticsNode().boundsInRoot);assertTrue(panel.left>right.right)
        proof("player-turn-frame-and-fleet")
        rule.runOnIdle {turn=BattleTurn.OPPONENT};rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("enemy-turn-glow").assertDoesNotExist();rule.onNodeWithTag("own-turn-glow").assertDoesNotExist()
        proof("opponent-turn-frame-and-fleet")
        val ship=(3..5).map {Cell(it,4)}.toSet()
        rule.runOnIdle {enemy=BattleView(shots=mapOf(ship.first() to true))};rule.mainClock.advanceTimeBy(800)
        rule.onNodeWithTag("enemy-fleet-panel").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Осталось кораблей: 10"))
        rule.onNodeWithTag("enemy-remaining").assertDoesNotExist()
        rule.runOnIdle {enemy=BattleView(listOf(ship),ship.associateWith {true},listOf(ship))}
        rule.mainClock.advanceTimeBy(4500)
        rule.onNodeWithTag("enemy-fleet-panel").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Осталось кораблей: 9"))
        rule.onNodeWithTag("enemy-ship-3-0").assertDoesNotExist()
        rule.onNodeWithTag("enemy-ship-3-1").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"В бою"))
        rule.onAllNodes(hasText("Осталось") and hasAnyAncestor(hasTestTag("enemy-fleet-panel"))).assertCountEquals(1)
        rule.onAllNodes(hasAnyAncestor(hasTestTag("enemy-fleet-panel")) and hasText("×",substring=true)).assertCountEquals(0)
        proof("enemy-fleet-after-sinking")
    }
}


