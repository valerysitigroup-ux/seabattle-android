package com.notebook.seabattle

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import org.junit.*
import org.junit.Assert.*
import kotlin.random.Random

class CannonSeaTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun landscape(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(15_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        rule.waitForIdle();prepareFullScreenProof(rule.activity)
    }
    @Test fun cannonFliesBeforeHitAndMissAppearsOnlyAfterArrival() {
        val own=Board.random(Random(41)).battleView(true)
        var enemy by mutableStateOf(BattleView())
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ваш ход",own,enemy,true,{},onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {enemy=BattleView(shots=mapOf(Cell(4,4) to true))}
        rule.mainClock.advanceTimeBy(240)
        rule.onNodeWithTag("cannon-flight").assertIsDisplayed().assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Ваш выстрел. Источник скрыт. Цель Д5. Попадание"))
        rule.onNode(hasContentDescription("Д5, вода") and hasAnyAncestor(hasTestTag("enemy-board"))).assertExists()
        rule.mainClock.advanceTimeByFrame();proof("cannon-outgoing-flight")
        rule.mainClock.advanceTimeBy(600)
        rule.onNodeWithTag("cannon-flight").assertDoesNotExist()
        rule.onNodeWithContentDescription("Д5, попадание").assertExists()
        rule.runOnIdle {enemy=enemy.copy(shots=enemy.shots+(Cell(8,7) to false))}
        rule.mainClock.advanceTimeBy(240)
        rule.onNodeWithTag("cannon-flight").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Ваш выстрел. Источник скрыт. Цель И8. Промах"))
        rule.onNodeWithContentDescription("И8, мимо").assertDoesNotExist()
        rule.mainClock.advanceTimeBy(600)
        rule.onNodeWithContentDescription("И8, мимо").assertExists()
        rule.onNodeWithTag("drawing-cross").assertExists()
        rule.mainClock.advanceTimeByFrame();proof("cannon-miss-water-cross")
    }
    @Test fun incomingFlightKeepsOwnShipUntilImpactThenSinksItOnBoard() {
        val ship=setOf(Cell(4,4))
        var own by mutableStateOf(BattleView(listOf(ship)))
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Соперник стреляет",own,BattleView(),false,{},onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {own=own.copy(shots=mapOf(Cell(4,4) to true),sunk=listOf(ship))}
        rule.mainClock.advanceTimeBy(240)
        rule.onNodeWithTag("cannon-flight").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Выстрел соперника. Источник скрыт. Цель Д5. Попадание"))
        rule.onNodeWithContentDescription("Д5, корабль").assertExists()
        rule.onNodeWithTag("inline-sinking").assertDoesNotExist()
        rule.mainClock.advanceTimeByFrame();proof("cannon-incoming-flight")
        rule.mainClock.advanceTimeBy(700)
        rule.onNodeWithTag("inline-sinking").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Палуб: 1. Моряков: 1"))
        rule.onNodeWithContentDescription("Д5, потопленный корабль").assertExists()
    }
    @Test fun oceanMovesUnderStableGridAndCellCoordinates() {
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {Box(Modifier.size(300.dp)){NotebookGrid(emptyList(),emptyMap(),false){}}}}
        rule.mainClock.advanceTimeBy(64)
        val before=rule.onNodeWithTag("moving-sea").captureToImage().toPixelMap()
        val cellBefore=rule.onNodeWithContentDescription("Д5, вода").fetchSemanticsNode().boundsInRoot
        rule.mainClock.advanceTimeBy(1600)
        val after=rule.onNodeWithTag("moving-sea").captureToImage().toPixelMap()
        var changed=0
        for(y in 1 until before.height step 3)for(x in 1 until before.width step 3)if(before[x,y]!=after[x,y])changed++
        assertTrue("The water must visibly move",changed>30)
        assertEquals(cellBefore,rule.onNodeWithContentDescription("Д5, вода").fetchSemanticsNode().boundsInRoot)
        rule.mainClock.advanceTimeByFrame();proof("living-sea-grid")
    }
    @Test fun quietSeaStopsOnMuteAndBackgroundAndResumesOnReturn() {
        val audio=GameAudio(rule.activity)
        try {
            rule.runOnUiThread {audio.startAmbience()}
            rule.waitUntil(10_000){audio.ambientPlaying}
            rule.runOnUiThread {audio.enabled=false};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.enabled=true};rule.waitUntil(5_000){audio.ambientPlaying}
            rule.runOnUiThread {audio.pause()};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.resume()};rule.waitUntil(5_000){audio.ambientPlaying}
            rule.runOnUiThread {audio.stopAmbience()};assertFalse(audio.ambientPlaying)
            rule.runOnUiThread {audio.startAmbience()};rule.waitUntil(5_000){audio.ambientPlaying}
        }finally{rule.runOnUiThread {audio.release()}}
        assertFalse(audio.ambientPlaying)
    }
    @Test fun settledWreckRemainsOnSeabedAndItsHaloStaysClosed() {
        val ship=(3..6).map {Cell(it,4)}.toSet()
        var view by mutableStateOf(BattleView(listOf(ship)))
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ваш ход",BattleView(),view,true,{},onShot={})}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {view=view.copy(shots=ship.associateWith {true},sunk=listOf(ship))}
        rule.mainClock.advanceTimeBy(6500)
        rule.onNodeWithTag("inline-sinking").assertDoesNotExist()
        rule.onNodeWithTag("seabed-wrecks").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"На дне: 1"))
        rule.onNodeWithContentDescription("Д5, потопленный корабль").assertExists()
        rule.onNodeWithContentDescription("В4, вокруг потопленного корабля, закрыто").assertIsNotEnabled()
        rule.mainClock.advanceTimeByFrame();proof("seabed-wreck-permanent")
    }
}


