package com.notebook.seabattle

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.*
import org.junit.Assert.*

class FleetGestureTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun screen(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(15_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        prepareFullScreenProof(rule.activity)
    }
    private fun fleet():FleetLayout {
        val text=rule.onNodeWithTag("placement-board").fetchSemanticsNode().config[SemanticsProperties.StateDescription]
        return FleetLayout(if(text.isEmpty())emptyList() else text.split(';').map {ship->ship.split(',').map {c->val xy=c.split(':');Cell(xy[0].toInt(),xy[1].toInt())}.toSet()})
    }
    @Test fun doubleTapRotatesAndDragMovesWithoutAddingShips() {
        rule.setContent {NotebookTheme {FleetPlacement(onBack={},onReady={})}}
        rule.onNodeWithTag("placement-board").performTouchInput {click(Offset(width*.15f,height*.15f))}
        assertEquals(1,fleet().ships.size)
        rule.onNodeWithTag("placement-board").performTouchInput {doubleClick(Offset(width*.15f,height*.15f))}
        assertEquals((1..4).map {Cell(1,it)}.toSet(),fleet().ships.single())
        rule.onNodeWithTag("placement-board").performTouchInput {swipe(Offset(width*.15f,height*.25f),Offset(width*.55f,height*.55f),600)}
        val moved=fleet();assertEquals((4..7).map {Cell(5,it)}.toSet(),moved.ships.single())
        rule.onNodeWithTag("placement-board").performTouchInput {swipe(Offset(width*.55f,height*.55f),Offset(width*.95f,height*.95f),600)}
        assertEquals("Invalid drop must roll back",moved,fleet())
        rule.onRoot().captureToImage();proof("manual-double-tap-and-drag")
    }
    @Test fun automaticFleetsCanBeShuffledRepeatedlyAndDragged() {
        rule.setContent {NotebookTheme {FleetPlacement(onBack={},onReady={})}}
        val layouts=mutableSetOf<FleetLayout>()
        repeat(6) {
            rule.onNodeWithTag("shuffle-fleet").performClick()
            val current=fleet();Board.placed(current.ships);layouts.add(current)
        }
        assertEquals(6,layouts.size)
        val before=fleet()
        data class Move(val index:Int,val dx:Int,val dy:Int,val expected:FleetLayout)
        val move=before.ships.indices.firstNotNullOf {index->(-9..9).firstNotNullOfOrNull {dx->(-9..9).firstNotNullOfOrNull {dy->
            if(dx==0&&dy==0)null else before.move(index,dx,dy)?.let {Move(index,dx,dy,it)}
        }}}
        val cell=before.ships[move.index].first()
        rule.onNodeWithTag("placement-board").performTouchInput {swipe(Offset(width*(cell.x+.5f)/10,height*(cell.y+.5f)/10),Offset(width*(cell.x+move.dx+.5f)/10,height*(cell.y+move.dy+.5f)/10),700)}
        assertEquals(move.expected,fleet());Board.placed(fleet().ships)
        rule.onRoot().captureToImage();proof("auto-fleet-dragged")
    }
    @Test fun reservePicturesDragToBoardAndBackWithoutLosingShips() {
        rule.setContent {NotebookTheme {FleetPlacement(onBack={},onReady={})}}
        rule.onAllNodes(SemanticsMatcher.keyIsDefined(SemanticsProperties.Text),useUnmergedTree=true).assertCountEquals(3)
        val board=rule.onNodeWithTag("placement-board").fetchSemanticsNode().boundsInRoot
        val stock=rule.onNodeWithTag("stock-6").fetchSemanticsNode().boundsInRoot
        val target=board.topLeft+Offset(board.width*.15f,board.height*.15f)
        rule.onRoot().performTouchInput {swipe(stock.center,target,700)}
        assertEquals(listOf(setOf(Cell(1,1))),fleet().ships)
        rule.onNodeWithTag("ready-fleet").assertIsNotEnabled()
        val stockFour=rule.onNodeWithTag("stock-0").fetchSemanticsNode().boundsInRoot
        rule.onRoot().performTouchInput {swipe(stockFour.center,target,700)}
        assertEquals("An invalid stock drop must not add or consume a vessel",listOf(setOf(Cell(1,1))),fleet().ships)
        rule.onNodeWithTag("stock-0").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"В запасе"))
        rule.onRoot().captureToImage();proof("frigate-stock-dragged-to-board")
        rule.onRoot().performTouchInput {swipe(target,stock.center,700)}
        assertTrue(fleet().ships.isEmpty())
        rule.onNodeWithTag("stock-9").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"В запасе"))
    }
}
