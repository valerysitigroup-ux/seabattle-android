package com.notebook.seabattle

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import org.junit.*
import org.junit.Assert.*
import kotlin.random.Random

class CartoonBattleTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun landscape(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(15_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        rule.waitForIdle()
        prepareFullScreenProof(rule.activity)
    }
    @Test fun largeTurnHeadingChessBoardsPencilMissesAndZoomControls() {
        val own=Board.random(Random(17)).battleView(true)
        var shotsFired=0
        rule.setContent {NotebookTheme {BattleScreen("МОРСКОЙ БОЙ","Ваш ход",own,BattleView(shots=mapOf(Cell(1,1) to false,Cell(6,3) to false,Cell(4,5) to true)),true,{},onShot={shotsFired++})}}
        rule.onNodeWithTag("top-turn").assertTextEquals("Ваш ход").assertIsDisplayed()
        rule.onNodeWithTag("own-turn-glow").assertExists()
        rule.onNodeWithContentDescription("Пиратское меню").assertExists()
        val board=rule.onNodeWithTag("enemy-board").fetchSemanticsNode().boundsInRoot
        assertCellSpacing(rule.onNodeWithTag("own-board").fetchSemanticsNode().boundsInRoot,board,rule.onRoot().fetchSemanticsNode().boundsInRoot)
        rule.onNodeWithTag("battle-menu").assertDoesNotExist()
        rule.onNodeWithContentDescription("Б2, мимо").assertExists()
        rule.onRoot().captureToImage() // Wait for the initial hardware-rendered frame before shell evidence.
        proof("cartoon-battle")
        rule.onNodeWithTag("open-menu").performClick()
        rule.onNodeWithTag("battle-menu").assertIsDisplayed();proof("parchment-menu")
        rule.onNodeWithTag("expand-enemy").performScrollTo().performClick()
        rule.onNodeWithTag("open-menu").performClick()
        rule.onNodeWithTag("zoom-in").performScrollTo().performClick()
        rule.onNodeWithTag("zoom-level").assertTextEquals("135%")
        rule.onNodeWithTag("close-menu").performScrollTo().performClick()
        rule.onNodeWithTag("enemy-board").performTouchInput {
            pinch(Offset(width*.4f,height*.5f),Offset(width*.6f,height*.5f),Offset(width*.2f,height*.5f),Offset(width*.8f,height*.5f),500)
        }
        rule.onNodeWithTag("open-menu").performClick()
        val level=rule.onNodeWithTag("zoom-level").fetchSemanticsNode().config[SemanticsProperties.Text].first().text.removeSuffix("%").toInt()
        assertTrue("Pinch must enlarge the board",level>135)
        rule.runOnIdle {assertEquals("Pinching must not fire a shot",0,shotsFired)}
        rule.onNodeWithTag("close-menu").performScrollTo().performClick()
        rule.onNodeWithTag("battle-menu").assertDoesNotExist()
        assertCellSpacing(rule.onNodeWithTag("enemy-board").fetchSemanticsNode().boundsInRoot,null,rule.onRoot().fetchSemanticsNode().boundsInRoot)
        rule.onRoot().captureToImage()
        proof("cartoon-zoom")
        rule.onNodeWithTag("open-menu").performClick()
        rule.onNodeWithTag("two-boards").performScrollTo().performClick()
        rule.onNodeWithTag("own-board").assertIsDisplayed();rule.onNodeWithTag("enemy-board").assertIsDisplayed()
    }
    @Test fun eachDeckCountSinksOnBoardWithMatchingCrew() {
        var view by mutableStateOf(BattleView())
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {Box(Modifier.size(300.dp).testTag("count-board")){NotebookGrid(view.ships,view.shots,false,sunkShips=view.sunk,battleEffects=true){}}}}
        rule.mainClock.advanceTimeBy(64)
        for(n in 1..4) {
            rule.runOnIdle {view=BattleView()};rule.mainClock.advanceTimeBy(64)
            val cells=(2 until 2+n).map {Cell(it,4)}.toSet()
            rule.runOnIdle {view=BattleView(listOf(cells),cells.associateWith{true},listOf(cells))}
            rule.mainClock.advanceTimeBy(1200)
            rule.onNodeWithTag("inline-sinking").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Палуб: $n. Моряков: $n"))
            val effect=rule.onNodeWithTag("inline-sinking").fetchSemanticsNode().boundsInRoot
            val board=rule.onNodeWithTag("count-board").fetchSemanticsNode().boundsInRoot
            assertTrue(board.contains(effect.center));assertTrue(effect.width<=board.width+1)
            if(n==1){rule.onRoot().captureToImage();proof("one-deck-on-board")}
            rule.mainClock.advanceTimeBy(2600);rule.onNodeWithTag("inline-sinking").assertDoesNotExist()
        }
    }
    @Test fun soloStartsWithOneFleetAndSupportsManualAndAutoPlacement() {
        rule.setContent {NotebookTheme {SinglePlayerGame(onBack={})}}
        rule.onNodeWithTag("placement-board").assertIsDisplayed()
        rule.onNodeWithTag("enemy-board").assertDoesNotExist()
        rule.onNodeWithContentDescription("А1, вода").performClick()
        rule.onNodeWithTag("fleet-panel").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Кораблей: 1/10"))
        rule.onNodeWithTag("ready-fleet").assertIsNotEnabled()
        rule.onNodeWithText("Авторасстановка").performClick()
        rule.onNodeWithTag("fleet-panel").assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Кораблей: 10/10"))
        rule.onRoot().captureToImage()
        proof("solo-fleet-setup")
        rule.onNodeWithTag("ready-fleet").performClick()
        rule.onNodeWithTag("own-board").assertIsDisplayed();rule.onNodeWithTag("enemy-board").assertIsDisplayed()
        rule.onNodeWithTag("open-menu").performClick()
        rule.onNodeWithText("Новая",useUnmergedTree=true).performScrollTo().performClick()
        rule.onNodeWithTag("placement-board").assertIsDisplayed()
        rule.onNodeWithTag("enemy-board").assertDoesNotExist()
    }
    @Test fun crossesAreDrawnGraduallyInsteadOfAppearingAtOnce() {
        var shots by mutableStateOf<Map<Cell,Boolean>>(emptyMap())
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {Box(Modifier.size(300.dp)){NotebookGrid(emptyList(),shots,false,battleEffects=true){}}}}
        rule.mainClock.advanceTimeBy(64)
        rule.runOnIdle {shots=mapOf(Cell(4,4) to false)}
        rule.mainClock.advanceTimeBy(200)
        rule.onNodeWithTag("drawing-cross").assertExists()
        rule.onRoot().captureToImage();proof("cross-first-stroke")
        rule.mainClock.advanceTimeBy(450);rule.onNodeWithTag("drawing-cross").assertExists()
        rule.mainClock.advanceTimeBy(600);rule.onNodeWithTag("drawing-cross").assertDoesNotExist()
        rule.onNodeWithContentDescription("Д5, мимо").assertExists()
    }
    @Test fun shotAfterZoomAndPanHitsTheVisibleCell() {
        val zoom=BoardZoomState();var selected:Cell?=null
        rule.setContent {NotebookTheme {Box(Modifier.size(300.dp)){ZoomableBoard(BattleView(),true,"mapping-board",zoom){selected=it}}}}
        rule.runOnIdle {zoom.zoom(2f);zoom.gesture(1f,Offset(zoom.side/2,zoom.side/2),Offset(zoom.side*.1f,-zoom.side*.1f))}
        rule.onNodeWithTag("mapping-board").performTouchInput {click(Offset(width*.9f,height*.5f))}
        rule.runOnIdle {assertEquals(Cell(6,5),selected)}
    }
    @Test fun sinkingAnimationShowsRescuedCrewBubblesAndCloses() {
        val ship=setOf(Cell(3,4),Cell(4,4),Cell(5,4),Cell(6,4))
        var enemy by mutableStateOf(BattleView(shots=ship.take(3).associateWith{true}))
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ваш ход",Board.random(Random(5)).battleView(true),enemy,true,{},onShot={})}}
        rule.mainClock.advanceTimeByFrame()
        rule.runOnIdle {enemy=BattleView(ships=listOf(ship),shots=ship.associateWith{true},sunk=listOf(ship))}
        rule.mainClock.advanceTimeByFrame();rule.mainClock.advanceTimeBy(1250)
        fun dryHullPixels():Int {
            val pixels=rule.onNodeWithTag("enemy-board").captureToImage().toPixelMap()
            var count=0
            for(y in (pixels.height*.35f).toInt() until (pixels.height*.47f).toInt())
                for(x in (pixels.width*.3f).toInt() until (pixels.width*.7f).toInt()) {
                    val c=pixels[x,y]
                    if(c.red>c.green*1.12f&&c.green>c.blue*1.05f&&c.green>.12f)count++
                }
            return count
        }
        val earlyHull=dryHullPixels();assertTrue("A dry portion of the hull is initially visible",earlyHull>10)
        proof("sinking-waterline")
        rule.mainClock.advanceTimeBy(750)
        rule.onNodeWithTag("sinking-scene").assertDoesNotExist()
        rule.onNodeWithTag("inline-sinking").assertIsDisplayed().assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription,"Палуб: 4. Моряков: 4"))
        proof("sinking-crew")
        rule.mainClock.advanceTimeBy(1500);rule.onNodeWithTag("inline-sinking").assertIsDisplayed();proof("sinking-bubbles")
        assertTrue("The dry hull must disappear below the water surface",dryHullPixels()<earlyHull*.2f)
        rule.mainClock.advanceTimeBy(1000);rule.onNodeWithTag("inline-sinking").assertDoesNotExist()
    }
    @Test fun glowFollowsTurnOwnerEvenWhileShotInputIsBlocked() {
        var owner by mutableStateOf(BattleTurn.PLAYER)
        val own=Board.random().battleView(true)
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ход соперника",own,BattleView(),false,{},onShot={},activeTurn=owner)}}
        rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("own-turn-glow").assertExists();rule.onNodeWithTag("enemy-turn-glow").assertDoesNotExist()
        rule.runOnIdle {owner=BattleTurn.OPPONENT};rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("enemy-turn-glow").assertExists();rule.onNodeWithTag("own-turn-glow").assertDoesNotExist()
        rule.onRoot().captureToImage();proof("opponent-turn-highlight")
    }
}
