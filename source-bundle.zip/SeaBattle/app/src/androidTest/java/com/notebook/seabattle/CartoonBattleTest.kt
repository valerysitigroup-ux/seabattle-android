package com.notebook.seabattle

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.dp
import org.junit.*
import org.junit.Assert.*
import kotlin.random.Random

class CartoonBattleTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun landscape(){
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(5_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        rule.waitForIdle()
    }
    @Test fun largeTurnHeadingChessBoardsPencilMissesAndZoomControls() {
        val own=Board.random(Random(17)).battleView(true)
        var shotsFired=0
        rule.setContent {NotebookTheme {BattleScreen("МОРСКОЙ БОЙ","Ваш ход",own,BattleView(shots=mapOf(Cell(1,1) to false,Cell(6,3) to false,Cell(4,5) to true)),true,{},onShot={shotsFired++},showGreeting=false)}}
        rule.onNodeWithTag("top-turn").assertTextEquals("Ваш ход").assertIsDisplayed()
        val turn=rule.onNodeWithTag("top-turn").fetchSemanticsNode().boundsInRoot
        val board=rule.onNodeWithTag("enemy-board").fetchSemanticsNode().boundsInRoot
        assertTrue(turn.bottom<board.top)
        rule.onNodeWithContentDescription("Б2, мимо").assertExists()
        rule.onRoot().captureToImage() // Wait for the initial hardware-rendered frame before shell evidence.
        proof("cartoon-battle")
        rule.onNodeWithTag("expand-enemy").performScrollTo().performClick()
        rule.onNodeWithTag("zoom-in").performScrollTo().performClick()
        rule.onNodeWithTag("zoom-level").assertTextEquals("135%")
        rule.onNodeWithTag("enemy-board").performTouchInput {
            pinch(Offset(width*.4f,height*.5f),Offset(width*.6f,height*.5f),Offset(width*.2f,height*.5f),Offset(width*.8f,height*.5f),500)
        }
        val level=rule.onNodeWithTag("zoom-level").fetchSemanticsNode().config[SemanticsProperties.Text].first().text.removeSuffix("%").toInt()
        assertTrue("Pinch must enlarge the board",level>135)
        rule.runOnIdle {assertEquals("Pinching must not fire a shot",0,shotsFired)}
        proof("cartoon-zoom")
        rule.onNodeWithTag("two-boards").performScrollTo().performClick()
        rule.onNodeWithTag("own-board").assertIsDisplayed();rule.onNodeWithTag("enemy-board").assertIsDisplayed()
    }
    @Test fun shotAfterZoomAndPanHitsTheVisibleCell() {
        val zoom=BoardZoomState();var selected:Cell?=null
        rule.setContent {NotebookTheme {Box(Modifier.size(300.dp)){ZoomableBoard(BattleView(),true,"mapping-board",zoom){selected=it}}}}
        rule.runOnIdle {zoom.zoom(2f);zoom.gesture(1f,Offset(zoom.side/2,zoom.side/2),Offset(zoom.side*.1f,-zoom.side*.1f))}
        rule.onNodeWithTag("mapping-board").performTouchInput {click(Offset(width*.9f,height*.5f))}
        rule.runOnIdle {assertEquals(Cell(6,5),selected)}
    }
    @Test fun sinkingAnimationShowsRescuedCrewBubblesAndCloses() {
        var enemy by mutableStateOf(BattleView())
        val ship=setOf(Cell(3,4),Cell(4,4),Cell(5,4))
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {BattleScreen("ПРОВЕРКА","Ваш ход",Board.random(Random(5)).battleView(true),enemy,true,{},onShot={},showGreeting=false)}}
        rule.mainClock.advanceTimeByFrame()
        rule.runOnIdle {enemy=BattleView(ships=listOf(ship),shots=ship.associateWith{true},sunk=listOf(ship))}
        rule.mainClock.advanceTimeByFrame();rule.mainClock.advanceTimeBy(1400)
        rule.onNodeWithTag("sinking-scene").assertIsDisplayed();rule.onNodeWithTag("rescue-animation").assertExists()
        proof("sinking-crew")
        rule.mainClock.advanceTimeBy(1500);rule.onNodeWithTag("sinking-scene").assertIsDisplayed();proof("sinking-bubbles")
        rule.mainClock.advanceTimeBy(1000);rule.onNodeWithTag("sinking-scene").assertDoesNotExist()
    }
}
