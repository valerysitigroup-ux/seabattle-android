package com.notebook.seabattle

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.*
import org.junit.Assert.*

class PlayerProfileTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    @Before fun screen(){dismissImmersiveHintForProofs()}
    @Test fun captainNameAndPerOpponentResultsPersistAfterActivityRecreation() {
        val store=PlayerStore(rule.activity);val oldName=store.preferences.getString("name",null);val oldLedger=store.preferences.getString("ledger",null)
        try {
            rule.runOnUiThread {
                store.preferences.edit().putString("name","Капитан Тест").remove("ledger").commit()
                store.record("test-win","Вася",true);store.record("test-loss","Вася",false);store.record("test-win","Вася",true)
            }
            rule.onNodeWithTag("edit-captain").performScrollTo().performClick()
            rule.onNodeWithTag("captain-name-input").performTextReplacement("Адмирал Тест")
            rule.onNodeWithTag("save-captain-name").performScrollTo().performClick()
            rule.activityRule.scenario.recreate();rule.waitForIdle();dismissImmersiveHintForProofs()
            rule.onNodeWithTag("edit-captain").performScrollTo().performClick()
            rule.onNodeWithTag("captain-name-input").assertTextContains("Адмирал Тест")
            proof("saved-captain-name")
            rule.onNodeWithTag("back-flag").performClick()
            rule.onNodeWithTag("open-statistics").performScrollTo().performClick()
            rule.onNodeWithTag("player-totals").assertTextEquals("Побед: 1 · Поражений: 1")
            rule.onNodeWithText("Вася").assertIsDisplayed()
            assertEquals(1,PlayerStore(rule.activity).read().ledger.wins)
            assertEquals(1,PlayerStore(rule.activity).read().ledger.losses)
            proof("saved-player-statistics")
        }finally{rule.runOnUiThread {store.preferences.edit().putString("name",oldName).putString("ledger",oldLedger).commit()}}
    }
}
