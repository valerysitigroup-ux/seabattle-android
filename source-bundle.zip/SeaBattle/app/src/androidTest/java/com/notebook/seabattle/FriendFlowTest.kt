package com.notebook.seabattle

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.platform.app.InstrumentationRegistry
import okhttp3.*
import org.json.JSONObject
import org.junit.*
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.abs

internal fun proof(name:String) {
    val instrument=InstrumentationRegistry.getInstrumentation()
    // Gradle uninstalls the app after tests, including its external-files directory.
    // Shell screenshots in Downloads survive that cleanup on the disposable emulator.
    fun shell(command:String) {
        android.os.ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand(command)).use { it.readBytes() }
    }
    instrument.waitForIdleSync()
    android.os.SystemClock.sleep(120) // Let the composed frame reach the emulator compositor.
    instrument.waitForIdleSync()
    shell("mkdir -p /sdcard/Download/seabattle-proofs")
    shell("screencap -p /sdcard/Download/seabattle-proofs/$name.png")
}
/** Check actual layout bounds: the gap scales with cells, never with fixed dp. */
internal fun assertCellSpacing(own:androidx.compose.ui.geometry.Rect,enemy:androidx.compose.ui.geometry.Rect?,screen:androidx.compose.ui.geometry.Rect) {
    val cell=own.width/10
    Assert.assertEquals("Cells stay square",own.width,own.height,2f)
    Assert.assertTrue("Left margin at least one cell",own.left-screen.left>=cell-3f)
    Assert.assertTrue("Top margin at least one cell",own.top-screen.top>=cell-3f)
    Assert.assertTrue("Bottom margin at least one cell",screen.bottom-own.bottom>=cell-3f)
    val right=enemy ?: own
    Assert.assertTrue("Right margin at least one cell",screen.right-right.right>=cell-3f)
    Assert.assertEquals("Fields centered horizontally",screen.center.x,(own.left+right.right)/2,3f)
    Assert.assertEquals("Fields centered vertically",screen.center.y,own.center.y,3f)
    if(enemy!=null) {
        Assert.assertEquals("Exactly one cell between fields",cell,enemy.left-own.right,3f)
        Assert.assertEquals("Matching board sizes",own.width,enemy.width,2f)
        Assert.assertEquals("Boards aligned",own.top,enemy.top,2f)
    }
}

internal fun prepareFullScreenProof(activity:android.app.Activity) {
    InstrumentationRegistry.getInstrumentation().runOnMainSync {
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(activity.window,false)
        androidx.core.view.WindowInsetsControllerCompat(activity.window,activity.window.decorView).apply {
            systemBarsBehavior=androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }
    dismissImmersiveHintForProofs()
}
internal fun dismissImmersiveHintForProofs() {
        // Android's first-use immersive hint is system UI, outside the Compose tree.
        // Dismiss its observed "Got it" button before screenshots of the actual Activity.
        val automation=InstrumentationRegistry.getInstrumentation().uiAutomation
        val service=automation.serviceInfo
        service.flags=service.flags or android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        automation.serviceInfo=service
        val deadline=android.os.SystemClock.uptimeMillis()+4000
        while(android.os.SystemClock.uptimeMillis()<deadline) {
            val roots=listOfNotNull(automation.rootInActiveWindow)+automation.windows.mapNotNull {it.root}
            val button=roots.flatMap {it.findAccessibilityNodeInfosByText("Got it")}.firstOrNull()
            if(button!=null) {
                button.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                android.os.SystemClock.sleep(200)
                return
            }
            android.os.SystemClock.sleep(100)
        }
    }

class EntrySmokeTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    @Before fun dismissSystemFullScreenTutorial() {dismissImmersiveHintForProofs()}
    private fun assertSystemBarsHidden() {
        rule.waitUntil(5_000) {
            var hidden=false
            rule.runOnUiThread {
                val insets=androidx.core.view.ViewCompat.getRootWindowInsets(rule.activity.window.decorView)
                hidden=insets!=null&&!insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.statusBars())&&!insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
            }
            hidden
        }
    }
    @Test fun realActivitySoloSetupAndFullScreenMenu() {
        assertSystemBarsHidden()
        rule.onNodeWithText("ИГРАТЬ").assertDoesNotExist()
        val paper=rule.onNodeWithTag("home-parchment").fetchSemanticsNode().boundsInRoot
        val home=rule.onRoot().fetchSemanticsNode().boundsInRoot
        Assert.assertTrue(paper.width<home.width*.75f);Assert.assertEquals(home.center.x,paper.center.x,3f)
        proof("home-sea-burnt-parchment")
        rule.onNodeWithText("Против компьютера").performClick()
        rule.onNodeWithTag("placement-board").assertIsDisplayed()
        rule.onNodeWithTag("enemy-board").assertDoesNotExist()
        rule.onNodeWithText("Авторасстановка").performClick()
        rule.onNodeWithTag("ready-fleet").performClick()
        val board=rule.onNodeWithTag("own-board").fetchSemanticsNode().boundsInRoot
        val screen=rule.onRoot().fetchSemanticsNode().boundsInRoot
        assertCellSpacing(board,rule.onNodeWithTag("enemy-board").fetchSemanticsNode().boundsInRoot,screen)
        rule.onRoot().captureToImage();proof("full-screen-pirate-battle")
        rule.onNodeWithTag("open-menu").performClick()
        val menu=rule.onNodeWithTag("battle-menu").fetchSemanticsNode().boundsInRoot
        Assert.assertTrue(menu.width>=screen.width-2f&&menu.height>=screen.height-2f)
        proof("full-screen-parchment-menu")
        rule.onNodeWithTag("close-menu").performClick()
        rule.onNodeWithTag("battle-menu").assertDoesNotExist()
        rule.onNodeWithTag("enemy-board").assertIsDisplayed()
        rule.activityRule.scenario.moveToState(androidx.lifecycle.Lifecycle.State.CREATED)
        rule.activityRule.scenario.moveToState(androidx.lifecycle.Lifecycle.State.RESUMED)
        assertSystemBarsHidden()
        rule.onNodeWithTag("enemy-board").assertIsDisplayed()
        rule.onRoot().captureToImage();proof("resumed-full-screen")
    }
    @Test fun friendInternetMenuOpensWithoutCrashing() {
        rule.onNodeWithText("С другом").performClick()
        rule.onNodeWithText("На одном телефоне").assertDoesNotExist()
        rule.onNodeWithText("По интернету").performClick()
        rule.waitUntil(10_000) {rule.onAllNodesWithText("ИГРА С ДРУГОМ").fetchSemanticsNodes().isNotEmpty()}
        rule.onNodeWithText("ИГРА С ДРУГОМ").assertIsDisplayed()
        rule.onNodeWithTag("back-flag").performClick()
        rule.onNodeWithText("По интернету").performClick()
        rule.waitUntil(10_000) {rule.onAllNodesWithText("ИГРА С ДРУГОМ").fetchSemanticsNodes().isNotEmpty()}
        assertSystemBarsHidden()
        proof("online-entry-api31")
    }
    @Test fun pirateFlagsReplaceBackTextInFriendsEntranceAndPlacement() {
        fun flagInCorner(){
            rule.onNodeWithText("Назад",ignoreCase=true).assertDoesNotExist()
            val bounds=rule.onNodeWithTag("back-flag").assertIsDisplayed().fetchSemanticsNode().boundsInRoot
            val root=rule.onRoot().fetchSemanticsNode().boundsInRoot
            Assert.assertTrue(bounds.left-root.left<root.width*.06f)
            Assert.assertTrue(bounds.top-root.top<root.height*.06f)
        }
        rule.onNodeWithText("С другом").performClick();flagInCorner();proof("friends-back-flag")
        rule.mainClock.autoAdvance=false
        rule.onNodeWithText("По интернету").performClick();rule.mainClock.advanceTimeBy(64)
        flagInCorner();rule.onNodeWithText("Море зовёт…").assertIsDisplayed()
        proof("sea-entrance-back-flag")
        rule.onNodeWithTag("back-flag").performClick()
        rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithText("По интернету").assertIsDisplayed()
        rule.onNodeWithTag("back-flag").performClick()
        rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithText("Против компьютера").performClick();rule.mainClock.advanceTimeBy(64);flagInCorner()
        proof("placement-back-flag")
        rule.onNodeWithTag("back-flag").performClick()
        rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithText("Против компьютера").assertIsDisplayed()
    }
}
class FriendFlowTest {
    @get:Rule val rule=createAndroidComposeRule<ComponentActivity>()
    @Before fun fullScreen() {
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        rule.waitUntil(15_000){rule.activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE}
        prepareFullScreenProof(rule.activity)
    }
    private val http=OkHttpClient()
    private var peer:WebSocket?=null
    private val messages=LinkedBlockingQueue<JSONObject>()
    private lateinit var session:OnlineSession
    private fun next(type:String):JSONObject {
        val deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(10)
        while(System.nanoTime()<deadline){val m=messages.poll(100,TimeUnit.MILLISECONDS) ?: continue;if(m.optString("type")==type)return m}
        error("No peer event: $type")
    }
    private fun send(j:JSONObject){check(peer?.send(j.toString())==true)}
    private fun start():String {
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        val opened=java.util.concurrent.CountDownLatch(1)
        peer=http.newWebSocket(Request.Builder().url("ws://10.0.2.2:8080").build(),object:WebSocketListener(){
            override fun onOpen(ws:WebSocket,response:Response){opened.countDown()}
            override fun onMessage(ws:WebSocket,text:String){messages.offer(JSONObject(text))}
        })
        check(opened.await(10,TimeUnit.SECONDS));send(JSONObject().put("type","hello").put("name","Тестовый друг"));val peerId=next("welcome").getString("id")
        session=OnlineSession(rule.activity,"ws://10.0.2.2:8080")
        val factory:(android.content.Context)->OnlineSession={session}
        rule.setContent {CompositionLocalProvider(LocalOnlineFactory provides factory) {NotebookTheme {OnlineGame(onBack={})}}}
        rule.waitUntil(15_000){session.phase==OnlinePhase.LOBBY&&session.players.any {it.id==peerId}}
        rule.onNodeWithTag("online-lobby").assertIsDisplayed()
        return peerId
    }
    @After fun cleanUp(){peer?.cancel();http.dispatcher.executorService.shutdown();http.connectionPool.evictAll()}
    @Test fun rosterInviteAutomaticFleetAndCenteredBattle() {
        val peerId=start();proof("online-roster")
        rule.onNodeWithTag("invite-$peerId").performClick()
        val invite=next("invitation")
        send(JSONObject().put("type","answer").put("id",invite.getString("id")).put("accept",true))
        next("arrange");rule.waitUntil(10_000){session.phase==OnlinePhase.CHOICE}
        val variants=mutableSetOf<String>()
        repeat(5) {
            rule.onNodeWithTag("shuffle-fleet").performClick()
            variants.add(rule.onNodeWithTag("placement-board").fetchSemanticsNode().config[androidx.compose.ui.semantics.SemanticsProperties.StateDescription])
        }
        Assert.assertEquals(5,variants.size)
        rule.onNodeWithTag("ready-fleet").performClick()
        val peerFleet=Board.random()
        send(JSONObject().put("type","fleet").put("ships",fleetJson(peerFleet)))
        rule.waitUntil(10_000){session.phase==OnlinePhase.BATTLE}
        rule.onNodeWithTag("own-board").assertIsDisplayed();rule.onNodeWithTag("enemy-board").assertIsDisplayed()
        val own=rule.onNodeWithTag("own-board").fetchSemanticsNode().boundsInRoot
        val enemy=rule.onNodeWithTag("enemy-board").fetchSemanticsNode().boundsInRoot
        val region=rule.onNodeWithTag("board-region").fetchSemanticsNode().boundsInRoot
        rule.onNodeWithTag("battle-menu").assertDoesNotExist()
        assertCellSpacing(own,enemy,region)
        Assert.assertTrue(abs((own.left+enemy.right)/2-region.center.x)<3f)
        rule.onNodeWithText("Чувак дай в долг)))").assertDoesNotExist();proof("centered-battle")
        // A losing friend can leave before our longer celebration finishes.
        rule.mainClock.autoAdvance=false
        for(cell in peerFleet.ships.flatMap {it.cells}) {
            rule.runOnIdle {session.shoot(cell)}
            rule.waitUntil(10_000){cell in session.state.enemyShots&&session.state.pending==null}
            rule.mainClock.advanceTimeBy(64)
        }
        rule.waitUntil(10_000){session.state.finished}
        send(JSONObject().put("type","leave"));next("closed")
        rule.waitUntil(10_000){session.players.any {it.id==peerId&&it.status=="available"}}
        rule.runOnIdle {Assert.assertEquals(OnlinePhase.BATTLE,session.phase);Assert.assertEquals(10,session.state.enemySunk.size)}
        var animationWait=0L
        // Query semantics on the instrumentation thread, never inside the main-clock callback.
        while(rule.onAllNodesWithTag("pirate-victory").fetchSemanticsNodes().isEmpty()&&animationWait<20_000){
            rule.mainClock.advanceTimeBy(100);animationWait+=100
        }
        rule.onNodeWithTag("pirate-victory").assertIsDisplayed();proof("online-victory-after-peer-left")
        rule.mainClock.advanceTimeBy(15000)
        rule.runOnIdle {Assert.assertEquals(OnlinePhase.LOBBY,session.phase)}
    }
    @Test fun receivedInvitationAcceptanceOpensManualFleetMenu() {
        start();send(JSONObject().put("type","invite").put("to",session.id))
        rule.waitUntil(10_000){session.invitation?.incoming==true}
        rule.runOnIdle {session.invite(session.players.first())} // An overlapping outbound invitation must not erase the incoming one.
        rule.waitUntil(10_000){session.info.startsWith("Не удалось выполнить")};rule.onNodeWithText("Принять").performClick();rule.waitUntil(10_000){session.phase==OnlinePhase.CHOICE}
        rule.onNodeWithTag("stock-0").assertIsDisplayed()
        rule.onNodeWithTag("ready-fleet").assertIsNotEnabled();proof("manual-after-accept")
    }
    @Test fun turnNoticeStaysUntilTurnChanges() {
        rule.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        var turn by androidx.compose.runtime.mutableStateOf(true)
        rule.mainClock.autoAdvance=false
        rule.setContent {NotebookTheme {androidx.compose.foundation.layout.Box {TurnNotice(turn,"Ход соперника")}}}
        rule.mainClock.advanceTimeByFrame()
        rule.onNodeWithTag("top-turn").assertTextEquals("Ваш ход")
        rule.mainClock.advanceTimeBy(20_000)
        rule.onNodeWithTag("top-turn").assertTextEquals("Ваш ход")
        rule.runOnIdle {turn=false};rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("top-turn").assertTextEquals("Ход соперника")
        rule.mainClock.advanceTimeBy(2700);rule.onNodeWithTag("top-turn").assertTextEquals("Ход соперника")
        rule.runOnIdle {turn=true};rule.mainClock.advanceTimeBy(64)
        rule.onNodeWithTag("top-turn").assertTextEquals("Ваш ход")
    }

}


