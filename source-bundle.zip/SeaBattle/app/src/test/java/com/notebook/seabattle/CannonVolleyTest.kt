package com.notebook.seabattle

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import org.junit.Assert.*
import org.junit.Test

class CannonVolleyTest {
    private val a=setOf(Cell(0,0),Cell(1,0))
    private val b=setOf(Cell(6,6))
    @Test fun existingHistoryIsNotReplayedAndUpdatesAreDeduplicated() {
        val view=BattleView(shots=mapOf(Cell(2,2) to false))
        val planner=SalvoPlanner(BattleView(),view)
        assertTrue(planner.plan(BattleView(),view).isEmpty())
        val next=view.copy(shots=view.shots+(Cell(3,3) to true))
        assertEquals(1,planner.plan(BattleView(),next).size)
        assertTrue(planner.plan(BattleView(),next).isEmpty())
    }
    @Test fun batchArrivalsRevealMarksAndSunkenEnemyOnlyAtTheirOwnFrame() {
        val planner=SalvoPlanner(BattleView(listOf(b)),BattleView())
        val frames=planner.plan(BattleView(listOf(b)),BattleView(listOf(a),a.associateWith{true},listOf(a)))
        assertEquals(2,frames.size)
        assertEquals(1,frames[0].enemy.shots.size)
        assertTrue(frames[0].enemy.ships.isEmpty());assertTrue(frames[0].enemy.sunk.isEmpty())
        assertEquals(listOf(a),frames[1].enemy.ships);assertEquals(listOf(a),frames[1].enemy.sunk)
        assertTrue(frames[1].enemy.blocked.isNotEmpty())
        assertEquals(b,frames[0].firingShip)
    }
    @Test fun sunkOwnShipRemainsVisibleBeforeIncomingArrivalAndCannotFireAgain() {
        val initial=BattleView(listOf(a,b),mapOf(a.first() to true))
        val planner=SalvoPlanner(initial,BattleView())
        val sunk=initial.copy(shots=a.associateWith{true},sunk=listOf(a))
        val incoming=planner.plan(sunk,BattleView()).single()
        assertFalse(incoming.outgoing);assertNull(incoming.firingShip)
        assertEquals(listOf(a,b),incoming.own.ships);assertEquals(listOf(a),incoming.own.sunk)
        val outgoing=planner.plan(sunk,BattleView(shots=mapOf(Cell(9,9) to false))).single()
        assertEquals(b,outgoing.firingShip)
    }
    @Test fun outgoingFrameDoesNotPrematurelyHideOwnShipSunkInSameUpdate() {
        val own=BattleView(listOf(a,b))
        val frames=SalvoPlanner(own,BattleView()).plan(own.copy(shots=a.associateWith{true},sunk=listOf(a)),BattleView(shots=mapOf(Cell(4,4) to false)))
        assertEquals(listOf(a,b),frames.first().own.ships)
        assertTrue(frames.first().own.sunk.isEmpty())
        assertEquals(listOf(a),frames.last().own.sunk)
    }
    @Test fun noFleetCanStillProduceAFlightWithoutDisclosingHiddenShips() {
        val frame=SalvoPlanner(BattleView(),BattleView()).plan(BattleView(shots=mapOf(Cell(2,3) to false)),BattleView()).single()
        assertFalse(frame.outgoing);assertFalse(frame.hit);assertNull(frame.firingShip)
        assertTrue(frame.enemy.ships.isEmpty());assertEquals(Cell(2,3),frame.target)
    }
    @Test fun shotTargetsUseCellCentersIncludingBoardOrigin() {
        assertEquals(Offset(115f,225f),boardCellPoint(Cell(1,2),Rect(100f,200f,200f,300f),BoardViewport()))
    }
    @Test fun flightTargetFollowsZoomAndPan() {
        assertEquals(Offset(90f,190f),boardCellPoint(Cell(1,2),Rect(100f,200f,200f,300f),BoardViewport(2f,Offset(10f,-10f))))
    }
    @Test fun arcStartsAndEndsAtExactTargetsWithRaisedMidpoint() {
        val start=Offset(10f,30f);val end=Offset(90f,50f)
        assertEquals(start,cannonArcPoint(start,end,-1f,20f))
        val last=cannonArcPoint(start,end,2f,20f)
        assertEquals(end.x,last.x,.001f);assertEquals(end.y,last.y,.001f)
        assertEquals(Offset(50f,20f),cannonArcPoint(start,end,.5f,20f))
    }
}
