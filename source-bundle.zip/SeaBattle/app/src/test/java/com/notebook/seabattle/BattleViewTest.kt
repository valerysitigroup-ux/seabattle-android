package com.notebook.seabattle

import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class BattleViewTest {
    @Test fun enemyShipStaysHiddenUntilEveryCellIsHit() {
        val board=Board.random(Random(53))
        val ship=board.ships.first().cells
        ship.toList().dropLast(1).forEach { board.shoot(it) }
        assertTrue(board.battleView(false).ships.isEmpty())
        board.shoot(ship.last())
        val view=board.battleView(false)
        assertEquals(listOf(ship),view.ships)
        assertEquals(listOf(ship),view.sunk)
        assertEquals(surroundingCells(listOf(ship)),view.blocked)
        assertTrue(view.blocked.none { board.occupied(it) })
    }
    @Test fun borderHaloIncludesDiagonalsButStaysOnBoard() {
        assertEquals(setOf(Cell(1,0),Cell(0,1),Cell(1,1)),surroundingCells(listOf(setOf(Cell(0,0)))))
        val ship=setOf(Cell(8,9),Cell(9,9))
        assertEquals(setOf(Cell(7,8),Cell(8,8),Cell(9,8),Cell(7,9)),surroundingCells(listOf(ship)))
    }
    @Test fun multipleWreckHalosNeverCoverAnyWreck() {
        val ships=listOf(setOf(Cell(0,0)),setOf(Cell(2,0)))
        val halo=surroundingCells(ships)
        assertTrue(Cell(1,1) in halo)
        assertEquals(halo.size,halo.distinct().size)
        assertTrue(ships.flatten().none { it in halo })
    }
    @Test fun sunkGroupDoesNotRevealUnrelatedWoundedShip() {
        val marks=mapOf(Cell(1,1) to true,Cell(2,1) to true,Cell(4,1) to true,Cell(3,1) to false)
        assertEquals(setOf(Cell(1,1),Cell(2,1)),sunkGroup(Cell(2,1),marks))
        assertTrue(sunkGroup(Cell(3,1),marks).isEmpty())
    }
    @Test fun internetSunkNotificationSurvivesFollowingSnapshotWithoutDuplicates() {
        val ready=OnlineState(player=0,turn=0,accepted=listOf(true,true))
        val state=ready.result(Cell(1,1),true,false,false).result(Cell(2,1),true,true,false)
        val next=state.snapshot(ready.copy(enemyShots=state.enemyShots))
        assertEquals(listOf(setOf(Cell(1,1),Cell(2,1))),next.enemySunk)
        assertEquals(next.enemySunk,next.result(Cell(2,1),true,true,false).enemySunk)
        assertTrue(next.ownSunk.isEmpty())
        assertTrue(OnlineState().enemySunk.isEmpty())
    }
    @Test fun internetIncomingSinkIsRecordedOnLeftBoardOnly() {
        val state=OnlineState().result(Cell(8,9),true,false,true).result(Cell(9,9),true,true,true)
        assertEquals(listOf(setOf(Cell(8,9),Cell(9,9))),state.ownSunk)
        assertTrue(state.enemySunk.isEmpty())
        assertTrue(state.enemyShots.isEmpty())
    }
    @Test fun internetBlocksShotsAroundSunkShipWithoutInventingActualShots() {
        val state=OnlineState(player=0,turn=0,accepted=listOf(true,true)).result(Cell(0,0),true,true,false)
        assertEquals(1,state.enemyShots.size)
        try { state.fire(Cell(1,1));fail("Diagonal halo must be blocked") } catch(_:IllegalArgumentException) { }
        assertEquals(Cell(2,0),state.fire(Cell(2,0)).pending)
    }
    @Test fun bluetoothRevealsOnlySunkComponentsAndKeepsPendingSeparate() {
        val view=bluetoothBattleView(mapOf(Cell(1,1) to ShotResult.HIT,Cell(2,1) to ShotResult.SUNK,
            Cell(5,5) to ShotResult.HIT,Cell(9,9) to ShotResult.ALREADY_SHOT,Cell(4,4) to ShotResult.MISS))
        assertEquals(listOf(setOf(Cell(1,1),Cell(2,1))),view.ships)
        assertEquals(setOf(Cell(9,9)),view.pending)
        assertFalse(Cell(9,9) in view.shots)
        assertEquals(false,view.shots[Cell(4,4)])
        assertFalse(view.ships.any { Cell(5,5) in it })
    }
}
