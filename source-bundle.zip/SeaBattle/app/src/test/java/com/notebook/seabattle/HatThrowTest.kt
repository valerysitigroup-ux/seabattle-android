package com.notebook.seabattle
import androidx.compose.ui.geometry.Offset
import org.junit.Assert.*
import org.junit.Test

class HatThrowTest {
    private val shoulder=Offset(204f,527f);private val elbow=Offset(194f,559f);private val wrist=Offset(188f,593f)
    @Test fun armAnimationKeepsBothPaintedBonesConnectedAtTheElbow() {
        for(i in 0..100){val p=hatThrowPose(i*.028f,0);val e=rotatePoint(elbow,shoulder,p.shoulderDegrees);val hand=throwingHand(shoulder,elbow,wrist,p)
            assertEquals((elbow-shoulder).getDistance(),(e-shoulder).getDistance(),.001f)
            assertEquals((wrist-elbow).getDistance(),(hand-e).getDistance(),.001f)
        }
    }
    @Test fun hatStartsInTheHandThenReleasesAndReturnsToIt() {
        val held=hatThrowPose(.15f,0);val hand=throwingHand(shoulder,elbow,wrist,held)
        assertFalse(held.released);assertEquals(hand,thrownHat(hand,hand,held,150f,20f))
        val flight=hatThrowPose(1.2f,0);val current=throwingHand(shoulder,elbow,wrist,flight)
        val release=throwingHand(shoulder,elbow,wrist,HatThrowPose(148f,-18f,true,0f))
        assertTrue(flight.released);assertTrue((thrownHat(current,release,flight,150f,20f)-current).getDistance()>50)
        assertTrue((thrownHat(hand,release,flight.copy(flight=1f),150f,20f)-hand).getDistance()<.001f)
    }
    @Test fun repeatedCelebrationLoopsWithoutAnArmJump() {
        val a=hatThrowPose(0f,0);val b=hatThrowPose(2.8f,0)
        assertEquals(a,b);assertNotEquals(hatThrowPose(.70f,0),hatThrowPose(.70f,3))
    }
}
