package com.notebook.seabattle

import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class SoloMatchTest {
    @Test fun opensWithPlayableFleetAndPlayerTurn() {
        val match=SoloMatch()
        assertEquals(SoloTurn.PLAYER,match.turn)
        assertEquals(20,match.own.ships.sumOf {it.cells.size})
        assertNull(match.winner)
        assertNull(match.computerFire())
    }
    @Test fun missHandsOverAndBlocksPlayerUntilComputerMisses() {
        val match=SoloMatch()
        val water=(0..9).flatMap {y->(0..9).map {x->Cell(x,y)}}.first {!match.opponent.occupied(it)}
        assertEquals(ShotResult.MISS,match.playerFire(water))
        assertEquals(SoloTurn.COMPUTER,match.turn)
        assertNull(match.playerFire(Cell(0,0)))
        repeat(100) {if(match.turn==SoloTurn.COMPUTER && match.winner==null)match.computerFire()}
        assertTrue(match.turn==SoloTurn.PLAYER || match.winner!=null)
        assertTrue(match.own.shots.isNotEmpty())
    }
    @Test fun hitsKeepTurnAndVictoryStopsBothPlayers() {
        val match=SoloMatch()
        val occupied=match.opponent.ships.flatMap {it.cells}
        occupied.dropLast(1).forEach {assertNotEquals(ShotResult.MISS,match.playerFire(it))}
        assertEquals(SoloTurn.PLAYER,match.turn)
        assertEquals(ShotResult.WIN,match.playerFire(occupied.last()))
        assertEquals(SoloTurn.PLAYER,match.winner)
        assertNull(match.computerFire());assertNull(match.playerFire(Cell(9,9)))
    }
    @Test fun repeatedPlayerShotDoesNotGiveOpponentAnotherTurn() {
        val match=SoloMatch()
        val hit=match.opponent.ships.first().cells.first()
        match.playerFire(hit)
        assertEquals(ShotResult.ALREADY_SHOT,match.playerFire(hit))
        assertEquals(SoloTurn.PLAYER,match.turn)
    }
    @Test fun aiPursuesAnAdjacentCellAfterHit() {
        val ai=CaptainAI(Random(1));val first=ai.nextShot();ai.accept(first,ShotResult.HIT)
        val next=ai.nextShot()
        assertEquals(1,kotlin.math.abs(first.x-next.x)+kotlin.math.abs(first.y-next.y))
    }
    @Test fun aiNeverRepeatsAndFinishesUnknownFleets() {
        repeat(20) {seed ->
            val board=Board.random(Random(seed))
            val ai=CaptainAI(Random(seed+100))
            val seen=mutableSetOf<Cell>()
            var won=false
            while(!won && seen.size<100) {
                val cell=ai.nextShot();assertTrue(seen.add(cell))
                val result=board.shoot(cell);assertNotEquals(ShotResult.ALREADY_SHOT,result)
                ai.accept(cell,result);won=result==ShotResult.WIN
            }
            assertTrue("AI failed for seed $seed",won)
        }
    }
    @Test fun aiWaitsForFeedbackAndRejectsWrongCell() {
        val ai=CaptainAI(Random(5));val c=ai.nextShot()
        try {ai.nextShot();fail("Must wait for result")}catch(_:IllegalStateException){}
        try {ai.accept(Cell(-1,-1),ShotResult.MISS);fail("Wrong result")}catch(_:IllegalArgumentException){}
        ai.accept(c,ShotResult.MISS)
        assertNotEquals(c,ai.nextShot())
    }
    @Test fun completeAutomaticSoloMatchEndsWithinTwoBoards() {
        val m=SoloMatch(own=Board.random(Random(9)),opponent=Board.random(Random(10)),captain=CaptainAI(Random(11)))
        val player=CaptainAI(Random(12))
        var steps=0
        while(m.winner==null && steps<200) {
            if(m.turn==SoloTurn.PLAYER) {
                val c=player.nextShot();player.accept(c,requireNotNull(m.playerFire(c)))
            }else m.computerFire()
            steps++
        }
        assertNotNull(m.winner);assertTrue(steps<=200)
    }
}
