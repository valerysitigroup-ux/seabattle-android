package com.notebook.seabattle

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

class ShipSketchTest {
    @Test fun exportsActualGameArtworkForVisualReview() {
        val svg=buildString {
            append("<svg xmlns='http://www.w3.org/2000/svg' width='1000' height='700' viewBox='0 0 1000 700'>")
            append("<rect width='1000' height='700' fill='#fffcf0'/>")
            append("<text x='55' y='45' font-family='sans-serif' font-size='24' fill='#173b88'>Морской бой · рисунки из игры</text>")
            for(length in 1..4) {
                append("<text x='55' y='${length*145}' font-family='sans-serif' font-size='18' fill='#173b88'>${listOf("Катер","Эсминец","Крейсер","Линкор")[length-1]}</text>")
                append("<g transform='translate(230 ${length*145-80}) scale(150)' stroke='#173b88' stroke-linecap='round' stroke-linejoin='round'>")
                val shapes=ShipSketch.shapes(length)
                assertTrue(shapes.isNotEmpty())
                for(shape in shapes) {
                    assertFalse(shape.path.contains("NaN"))
                    val fill=shape.fill?.let {"#"+(it and 0xFFFFFF).toString(16).padStart(6,'0')}?:"none"
                    append("<path d='${shape.path}' fill='$fill' stroke-width='${shape.width}' opacity='${shape.alpha}'/>")
                }
                append("</g>")
            }
            append("</svg>")
        }
        DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(svg.byteInputStream())
        File("build/reports/ship-artwork.svg").also {it.parentFile?.mkdirs();it.writeText(svg)}
    }
}

