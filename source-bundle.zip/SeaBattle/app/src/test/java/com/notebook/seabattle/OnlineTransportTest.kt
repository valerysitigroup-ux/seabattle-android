package com.notebook.seabattle

import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.junit.Assert.*
import org.junit.Test
import java.net.ServerSocket
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

class OnlineTransportTest {
    @Test fun delayedUpgradeSurvivesThePreviousEightSecondLimit() {
        val client = onlineClient()
        val failure = AtomicReference<Throwable?>()
        val opened = CountDownLatch(1)
        val done = CountDownLatch(1)
        ServerSocket(0).use { server ->
            val fixture = thread(isDaemon = true, name = "delayed-upgrade") {
                try {
                    server.accept().use { peer ->
                        peer.soTimeout = 20_000
                        val reader = peer.getInputStream().bufferedReader()
                        var key = ""
                        while (true) {
                            val line = reader.readLine() ?: error("Missing headers")
                            if (line.isEmpty()) break
                            if (line.startsWith("Sec-WebSocket-Key:", ignoreCase = true)) key = line.substringAfter(':').trim()
                        }
                        check(key.isNotEmpty())
                        Thread.sleep(9_000)
                        val digest = MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray(Charsets.US_ASCII))
                        val accept = Base64.getEncoder().encodeToString(digest)
                        peer.getOutputStream().apply {
                            write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: $accept\r\n\r\n").toByteArray(Charsets.US_ASCII))
                            flush()
                        }
                        done.await(5, TimeUnit.SECONDS)
                    }
                } catch (t: Throwable) { failure.compareAndSet(null, t); opened.countDown() }
            }
            val socket = client.newWebSocket(Request.Builder().url("ws://127.0.0.1:${server.localPort}").build(), object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) { opened.countDown() }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { failure.compareAndSet(null, t); opened.countDown() }
            })
            try {
                assertTrue("Upgrade timed out", opened.await(20, TimeUnit.SECONDS))
                assertNull("Delayed upgrade failed", failure.get())
                assertEquals(120_000, client.readTimeoutMillis)
            } finally {
                done.countDown()
                socket.cancel()
                client.dispatcher.executorService.shutdownNow()
                client.connectionPool.evictAll()
                fixture.join(2_000)
            }
        }
    }
}
