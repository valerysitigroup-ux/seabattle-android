package com.notebook.seabattle

import org.junit.Assert.*
import org.junit.Test

class FleetLayoutTest {
    private val ship=(1..4).map {Cell(it,1)}.toSet()
    @Test fun rotateAndRotateBackPreserveShip() {
        val original=FleetLayout(listOf(ship));val turned=original.rotate(0)!!
        assertEquals((1..4).map {Cell(1,it)}.toSet(),turned.ships.single())
        assertEquals(original,turned.rotate(0))
    }
    @Test fun draggingMovesWholeVessel() {
        val original=FleetLayout(listOf(ship));val moved=original.move(0,3,4)!!
        assertEquals(ship.map {Cell(it.x+3,it.y+4)}.toSet(),moved.ships.single())
        assertEquals(ship,original.ships.single())
    }
    @Test fun outOfBoundsMoveIsRejected() {assertNull(FleetLayout(listOf(ship)).move(0,8,0))}
    @Test fun collisionAndDiagonalContactAreRejected() {
        val fleet=FleetLayout(listOf(ship,setOf(Cell(6,3))))
        assertNull(fleet.move(0,1,1));assertNotNull(fleet.move(0,0,5))
    }
    @Test fun blockedRotationDoesNotChangeFleet() {
        val fleet=FleetLayout(listOf(ship,setOf(Cell(1,4))))
        assertNull(fleet.rotate(0));assertEquals(ship,fleet.ships.first())
    }
    @Test fun rotationAtEdgeFitsInsideBoard() {
        val fleet=FleetLayout(listOf((6..9).map {Cell(2,it)}.toSet()))
        val turned=fleet.rotate(0)!!
        assertEquals(4,turned.ships.single().size);assertTrue(turned.ships.single().all {it.x in 0..9&&it.y in 0..9})
    }
    @Test fun repeatedAutoShuffleProducesEditableValidFleets() {
        var fleet=FleetLayout()
        repeat(20) {
            val next=fleet.shuffled();assertNotEquals(fleet,next)
            Board.placed(next.ships);fleet=next
        }
        val move=fleet.ships.indices.firstNotNullOfOrNull {i->(-3..3).firstNotNullOfOrNull {dx->(-3..3).firstNotNullOfOrNull {dy->if(dx==0&&dy==0)null else fleet.move(i,dx,dy)}}}
        assertNotNull(move);Board.placed(move!!.ships)
    }
}
