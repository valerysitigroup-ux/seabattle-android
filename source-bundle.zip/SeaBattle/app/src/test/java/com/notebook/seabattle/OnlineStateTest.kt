package com.notebook.seabattle

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONArray

class OnlineStateTest {
    private fun ready() = OnlineState(player=0,turn=0,accepted=listOf(true,true))
    @Test fun requiresBothFleetsAndCorrectTurn() {
        assertFalse(OnlineState().canShoot)
        assertFalse(ready().copy(accepted=listOf(true,false)).canShoot)
        assertFalse(ready().copy(turn=1).canShoot)
        assertFalse(ready().copy(finished=true).canShoot)
        assertTrue(ready().canShoot)
    }
    @Test fun onlyOnePendingShot() {
        val pending=ready().fire(Cell(0,0))
        assertFalse(pending.canShoot)
        try { pending.fire(Cell(1,0)); fail("Second shot must be blocked") } catch (_: IllegalArgumentException) { }
    }
    @Test fun unrelatedSnapshotDoesNotUnlockPendingShot() {
        val pending=ready().fire(Cell(0,0))
        assertEquals(Cell(0,0),pending.snapshot(ready()).pending)
    }
    @Test fun acceptedHitUnlocksNextShot() {
        val next=ready().fire(Cell(0,0)).snapshot(ready().copy(enemyShots=mapOf(Cell(0,0) to true)))
        assertNull(next.pending); assertTrue(next.canShoot)
    }
    @Test fun missChangesTurnAndFinishedBlocksShots() {
        val pending=ready().fire(Cell(9,9))
        val missed=pending.snapshot(ready().copy(turn=1,enemyShots=mapOf(Cell(9,9) to false)))
        assertNull(missed.pending); assertFalse(missed.canShoot)
        assertFalse(pending.snapshot(ready().copy(finished=true)).canShoot)
    }
    @Test fun cannotShootSameCellAgain() {
        val state=ready().copy(enemyShots=mapOf(Cell(0,0) to true))
        try { state.fire(Cell(0,0)); fail("Duplicate shot") } catch (_: IllegalArgumentException) { }
    }
    @Test fun playerOneReadinessIsOwnReadiness() {
        assertFalse(ready().copy(player=1,accepted=listOf(true,false)).fleetAccepted)
        assertTrue(ready().copy(player=1,accepted=listOf(false,true)).fleetAccepted)
    }
    @Test fun actualFleetJsonContainsChosenCoordinates() {
        val board=Board.random(kotlin.random.Random(47))
        val decoded=JSONArray(fleetJson(board).toString())
        val cells=(0 until decoded.length()).map { i ->
            val ship=decoded.getJSONArray(i)
            (0 until ship.length()).map { j -> val c=ship.getJSONArray(j); Cell(c.getInt(0),c.getInt(1)) }.toSet()
        }
        assertEquals(board.ships.map { it.cells },cells)
        Board.placed(cells)
    }
}
