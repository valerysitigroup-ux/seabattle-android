package com.notebook.seabattle
import org.junit.Assert.*
import org.junit.Test

class MatchLedgerTest {
    @Test fun scoresAccumulatePerOpponentAndCountOnlyOncePerMatch() {
        var book=MatchLedger()
        repeat(5){book=book.record("win-$it","Вася",true)}
        repeat(7){book=book.record("loss-$it","Вася",false)}
        book=book.record("other","Петя",true)
        assertEquals(OpponentScore("Вася",5,7),book.opponents.first())
        assertEquals(6,book.wins);assertEquals(7,book.losses)
        assertEquals(book,book.record("win-0","Вася",false))
    }
    @Test fun serializationRetainsScoresAndDeduplicationAcrossRestarts() {
        val before=MatchLedger().record("online:session:123456","Вася",true).record("bt:unique","Петя",false)
        val restored=MatchLedger.fromJson(before.toJson())
        assertEquals(before,restored);assertEquals(restored,restored.record("online:session:123456","Вася",true))
    }
    @Test fun sameDisplayNameInDifferentCaseAndNewRoomsAccumulates() {
        val book=MatchLedger().record("session1:111111","  Вася  ",true).record("session2:111111","вася",false)
        assertEquals(1,book.opponents.size);assertEquals(1,book.wins);assertEquals(1,book.losses)
    }
    @Test fun noCompletedMatchOrOpponentMeansNoRecordedScore() {
        val book=MatchLedger();assertEquals(book,book.record("","Вася",true));assertEquals(book,book.record("unfinished"," ",false))
        assertEquals(book,MatchLedger.fromJson(null));assertEquals(book,MatchLedger.fromJson("broken"))
    }
}
