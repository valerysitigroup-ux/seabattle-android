package com.notebook.seabattle
import org.junit.Assert.*
import org.junit.Test
class ServerDirectoryTest {
 @Test fun acceptsOnlyUsableSecureAddresses() {
  assertEquals("wss://game.example/play",ServerDirectory.usable(" wss://game.example/play "))
  for(bad in listOf("","https://game.example","ws://game.example","wss://","wss://user:secret@game.example","wss://game.example/#secret","not a url"))assertNull(bad,ServerDirectory.usable(bad))
 }
}
