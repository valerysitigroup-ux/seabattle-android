package com.notebook.seabattle

import androidx.compose.ui.geometry.Offset
import org.junit.Assert.*
import org.junit.Test

class BoardViewportTest {
    @Test fun zoomLimitsAreOneToThree() {
        assertEquals(3f,BoardViewport().transform(10f,Offset(50f,50f),Offset.Zero,100f).scale,0f)
        assertEquals(BoardViewport(),BoardViewport(2f,Offset(12f,8f)).transform(.1f,Offset(50f,50f),Offset.Zero,100f))
    }
    @Test fun pinchingKeepsTheTouchedPointAnchored() {
        val next=BoardViewport().transform(2f,Offset(75f,25f),Offset.Zero,100f)
        assertEquals(Offset(-25f,25f),next.offset)
        // The original point at 75,25 still projects to 75,25 around the board centre.
        assertEquals(Offset(75f,25f),(Offset(75f,25f)-Offset(50f,50f))*next.scale+Offset(50f,50f)+next.offset)
    }
    @Test fun panNeverExposesEmptySpaceOutsideTheBoard() {
        assertEquals(Offset(100f,-100f),BoardViewport(3f).transform(1f,Offset.Zero,Offset(1000f,-1000f),100f).offset)
    }
    @Test fun aNormalSizeBoardCannotBePannedAway() {
        assertEquals(BoardViewport(),BoardViewport().transform(1f,Offset.Zero,Offset(44f,-30f),100f))
    }
    @Test fun invalidGestureCannotCorruptTheViewport() {
        val original=BoardViewport(2f,Offset(1f,2f))
        assertEquals(original,original.transform(Float.NaN,Offset.Zero,Offset.Zero,100f))
        assertEquals(original,original.transform(1f,Offset.Zero,Offset(Float.POSITIVE_INFINITY,1f),100f))
    }
    @Test fun changingBoardSizePreservesPanAndScaleProportionally() {
        val state=BoardZoomState();state.resize(100f);state.zoom(3f)
        state.gesture(1f,Offset(50f,50f),Offset(100f,-100f));state.resize(50f)
        assertEquals(3f,state.viewport.scale,0f);assertEquals(Offset(50f,-50f),state.viewport.offset)
    }
}
