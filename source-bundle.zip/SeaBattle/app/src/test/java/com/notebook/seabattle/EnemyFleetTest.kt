package com.notebook.seabattle
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class EnemyFleetTest {
    @Test fun partialHitsDoNotRevealShipTypeOrReduceRemainingShips() {
        val board=Board.random(Random(91));val ship=board.ships.first().cells.toList()
        ship.dropLast(1).forEach {board.shoot(it)}
        assertEquals(10,enemyFleetCounts(board.battleView(false).sunk).sumOf {it.remaining})
        board.shoot(ship.last())
        assertEquals(9,enemyFleetCounts(board.battleView(false).sunk).sumOf {it.remaining})
    }
    @Test fun mixedSunkTypesAndDuplicatesKeepCorrectInventory() {
        val three=setOf(Cell(1,1),Cell(2,1),Cell(3,1));val one=setOf(Cell(9,9))
        val counts=enemyFleetCounts(listOf(three,three,one))
        assertEquals(8,counts.sumOf {it.remaining});assertEquals(1,counts.first {it.length==3}.remaining)
        assertEquals(3,counts.first {it.length==1}.remaining)
    }
    @Test fun fullStandardFleetLeavesNoShipsInAnyMode() {
        val board=Board.random(Random(7));board.ships.flatMap {it.cells}.forEach {board.shoot(it)}
        val counts=enemyFleetCounts(board.battleView(false).sunk)
        assertEquals(0,counts.sumOf {it.remaining});assertTrue(counts.all {it.sunk==it.total})
    }
}
