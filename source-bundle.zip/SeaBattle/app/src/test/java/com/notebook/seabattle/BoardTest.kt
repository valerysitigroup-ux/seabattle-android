package com.notebook.seabattle

import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class BoardTest {
    private fun positions() = listOf(
        setOf(Cell(0,0),Cell(1,0),Cell(2,0),Cell(3,0)),
        setOf(Cell(6,0),Cell(7,0),Cell(8,0)), setOf(Cell(0,2),Cell(1,2),Cell(2,2)),
        setOf(Cell(5,2),Cell(6,2)), setOf(Cell(8,2),Cell(8,3)), setOf(Cell(0,4),Cell(1,4)),
        setOf(Cell(4,4)),setOf(Cell(6,5)),setOf(Cell(8,6)),setOf(Cell(0,7)))
    private fun rejects(block: () -> Unit) {
        try { block(); fail("Expected invalid placement") } catch (_: IllegalArgumentException) { }
    }
    @Test fun manualFleetIsPreserved() {
        val p = positions(); val board = Board.placed(p)
        assertEquals(p, board.ships.map { it.cells }); assertTrue(board.shots.isEmpty())
    }
    @Test fun rejectsIncompleteFleet() = rejects { Board.placed(positions().dropLast(1)) }
    @Test fun rejectsTouchingAndOverlap() {
        for (c in listOf(Cell(5,5),Cell(4,0),Cell(0,0))) {
            rejects { Board.placed(positions().toMutableList().also { it[9] = setOf(c) }) }
        }
    }
    @Test fun rejectsBentGappedAndOutOfBounds() {
        for (ship in listOf(setOf(Cell(0,0),Cell(1,0),Cell(2,0),Cell(2,1)),
            setOf(Cell(0,0),Cell(1,0),Cell(2,0),Cell(4,0)),
            setOf(Cell(-1,0),Cell(0,0),Cell(1,0),Cell(2,0)))) {
            rejects { Board.placed(positions().toMutableList().also { it[0] = ship }) }
        }
    }
    @Test fun validationCopiesMutableInput() {
        val ship = positions()[0].toMutableSet()
        val p = positions().toMutableList().also { it[0] = ship }
        val board = Board.placed(p); ship.clear(); p.clear()
        assertEquals(4, board.ships[0].cells.size)
    }
    @Test fun randomFleetsPassManualValidator() {
        repeat(100) { seed ->
            val board=Board.random(Random(seed))
            assertEquals(20, Board.placed(board.ships.map { it.cells }).ships.sumOf { it.cells.size })
        }
    }
    @Test fun shotRulesMissHitSunkWinAndDuplicate() {
        val board=Board.placed(positions())
        assertEquals(ShotResult.MISS,board.shoot(Cell(9,9)))
        assertEquals(ShotResult.ALREADY_SHOT,board.shoot(Cell(9,9)))
        assertEquals(ShotResult.HIT,board.shoot(Cell(0,0)))
        assertEquals(ShotResult.ALREADY_SHOT,board.shoot(Cell(0,0)))
        board.shoot(Cell(1,0)); board.shoot(Cell(2,0))
        assertEquals(ShotResult.SUNK,board.shoot(Cell(3,0)))
        val remaining=positions().drop(1).flatMap { it }
        remaining.dropLast(1).forEach { board.shoot(it) }
        assertEquals(ShotResult.WIN,board.shoot(remaining.last()))
    }
    @Test fun rejectsInvalidShotWithoutMutatingBoard() {
        val board=Board.placed(positions())
        rejects { board.shoot(Cell(10,0)) }; assertTrue(board.shots.isEmpty())
    }
}
