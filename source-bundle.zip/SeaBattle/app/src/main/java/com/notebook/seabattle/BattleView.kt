package com.notebook.seabattle

/** Public battle information only; wounded enemy vessels stay hidden. */
data class BattleView(
    val ships: List<Set<Cell>> = emptyList(),
    val shots: Map<Cell, Boolean> = emptyMap(),
    val sunk: List<Set<Cell>> = emptyList(),
    val pending: Set<Cell> = emptySet()
) {
    val blocked get() = surroundingCells(sunk)
}

fun surroundingCells(ships: List<Set<Cell>>): Set<Cell> {
    val occupied = ships.flatten().toSet()
    return occupied.flatMap { c -> (-1..1).flatMap { dx -> (-1..1).map { dy -> Cell(c.x+dx,c.y+dy) } } }
        .filter { it.x in 0..9 && it.y in 0..9 && it !in occupied }.toSet()
}

fun Board.battleView(showFleet: Boolean): BattleView {
    val marks = shots.associateWith { occupied(it) }
    val sunk = ships.map { it.cells }.filter { it.all { c -> marks[c] == true } }
    return BattleView(if(showFleet) ships.map { it.cells } else sunk, marks, sunk)
}

/** Non-touching fleets let a sunk notification reveal exactly one connected hit group. */
fun sunkGroup(cell: Cell, shots: Map<Cell, Boolean>): Set<Cell> {
    if(shots[cell] != true) return emptySet()
    val group = mutableSetOf(cell)
    val queue = ArrayDeque<Cell>().apply { add(cell) }
    while(queue.isNotEmpty()) {
        val c=queue.removeFirst()
        for(n in listOf(Cell(c.x-1,c.y),Cell(c.x+1,c.y),Cell(c.x,c.y-1),Cell(c.x,c.y+1))) {
            if(shots[n] == true && group.add(n)) queue.add(n)
        }
    }
    return group.toSet()
}

fun bluetoothBattleView(results: Map<Cell, ShotResult>): BattleView {
    val marks=results.filterValues { it != ShotResult.ALREADY_SHOT }.mapValues { it.value != ShotResult.MISS }
    val sunk=results.filterValues { it == ShotResult.SUNK || it == ShotResult.WIN }.keys
        .map { sunkGroup(it,marks) }.filter { it.isNotEmpty() }.distinct()
    return BattleView(sunk,marks,sunk,results.filterValues { it == ShotResult.ALREADY_SHOT }.keys.toSet())
}
