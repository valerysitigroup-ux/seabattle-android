package com.notebook.seabattle

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class OpponentScore(val name:String,val wins:Int=0,val losses:Int=0)
data class MatchLedger(val opponents:List<OpponentScore> = emptyList(),val recorded:Set<String> = emptySet()) {
    val wins get()=opponents.sumOf {it.wins}
    val losses get()=opponents.sumOf {it.losses}
    fun record(matchId:String,opponent:String,won:Boolean):MatchLedger {
        val name=opponent.trim().replace(Regex("\\s+")," ").take(24)
        if(matchId.isBlank()||name.isBlank()||matchId in recorded)return this
        val index=opponents.indexOfFirst {it.name.lowercase(Locale.ROOT)==name.lowercase(Locale.ROOT)}
        val old=opponents.getOrNull(index) ?: OpponentScore(name)
        val score=old.copy(name=name,wins=old.wins+if(won)1 else 0,losses=old.losses+if(won)0 else 1)
        return copy(opponents=if(index<0)opponents+score else opponents.mapIndexed {i,s->if(i==index)score else s},recorded=recorded+matchId)
    }
    fun toJson():String=JSONObject().put("opponents",JSONArray().apply {opponents.forEach {s->put(JSONObject().put("name",s.name).put("wins",s.wins).put("losses",s.losses))}})
        .put("recorded",JSONArray(recorded.toList())).toString()
    companion object {
        fun fromJson(raw:String?):MatchLedger=runCatching {
            val j=JSONObject(raw ?: "{}");val scores=j.optJSONArray("opponents") ?: JSONArray();val ids=j.optJSONArray("recorded") ?: JSONArray()
            MatchLedger((0 until scores.length()).map {i->val s=scores.getJSONObject(i);OpponentScore(s.getString("name"),s.getInt("wins").coerceAtLeast(0),s.getInt("losses").coerceAtLeast(0))},(0 until ids.length()).map {ids.getString(it)}.toSet())
        }.getOrElse {MatchLedger()}
    }
}
