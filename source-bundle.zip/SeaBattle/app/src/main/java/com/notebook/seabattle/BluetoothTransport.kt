package com.notebook.seabattle

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import kotlin.concurrent.thread

/** RFCOMM transport for paired devices. Android 12+ requires BLUETOOTH_CONNECT runtime grant.
 * The turn protocol is implemented by BluetoothGame.
 */
class BluetoothTransport(private val adapter: BluetoothAdapter) {
    companion object {
        val SERVICE_ID: UUID = UUID.fromString("78d2f5e1-41f9-4ab3-bf41-ec81ac3c1a70")
    }
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var listener: BluetoothServerSocket? = null
    @SuppressLint("MissingPermission")
    fun peerDeviceName():String?=socket?.remoteDevice?.name

    @SuppressLint("MissingPermission")
    fun host(onMessage: (String) -> Unit, onError: (Throwable) -> Unit, onConnected: () -> Unit = {}) = thread(name="sea-bt-host") {
        try {
            listener = adapter.listenUsingRfcommWithServiceRecord("Notebook Sea Battle", SERVICE_ID)
            val accepted = listener!!.accept()
            socket = accepted
            listener?.close(); listener = null
            onConnected()
            readLoop(accepted, onMessage)
        } catch (e: Exception) { onError(e) }
    }

    @SuppressLint("MissingPermission")
    fun join(device: BluetoothDevice, onMessage: (String) -> Unit, onError: (Throwable) -> Unit, onConnected: () -> Unit = {}) = thread(name="sea-bt-client") {
        try {
            val connected = device.createRfcommSocketToServiceRecord(SERVICE_ID)
            connected.connect()
            socket = connected
            onConnected()
            readLoop(connected, onMessage)
        } catch (e: Exception) { onError(e) }
    }

    private fun readLoop(s: BluetoothSocket, onMessage: (String) -> Unit) {
        val reader = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
        try {
            while (true) {
                val line = reader.readLine() ?: break
                if (line.length <= 16384) onMessage(line)
            }
        } finally {
            throw java.io.EOFException("Bluetooth-соединение закрыто")
        }
    }

    @Synchronized fun send(message: String) {
        require(message.length <= 16384 && '\n' !in message)
        val out = requireNotNull(socket) { "Bluetooth not connected" }.outputStream
        out.write((message + "\n").toByteArray(Charsets.UTF_8))
        out.flush()
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        try { listener?.close() } catch (_: Exception) {}
        socket = null; listener = null
    }
}
