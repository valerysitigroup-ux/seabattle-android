package com.notebook.seabattle

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import kotlin.math.*

internal const val CANNON_FLIGHT_MS=600
internal data class ShotFrame(val outgoing:Boolean,val target:Cell,val hit:Boolean,val own:BattleView,val enemy:BattleView)

/** Authoritative shots become ordered visual frames; enemy hulls and halos appear only on arrival. */
internal class SalvoPlanner(initialOwn:BattleView,initialEnemy:BattleView) {
    private var seenOwn=initialOwn
    private var seenEnemy=initialEnemy
    private fun staged(view:BattleView,marks:Map<Cell,Boolean>,concealRevealed:Boolean=false):BattleView {
        val sunk=view.sunk.filter {ship->ship.all {marks[it]==true}}
        return view.copy(ships=if(concealRevealed)view.ships.filter {it !in view.sunk||it in sunk} else view.ships,shots=marks,sunk=sunk)
    }
    fun plan(own:BattleView,enemy:BattleView):List<ShotFrame> {
        var left=staged(own,seenOwn.shots);var right=staged(enemy,seenEnemy.shots,true)
        val frames=mutableListOf<ShotFrame>()
        for((cell,hit) in enemy.shots.filterKeys {it !in seenEnemy.shots}) {
            right=staged(enemy,right.shots+(cell to hit),true)
            frames.add(ShotFrame(true,cell,hit,left,right))
        }
        for((cell,hit) in own.shots.filterKeys {it !in seenOwn.shots}) {
            left=staged(own,left.shots+(cell to hit))
            // Hidden enemy positions must never be inferred or revealed by the firing animation.
            frames.add(ShotFrame(false,cell,hit,left,right))
        }
        seenOwn=own;seenEnemy=enemy
        return frames
    }
}
internal fun boardLocalPoint(local:Offset,bounds:Rect,viewport:BoardViewport):Offset {
    val center=Offset(bounds.width/2,bounds.height/2)
    return bounds.topLeft+center+(local-center)*viewport.scale+viewport.offset
}
internal fun boardCellPoint(cell:Cell,bounds:Rect,viewport:BoardViewport)=boardLocalPoint(Offset((cell.x+.5f)*bounds.width/10,(cell.y+.5f)*bounds.height/10),bounds,viewport)
internal fun cannonArcPoint(start:Offset,end:Offset,progress:Float,rise:Float):Offset {
    val p=progress.coerceIn(0f,1f)
    return start+(end-start)*p+Offset(0f,-sin(PI.toFloat()*p)*rise)
}

/** Fixed off-screen origins never depend on a visible or hidden vessel position. */
internal fun concealedCannonOrigin(outgoing:Boolean,screen:Size)=Offset(if(outgoing)-screen.width*.03f else screen.width*1.03f,screen.height*.25f)
