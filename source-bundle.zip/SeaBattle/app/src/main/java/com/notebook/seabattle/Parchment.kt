package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

private fun DrawScope.paperEdge():Path {
    val m=minOf(4.dp.toPx(),size.minDimension*.06f)
    val rough=minOf(2.5.dp.toPx(),size.minDimension*.03f)
    fun jitter(i:Int)=sin(i*2.71f)*rough+cos(i*1.13f)*rough*.4f
    return Path().apply {
        moveTo(m,m)
        repeat(49){i->lineTo(m+(size.width-2*m)*i/48,m+jitter(i))}
        repeat(25){i->lineTo(size.width-m+jitter(i+49),m+(size.height-2*m)*i/24)}
        repeat(49){i->lineTo(size.width-m-(size.width-2*m)*i/48,size.height-m+jitter(i+74))}
        repeat(25){i->lineTo(m+jitter(i+123),size.height-m-(size.height-2*m)*i/24)}
        close()
    }
}
internal fun DrawScope.drawBurntParchment() {
    val edge=paperEdge()
    drawPath(edge,Brush.radialGradient(listOf(Color(0xFFF6DFAC),Color(0xFFE9C98C),Color(0xFFB47A3D)),center=Offset(size.width*.5f,size.height*.45f),radius=size.maxDimension*.7f))
    drawPath(edge,Color(0xFF30231B),style=Stroke(minOf(7.dp.toPx(),size.minDimension*.12f),join=StrokeJoin.Round))
    drawPath(edge,Color(0xFF87502B),style=Stroke(minOf(4.dp.toPx(),size.minDimension*.07f),join=StrokeJoin.Round))
    drawPath(edge,Color(0xFFC28B45),style=Stroke(1.dp.toPx(),join=StrokeJoin.Round))
    repeat(260){i->
        val x=((i*157)%997)/997f*size.width;val y=((i*317)%991)/991f*size.height
        drawLine(Color(0xFF805526).copy(alpha=.045f),Offset(x,y),Offset(x+2.dp.toPx()+(i%5),y+(i%3-1)),.5.dp.toPx())
    }
    if(size.height>100.dp.toPx()&&size.width>100.dp.toPx()) {
        val c=Offset(size.width-26.dp.toPx(),size.height-27.dp.toPx());val r=13.dp.toPx()
        drawCircle(Color(0xFF704A2A).copy(alpha=.16f),r,c,style=Stroke(1.dp.toPx()))
        repeat(8){i->val a=i*PI.toFloat()/4;val d=Offset(cos(a),sin(a));drawLine(Color(0xFF704A2A).copy(alpha=.2f),c-d*r*.6f,c+d*r,1.dp.toPx())}
    }
}
internal fun Modifier.burntPaper()=drawBehind {drawBurntParchment()}
@Composable fun Parchment(modifier:Modifier=Modifier,content:@Composable BoxScope.()->Unit) {
    Box(modifier.pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent()}}}) {
        Canvas(Modifier.matchParentSize()){drawBurntParchment()}
        content()
    }
}
@Composable internal fun LargeMenuText(content:@Composable ()->Unit) {
    MaterialTheme(typography=MaterialTheme.typography.copy(labelLarge=MaterialTheme.typography.labelLarge.copy(fontSize=30.sp,lineHeight=34.sp),bodyLarge=MaterialTheme.typography.bodyLarge.copy(fontSize=28.sp,lineHeight=32.sp)),content=content)
}
