package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.ui.input.pointer.pointerInput

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Opaque parchment keeps menus readable and prevents the sea showing through. */
@Composable fun Parchment(modifier:Modifier=Modifier,content:@Composable BoxScope.()->Unit) {
    Box(modifier.pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent()}}}) {
        Canvas(Modifier.matchParentSize()) {
            drawRect(Brush.radialGradient(listOf(Color(0xFFF3DCA7),Color(0xFFD9B473),Color(0xFFB08045)),center=Offset(size.width*.48f,size.height*.4f),radius=size.maxDimension*.8f))
            repeat(430) { i ->
                val x=((i*157)%997)/997f*size.width;val y=((i*317)%991)/991f*size.height
                drawCircle(Color(0xFF805526).copy(alpha=.035f+(i%4)*.009f),.5.dp.toPx()+(i%3)*.3f,Offset(x,y))
            }
            drawRect(Color(0xFF805526).copy(alpha=.4f),Offset(7.dp.toPx(),7.dp.toPx()),Size((size.width-14.dp.toPx()).coerceAtLeast(0f),(size.height-14.dp.toPx()).coerceAtLeast(0f)),style=Stroke(1.5.dp.toPx()))
        }
        content()
    }
}
@Composable internal fun LargeMenuText(content:@Composable ()->Unit) {
    MaterialTheme(typography=MaterialTheme.typography.copy(labelLarge=MaterialTheme.typography.labelLarge.copy(fontSize=30.sp,lineHeight=34.sp),bodyLarge=MaterialTheme.typography.bodyLarge.copy(fontSize=28.sp,lineHeight=32.sp)),content=content)
}

