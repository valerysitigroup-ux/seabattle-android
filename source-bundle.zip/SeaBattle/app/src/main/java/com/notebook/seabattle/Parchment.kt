package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

internal val LocalBurntParchment=staticCompositionLocalOf<ImageBitmap?> {null}

/** Nine slices preserve the irregular carbonised corners on both small labels and full menus. */
internal fun DrawScope.drawBurntParchment(paper:ImageBitmap?) {
    if(paper==null){drawRect(NotebookPaper);return}
    val srcX=(paper.width*.2f).roundToInt();val srcY=(paper.height*.2f).roundToInt()
    val border=minOf(28.dp.toPx(),size.minDimension*.26f).roundToInt().coerceAtLeast(1)
    val sx=intArrayOf(0,srcX,paper.width-srcX,paper.width)
    val sy=intArrayOf(0,srcY,paper.height-srcY,paper.height)
    val dx=intArrayOf(0,border,size.width.roundToInt()-border,size.width.roundToInt())
    val dy=intArrayOf(0,border,size.height.roundToInt()-border,size.height.roundToInt())
    for(y in 0..2)for(x in 0..2) {
        val w=dx[x+1]-dx[x];val h=dy[y+1]-dy[y]
        if(w>0&&h>0)drawImage(paper,srcOffset=IntOffset(sx[x],sy[y]),srcSize=IntSize(sx[x+1]-sx[x],sy[y+1]-sy[y]),
            dstOffset=IntOffset(dx[x],dy[y]),dstSize=IntSize(w,h),filterQuality=FilterQuality.Medium)
    }
    // Dry quill-ink splashes stay in the margins, away from the text and controls.
    if(size.width>50.dp.toPx()&&size.height>32.dp.toPx()) {
        val r=minOf(7.dp.toPx(),size.minDimension*.035f)
        for((n,c) in listOf(androidx.compose.ui.geometry.Offset(size.width*.052f,size.height*.18f),androidx.compose.ui.geometry.Offset(size.width*.95f,size.height*.83f)).withIndex()) {
            val blot=Path()
            repeat(24){i->
                val a=i*Math.PI/12
                val radius=r*(.55f+(.45f*kotlin.math.sin(i*2.7+n)).toFloat().let {kotlin.math.abs(it)})
                val x=c.x+kotlin.math.cos(a).toFloat()*radius;val y=c.y+kotlin.math.sin(a).toFloat()*radius
                if(i==0)blot.moveTo(x,y)else blot.lineTo(x,y)
            }
            blot.close();drawPath(blot,BlackInk.copy(alpha=.72f))
            repeat(5){i->
                val a=i*2.31f+n
                drawCircle(BlackInk.copy(alpha=.6f),r*(.07f+(i%3)*.045f),c+androidx.compose.ui.geometry.Offset(kotlin.math.cos(a),kotlin.math.sin(a))*r*(1.3f+i*.12f))
            }
        }
    }
}
@Composable internal fun Modifier.burntPaper():Modifier {
    val paper=LocalBurntParchment.current
    return drawBehind {drawBurntParchment(paper)}
}
@Composable fun Parchment(modifier:Modifier=Modifier,content:@Composable BoxScope.()->Unit) {
    val paper=LocalBurntParchment.current
    Box(modifier.pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent()}}}) {
        Canvas(Modifier.matchParentSize()){drawBurntParchment(paper)}
        content()
    }
}
@Composable internal fun LargeMenuText(content:@Composable ()->Unit) {
    MaterialTheme(typography=MaterialTheme.typography.copy(labelLarge=MaterialTheme.typography.labelLarge.copy(fontSize=30.sp,lineHeight=34.sp),bodyLarge=MaterialTheme.typography.bodyLarge.copy(fontSize=28.sp,lineHeight=32.sp)),content=content)
}
