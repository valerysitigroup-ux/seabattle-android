package com.notebook.seabattle

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

internal fun onlineClient(): OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    // A sleeping free host may take over a minute to finish the WebSocket upgrade.
    .readTimeout(120, TimeUnit.SECONDS)
    .pingInterval(20, TimeUnit.SECONDS)
    .build()
