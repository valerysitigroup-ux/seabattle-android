package com.notebook.seabattle

import androidx.compose.ui.geometry.Offset
import kotlin.math.*

internal data class HatThrowPose(val shoulderDegrees:Float,val elbowDegrees:Float,val released:Boolean,val flight:Float)
internal fun hatThrowPose(seconds:Float,pirate:Int):HatThrowPose {
    val q=((seconds/2.8f+pirate*.107f)%1f+1f)%1f
    val lift=when {q<.10f->0f;q<.32f->(q-.10f)/.22f;q<.72f->1f;q<.92f->1-(q-.72f)/.20f;else->0f}
    val smooth=lift*lift*(3-2*lift)
    return HatThrowPose(smooth*148f,-smooth*18f,q>=.32f&&q<.88f,((q-.32f)/.56f).coerceIn(0f,1f))
}
internal fun rotatePoint(point:Offset,pivot:Offset,degrees:Float):Offset {
    val a=degrees*PI.toFloat()/180;val v=point-pivot
    return pivot+Offset(v.x*cos(a)-v.y*sin(a),v.x*sin(a)+v.y*cos(a))
}
internal fun throwingHand(shoulder:Offset,elbow:Offset,wrist:Offset,pose:HatThrowPose)=
    rotatePoint(rotatePoint(wrist,elbow,pose.elbowDegrees),shoulder,pose.shoulderDegrees)
internal fun thrownHat(hand:Offset,releaseHand:Offset,pose:HatThrowPose,rise:Float,drift:Float):Offset {
    if(!pose.released)return hand
    val q=pose.flight
    return releaseHand+(hand-releaseHand)*q+Offset(sin(q*PI.toFloat())*drift,-sin(q*PI.toFloat())*rise)
}
