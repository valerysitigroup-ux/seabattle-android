package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class FleetTypeCount(val length:Int,val total:Int,val sunk:Int) {val remaining get()=total-sunk}
/** No position or wounded-ship information is consumed by this public tally. */
fun enemyFleetCounts(sunkShips:List<Set<Cell>>):List<FleetTypeCount> = (4 downTo 1).map {length->
    val total=Board.fleetLengths.count {it==length}
    FleetTypeCount(length,total,sunkShips.distinct().count {it.size==length}.coerceIn(0,total))
}

@Composable internal fun EnemyFleetPanel(sunkShips:List<Set<Cell>>,modifier:Modifier=Modifier) {
    val counts=enemyFleetCounts(sunkShips)
    val sprites=LocalPirateSprites.current
    Parchment(modifier.testTag("enemy-fleet-panel").semantics {stateDescription="Осталось кораблей: ${counts.sumOf {it.remaining}}"}) {
        Column(Modifier.fillMaxSize().padding(horizontal=4.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Осталось",fontSize=13.sp,maxLines=1,softWrap=false)
            counts.forEach {row->
                Column(Modifier.weight(1f).fillMaxWidth().testTag("enemy-type-${row.length}")
                    .semantics {stateDescription="${row.length} палубы. Осталось: ${row.remaining}"},horizontalAlignment=Alignment.CenterHorizontally) {
                    // One full-width silhouette per surviving ship, with no numeric tally.
                    repeat(row.total){index->
                        if(index>=row.sunk) {
                            Canvas(Modifier.weight(1f).fillMaxWidth().testTag("enemy-ship-${row.length}-$index")
                                .semantics {contentDescription="${row.length} палубы";stateDescription="В бою"}) {
                                val unit=minOf(size.width/(row.length+.15f),size.height/vesselHeightScale(row.length))
                                cartoonVessel(sprites,row.length,unit,center,heightScale=vesselHeightScale(row.length))
                            }
                        }
                    }
                }
            }
        }
    }
}
