package com.notebook.seabattle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag

private val ink=BlackInk
private val paper=NotebookPaper

class MainActivity: ComponentActivity() {
    private lateinit var audio:GameAudio
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window,false)
        hideGameBars()
        audio=GameAudio(this)
        setContent {
            CompositionLocalProvider(LocalGameAudio provides audio) {
            DisposableEffect(audio){audio.startAmbience();onDispose{audio.stopAmbience()}}
            NotebookTheme {
                OceanScene {Box(Modifier.fillMaxSize().displayCutoutPadding()) { NotebookGame() }}
            }
            }
        }
    }
    private fun hideGameBars() {
        androidx.core.view.WindowInsetsControllerCompat(window,window.decorView).apply {
            systemBarsBehavior=androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }
    override fun onResume() {super.onResume();hideGameBars()}
    override fun onWindowFocusChanged(hasFocus:Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if(hasFocus)hideGameBars()
    }
    override fun onStart() { super.onStart();if(::audio.isInitialized) audio.resume() }
    override fun onStop() { if(::audio.isInitialized) audio.pause();super.onStop() }
    override fun onDestroy() { if(::audio.isInitialized) audio.release();super.onDestroy() }
}

@Composable fun NotebookGame() {
    var screen by remember { mutableStateOf("home") }
    val (store,profile)=rememberPlayerProfile()
    when(screen) {
        "name","statistics" -> {CaptainPage(profile,store,screen=="statistics",onBack={screen="home"});return}
        "sound" -> {
            SoundSettings{screen="home"};return
        }
        "solo" -> {SinglePlayerGame(onBack={screen="home"});return}
        "online" -> {SeaEntrance(onBack={screen="friends"}) {OnlineGame(onBack={screen="friends"},onSolo={screen="solo"},onGameFinished={screen="home"})};return}
        "bluetooth" -> {SeaEntrance(onBack={screen="friends"}) {BluetoothGame(onBack={screen="friends"},onGameFinished={screen="home"})};return}
    }
    BackHandler(enabled=screen!="home") {screen="home"}
    BoxWithConstraints(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
    val menuWidth=minOf(maxWidth*.64f,500.dp)
    val menuFont=(maxHeight.value*.073f).coerceIn(22f,32f).sp
    Parchment(Modifier.width(menuWidth).fillMaxHeight(.92f).testTag("home-parchment")) {
        LargeMenuText {
            if(screen=="home")Column(Modifier.fillMaxSize().padding(horizontal=22.dp,vertical=14.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.SpaceEvenly) {
                AdmiralMenuItem("Против компьютера","solo",menuFont){screen="solo"}
                AdmiralMenuItem("С другом","friends",menuFont){screen="friends"}
                AdmiralMenuItem("Имя Адмирала","edit-captain",menuFont){screen="name"}
                AdmiralMenuItem("Побед: ${profile.ledger.wins} · Поражений: ${profile.ledger.losses}","open-statistics",menuFont){screen="statistics"}
                AdmiralMenuItem("Звук","sound",menuFont){screen="sound"}
            } else Column(Modifier.fillMaxSize().padding(22.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                if(screen!="home")Text("С ДРУГОМ",fontSize=38.sp)
                TextButton(onClick={screen="online"}){Text("По интернету")}
                TextButton(onClick={screen="bluetooth"}){Text("По Bluetooth")}
                if(screen!="home")SoundButton()
            }
        }
    }
    if(screen!="home")PirateBackButton(onClick={screen="home"},modifier=Modifier.align(Alignment.TopStart).padding(4.dp))
    }
}

@Composable private fun AdmiralMenuItem(text:String,tag:String,font:androidx.compose.ui.unit.TextUnit,onClick:()->Unit) {
    TextButton(onClick=onClick,modifier=Modifier.fillMaxWidth().testTag(tag),contentPadding=PaddingValues(horizontal=4.dp,vertical=4.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Canvas(Modifier.size(17.dp).testTag("ink-blot-$tag")) {
                val seed=tag.length.toFloat()
                repeat(9){i->val angle=i*2.39f+seed;val r=size.minDimension*(.20f+(i%3)*.025f)
                    drawCircle(BlackInk,r,center+Offset(cos(angle),sin(angle))*size.minDimension*.14f)
                }
                repeat(4){i->val a=i*2.1f+seed;drawCircle(BlackInk,size.minDimension*.035f,center+Offset(cos(a),sin(a))*size.minDimension*.44f)}
            }
            Text(text,fontSize=font,lineHeight=font*1.08f)
        }
    }
}
