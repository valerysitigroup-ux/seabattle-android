package com.notebook.seabattle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ink=Color(0xFF173B88)
private val paper=Color(0xFFFFFCF0)

class MainActivity: ComponentActivity() {
    private lateinit var audio:GameAudio
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio=GameAudio(this)
        setContent {
            CompositionLocalProvider(LocalGameAudio provides audio) {
            MaterialTheme(colorScheme=lightColorScheme(primary=ink,secondary=ink,background=paper,surface=paper)) {
                Box(Modifier.fillMaxSize().background(paper).systemBarsPadding()) { NotebookGame() }
            }
            }
        }
    }
    override fun onStart() { super.onStart();if(::audio.isInitialized) audio.resume() }
    override fun onStop() { if(::audio.isInitialized) audio.pause();super.onStop() }
    override fun onDestroy() { if(::audio.isInitialized) audio.release();super.onDestroy() }
}

@Composable fun NotebookGame() {
    var screen by remember { mutableStateOf("home") }
    when(screen) {
        "solo" -> { SinglePlayerGame(onBack={screen="home"});return }
        "online" -> { OnlineGame(onBack={screen="friends"},onSolo={screen="solo"});return }
        "bluetooth" -> { BluetoothGame(onBack={screen="friends"});return }
        "local" -> { TwoPlayerGame(onBack={screen="friends"});return }
    }
    BackHandler(enabled=screen!="home") { screen="home" }
    Row(Modifier.fillMaxSize().padding(16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(24.dp)) {
    Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("МОРСКОЙ БОЙ",style=MaterialTheme.typography.headlineMedium,color=ink)
        Text("Лист бумаги. Синяя ручка. Ваш флот.",style=MaterialTheme.typography.bodySmall,color=ink.copy(alpha=.7f))
        FleetIllustration(Modifier.fillMaxWidth().height(125.dp))
        SoundButton()
    }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(16.dp)) {
        if(screen=="home") {
            Button(onClick={screen="solo"},modifier=Modifier.fillMaxWidth().height(56.dp)) { Text("ИГРАТЬ",fontSize=20.sp) }
            Text("Против компьютера · без интернета",style=MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick={screen="friends"},modifier=Modifier.fillMaxWidth()) { Text("С другом") }
        } else {
            Text("С ДРУГОМ",style=MaterialTheme.typography.titleLarge)
            Button(onClick={screen="online"},modifier=Modifier.fillMaxWidth()) { Text("По интернету") }
            OutlinedButton(onClick={screen="local"},modifier=Modifier.fillMaxWidth()) { Text("На одном телефоне") }
            OutlinedButton(onClick={screen="bluetooth"},modifier=Modifier.fillMaxWidth()) { Text("По Bluetooth") }
            TextButton(onClick={screen="home"}) { Text("Назад") }
        }
    }
    }
}

private class LocalMatch(first:Board=Board.random(),second:Board=Board.random()) {
    val boards=listOf(first,second)
    var active=0
    var waiting=false
    var winner:Int?=null
    var message="Ход игрока 1"
    fun fire(cell:Cell) {
        if(waiting || winner!=null)return
        when(boards[1-active].shoot(cell)) {
            ShotResult.MISS -> { message="Мимо! Передайте телефон игроку ${2-active}.";waiting=true }
            ShotResult.HIT -> message="Попадание! Стреляйте ещё."
            ShotResult.SUNK -> message="Корабль потоплен! Стреляйте ещё."
            ShotResult.WIN -> {winner=active;message="Победил игрок ${active+1}!"}
            ShotResult.ALREADY_SHOT -> message="Эта клетка уже проверена."
        }
    }
    fun next() { if(waiting) {active=1-active;waiting=false;message="Ход игрока ${active+1}"} }
}

@Composable private fun TwoPlayerGame(onBack:()->Unit) {
    var match by remember { mutableStateOf(LocalMatch()) }
    var revision by remember { mutableIntStateOf(0) }
    var placement by remember { mutableStateOf(false) }
    BackHandler { if(placement)placement=false else onBack() }
    if(placement) {FleetPlacement(onBack={placement=false},onReady={match=LocalMatch(it);revision++;placement=false});return}
    val ownView=remember(match,revision) { match.boards[match.active].battleView(true) }
    val enemyView=remember(match,revision) { match.boards[1-match.active].battleView(false) }
    if(match.waiting) Column(Modifier.fillMaxSize().padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        TextButton(onClick=onBack) {Text("‹ Меню")}
        Text(match.message,style=MaterialTheme.typography.titleLarge)
        Text("Корабли скрыты. Передайте телефон следующему игроку.")
        Button(onClick={match.next();revision++}) {Text("Я игрок ${2-match.active}. Начать ход")}
    } else key(match,match.active) {
        BattleScreen("ИГРОК ${match.active+1}",match.message,ownView,enemyView,match.winner==null,onBack,
            onShot={if(it !in enemyView.blocked) {match.fire(it);revision++}},
            actions={
                TextButton(onClick={match=LocalMatch();revision++}) {Text("Новая")}
                TextButton(onClick={placement=true}) {Text("Флот 1")}
            })
    }
}
