package com.notebook.seabattle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag

private val ink=GreenInk
private val paper=NotebookPaper

class MainActivity: ComponentActivity() {
    private lateinit var audio:GameAudio
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window,false)
        hideGameBars()
        audio=GameAudio(this)
        setContent {
            CompositionLocalProvider(LocalGameAudio provides audio) {
            DisposableEffect(audio){audio.startAmbience();onDispose{audio.stopAmbience()}}
            NotebookTheme {
                OceanScene {Box(Modifier.fillMaxSize().displayCutoutPadding()) { NotebookGame() }}
            }
            }
        }
    }
    private fun hideGameBars() {
        androidx.core.view.WindowInsetsControllerCompat(window,window.decorView).apply {
            systemBarsBehavior=androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }
    override fun onResume() {super.onResume();hideGameBars()}
    override fun onWindowFocusChanged(hasFocus:Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if(hasFocus)hideGameBars()
    }
    override fun onStart() { super.onStart();if(::audio.isInitialized) audio.resume() }
    override fun onStop() { if(::audio.isInitialized) audio.pause();super.onStop() }
    override fun onDestroy() { if(::audio.isInitialized) audio.release();super.onDestroy() }
}

@Composable fun NotebookGame() {
    var screen by remember { mutableStateOf("home") }
    when(screen) {
        "solo" -> {SinglePlayerGame(onBack={screen="home"});return}
        "online" -> {SeaEntrance(onBack={screen="friends"}) {OnlineGame(onBack={screen="friends"},onSolo={screen="solo"},onGameFinished={screen="home"})};return}
        "bluetooth" -> {SeaEntrance(onBack={screen="friends"}) {BluetoothGame(onBack={screen="friends"},onGameFinished={screen="home"})};return}
    }
    BackHandler(enabled=screen!="home") {screen="home"}
    Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
    Parchment(Modifier.widthIn(max=440.dp).fillMaxWidth(.62f).fillMaxHeight(.9f).testTag("home-parchment")) {
        LargeMenuText {
            Column(Modifier.fillMaxSize().padding(22.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                if(screen!="home")Text("С ДРУГОМ",fontSize=38.sp)
                if(screen=="home") {
                    TextButton(onClick={screen="solo"}){Text("Против компьютера",fontSize=36.sp)}
                    TextButton(onClick={screen="friends"}){Text("С другом",fontSize=36.sp)}
                } else {
                    TextButton(onClick={screen="online"}){Text("По интернету")}
                    TextButton(onClick={screen="bluetooth"}){Text("По Bluetooth")}
                }
                if(screen!="home")SoundButton()
            }
        }
    }
    if(screen!="home")PirateBackButton(onClick={screen="home"},modifier=Modifier.align(Alignment.TopStart).padding(4.dp))
    }
}
