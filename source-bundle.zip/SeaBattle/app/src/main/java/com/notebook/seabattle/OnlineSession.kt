package com.notebook.seabattle

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random
import kotlin.concurrent.thread

enum class OnlinePhase { CONNECTING, LOBBY, CHOICE, MANUAL, WAITING, BATTLE, ERROR }
data class OnlinePlayer(val id:String,val name:String,val status:String)
data class GameInvitation(val id:String,val player:OnlinePlayer,val incoming:Boolean)
val LocalOnlineFactory=staticCompositionLocalOf<(Context)->OnlineSession> { { OnlineSession(it) } }

/** Owns one socket outside the UI branches. All published state belongs to the main thread. */
class OnlineSession(context:Context,private val testEndpoint:String?=null) {
    private val playerStore=PlayerStore(context)
    private val sessionKey=java.util.UUID.randomUUID().toString()
    private val prefs=context.applicationContext.getSharedPreferences("captain",Context.MODE_PRIVATE)
    var name by mutableStateOf(prefs.getString("name",null) ?: "Капитан ${Random.nextInt(1000,9999)}");private set
    var id by mutableStateOf("");private set
    var phase by mutableStateOf(OnlinePhase.CONNECTING);private set
    var info by mutableStateOf("Подключаемся к игрокам… Первый запуск может занять около минуты.");private set
    var players by mutableStateOf<List<OnlinePlayer>>(emptyList());private set
    var invitation by mutableStateOf<GameInvitation?>(null);private set
    var room by mutableStateOf("");private set
    var opponent by mutableStateOf("");private set
    var state by mutableStateOf(OnlineState());private set
    var board by mutableStateOf<Board?>(null);private set
    var variants by mutableStateOf<List<Board>>(emptyList());private set
    var selectedVariant by mutableIntStateOf(0);private set
    private val ui=Handler(Looper.getMainLooper())
    private val client=onlineClient()
    private val directoryClient=client.newBuilder().readTimeout(8,TimeUnit.SECONDS).callTimeout(15,TimeUnit.SECONDS).build()
    private var socket:WebSocket?=null
    private val presentingResult get()=phase==OnlinePhase.BATTLE&&state.finished
    @Volatile private var disposed=false
    private fun publish(ws:WebSocket,action:()->Unit) {ui.post {if(!disposed && socket===ws)action()}}
    suspend fun start() {
        if(disposed || socket!=null)return
        phase=OnlinePhase.CONNECTING
        val endpoint=withContext(Dispatchers.IO) {
            if(BuildConfig.DEBUG && testEndpoint=="ws://10.0.2.2:8080")testEndpoint
            else ServerDirectory.usable(BuildConfig.MATCH_SERVER_URL) ?: runCatching {
                directoryClient.newCall(Request.Builder().url(BuildConfig.SERVER_DIRECTORY).build()).execute().use {
                    if(it.isSuccessful) ServerDirectory.usable(JSONObject(it.body?.string() ?: "{}").optString("serverUrl")) else null
                }
            }.getOrNull()
        }
        if(disposed)return
        if(endpoint==null){phase=OnlinePhase.ERROR;info="Не удалось открыть список игроков. Попробуйте ещё раз.";return}
        try {
            socket=client.newWebSocket(Request.Builder().url(endpoint).build(),object:WebSocketListener(){
                override fun onOpen(ws:WebSocket,response:Response)=publish(ws){send(JSONObject().put("type","hello").put("name",name))}
                override fun onMessage(ws:WebSocket,text:String)=publish(ws){
                    try {receive(JSONObject(text))} catch(_:Exception){info="Связь с игровой комнатой прервалась. Подключитесь ещё раз.";phase=OnlinePhase.ERROR;cancelSocket()}
                }
                override fun onFailure(ws:WebSocket,t:Throwable,response:Response?)=publish(ws){socket=null;if(!presentingResult){phase=OnlinePhase.ERROR;info="Не удалось подключиться. Проверьте интернет и попробуйте ещё раз."}}
                override fun onClosing(ws:WebSocket,code:Int,reason:String){ws.close(code,reason)}
                override fun onClosed(ws:WebSocket,code:Int,reason:String)=publish(ws){socket=null;if(!presentingResult){phase=OnlinePhase.ERROR;info="Соединение завершено. Подключитесь ещё раз."}}
            })
        } catch(_:Exception){phase=OnlinePhase.ERROR;info="Не удалось открыть игровую комнату. Попробуйте ещё раз."}
    }
    private fun send(message:JSONObject):Boolean {
        val sent=try {socket?.send(message.toString())==true} catch(_:Exception){false}
        if(!sent&&!disposed){phase=OnlinePhase.ERROR;info="Связь прервалась. Подключитесь ещё раз."}
        return sent
    }
    private fun receive(j:JSONObject) {
        when(j.getString("type")) {
            "welcome"->{id=j.getString("id");name=j.getString("name");prefs.edit().putString("name",name).apply();phase=OnlinePhase.LOBBY;info="Выберите игрока и отправьте приглашение."}
            "presence"->{val a=j.getJSONArray("players");players=(0 until a.length()).map {val p=a.getJSONObject(it);OnlinePlayer(p.getString("id"),p.getString("name"),p.getString("status"))}.filter {it.id!=id}}
            "invitation", "invite_sent"->{val incoming=j.getString("type")=="invitation";val p=j.getJSONObject(if(incoming)"from" else "to");invitation=GameInvitation(j.getString("id"),OnlinePlayer(p.getString("id"),p.getString("name"),"inviting"),incoming);info=if(incoming)"Вас приглашают сыграть" else "Ждём ответа игрока"}
            "invite_closed"->{if(invitation?.id==j.getString("id"))invitation=null;info=when(j.optString("reason")){"declined"->"Игрок отклонил приглашение.";"expired"->"Время приглашения истекло.";"offline"->"Игрок вышел из сети.";else->"Приглашение отменено."}}
            "arrange"->{room=j.getString("room");opponent=j.getJSONObject("opponent").getString("name");state=OnlineState();board=null;variants=listOf(Board.random());selectedVariant=0;invitation=null;phase=OnlinePhase.CHOICE;info="Приглашение принято. Расставьте корабли."}
            "state"->{
                val ready=j.getJSONArray("ready");require(ready.length()==2)
                state=state.snapshot(OnlineState(player=j.getInt("player"),turn=j.getInt("turn"),accepted=listOf(ready.getBoolean(0),ready.getBoolean(1)),finished=j.getBoolean("finished"),ownShots=parseShots(j.getJSONArray("ownShots")),enemyShots=parseShots(j.getJSONArray("enemyShots"))))
                if(state.accepted.all {it})phase=OnlinePhase.BATTLE
                else if(state.fleetAccepted){phase=OnlinePhase.WAITING;info="Ждём, пока $opponent расставит корабли…"}
                if(phase==OnlinePhase.BATTLE)info=when {state.finished->if(state.enemyShots.values.count {it}==20)"Вы победили!" else "Соперник победил";state.turn==state.player->"Ваш ход";else->"Ход соперника"}
                if(state.finished&&room.isNotEmpty()&&opponent.isNotBlank()) {
                    if(state.enemyShots.values.count {it}==20)playerStore.record("online:$sessionKey:$room",opponent,true)
                    else if(state.ownShots.values.count {it}==20)playerStore.record("online:$sessionKey:$room",opponent,false)
                }
            }
            "result", "incoming"->state=state.result(Cell(j.getInt("x"),j.getInt("y")),j.getBoolean("hit"),j.getBoolean("sunk"),j.getString("type")=="incoming")
            // Preserve the finished board until this player's own ending has completed.
            "closed"->{if(!presentingResult){resetRoom();info="Соперник вышел. Выберите новую игру."}}
            "error"->{state=state.copy(pending=null);info="Не удалось выполнить действие. Игрок мог выйти или начать другую партию.";if(id.isEmpty()){cancelSocket();phase=OnlinePhase.ERROR;info="Игровая комната обновляется. Попробуйте через минуту."}}
        }
    }
    fun rename(value:String){send(JSONObject().put("type","hello").put("name",value.trim().take(24)))}
    fun invite(player:OnlinePlayer){send(JSONObject().put("type","invite").put("to",player.id))}
    fun answer(accept:Boolean){val inv=invitation ?: return;send(JSONObject().put("type","answer").put("id",inv.id).put("accept",accept))}
    fun cancelInvite(){val inv=invitation ?: return;send(JSONObject().put("type","cancel_invite").put("id",inv.id))}
    fun selectVariant(index:Int){if(index in variants.indices)selectedVariant=index}
    fun manual(){phase=OnlinePhase.MANUAL}
    fun choice(){phase=OnlinePhase.CHOICE}
    fun ready(fleet:Board){board=fleet;if(send(JSONObject().put("type","fleet").put("ships",fleetJson(fleet)))){phase=OnlinePhase.WAITING;info="Отправляем готовность флота…"}}
    fun shoot(cell:Cell){if(state.canShoot && cell !in state.enemyShots && cell !in surroundingCells(state.enemySunk)){state=state.fire(cell);send(JSONObject().put("type","shot").put("x",cell.x).put("y",cell.y))}}
    private fun resetRoom(){room="";board=null;variants=emptyList();invitation=null;state=OnlineState();phase=OnlinePhase.LOBBY}
    fun leave(){send(JSONObject().put("type","leave"));resetRoom()}
    private fun cancelSocket(){val old=socket;socket=null;thread(name="sea-socket-cancel",isDaemon=true){runCatching{old?.cancel()}}}
    fun close(){
        if(disposed)return
        disposed=true;ui.removeCallbacksAndMessages(null)
        val old=socket;socket=null
        // TLS socket closure may write to the network. Never evict a pool on the UI thread.
        thread(name="sea-online-close",isDaemon=true){
            runCatching{old?.cancel()}
            runCatching{client.dispatcher.cancelAll();client.connectionPool.evictAll()}
            client.dispatcher.executorService.shutdown()
        }
    }
}
internal fun fleetJson(board:Board):JSONArray=JSONArray().apply {board.ships.forEach {ship->put(JSONArray().apply {ship.cells.sortedWith(compareBy<Cell>{it.y}.thenBy{it.x}).forEach {put(JSONArray().put(it.x).put(it.y))}})}}
private fun parseShots(a:JSONArray):Map<Cell,Boolean> = buildMap {for(i in 0 until a.length()){val o=a.getJSONObject(i);val c=Cell(o.getInt("x"),o.getInt("y"));require(c.x in 0..9&&c.y in 0..9);put(c,o.getBoolean("hit"))}}


