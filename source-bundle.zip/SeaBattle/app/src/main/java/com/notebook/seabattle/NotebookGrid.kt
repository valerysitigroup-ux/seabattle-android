package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

private val pen = Color(0xFF173B88)
private val pencilGrid = Color(0xFF9BBCE5)
private val redPen = Color(0xFFCB292D)

/** One canvas per board keeps each multi-cell vessel a continuous silhouette. */
@Composable
fun NotebookGrid(
    ships: List<Set<Cell>>,
    shots: Map<Cell, Boolean>,
    enabled: Boolean,
    pending: Set<Cell> = emptySet(),
    onCell: (Cell) -> Unit
) {
    Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
        Canvas(Modifier.matchParentSize()) {
            val unit = size.width / 10f
            for (i in 0..10) {
                drawLine(pencilGrid, Offset(i * unit, 0f), Offset(i * unit, size.height), .7.dp.toPx())
                drawLine(pencilGrid, Offset(0f, i * unit), Offset(size.width, i * unit), .7.dp.toPx())
            }
            ships.filter { it.isNotEmpty() }.forEach { drawPenShip(it, unit) }
            shots.forEach { (c, hit) ->
                val x = (c.x + .5f) * unit; val y = (c.y + .5f) * unit
                if (hit) {
                    val d = unit * .26f
                    drawLine(redPen, Offset(x-d, y-d), Offset(x+d, y+d), 2.dp.toPx(), StrokeCap.Round)
                    drawLine(redPen, Offset(x+d, y-d), Offset(x-d, y+d), 2.dp.toPx(), StrokeCap.Round)
                } else drawCircle(pen, unit * .085f, Offset(x, y))
            }
            pending.forEach { c ->
                drawCircle(pen.copy(alpha = .6f), unit * .15f,
                    Offset((c.x + .5f) * unit, (c.y + .5f) * unit), style = Stroke(1.dp.toPx()))
            }
        }
        Column(Modifier.fillMaxSize()) {
            repeat(10) { y ->
                Row(Modifier.weight(1f)) {
                    repeat(10) { x ->
                        val cell = Cell(x, y)
                        val label = "${"АБВГДЕЖЗИК"[x]}${y + 1}"
                        val mark = when (shots[cell]) { true -> "попадание"; false -> "мимо"; null -> if (ships.any { cell in it }) "корабль" else "вода" }
                        Box(Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = "$label, $mark" }
                            .clickable(enabled = enabled && cell !in shots && cell !in pending) { onCell(cell) })
                    }
                }
            }
        }
    }
}


private val inkPaths = (1..4).associateWith { length ->
    ShipSketch.shapes(length).map { shape -> shape to PathParser().parsePathString(shape.path).toPath() }
}

private fun DrawScope.drawVessel(length:Int,unit:Float,center:Offset,vertical:Boolean=false) {
    withTransform({
        translate(center.x,center.y)
        if(vertical) rotate(90f,Offset.Zero)
        scale(unit,unit,Offset.Zero)
        translate(-length/2f,-.5f)
    }) {
        inkPaths.getValue(length).forEach { (shape,path) ->
            shape.fill?.let { drawPath(path,Color(it),alpha=shape.alpha) }
            drawPath(path,pen,alpha=shape.alpha,style=Stroke(shape.width,cap=StrokeCap.Round,join=StrokeJoin.Round))
        }
    }
}

private fun DrawScope.drawPenShip(cells:Set<Cell>,unit:Float) {
    drawVessel(cells.size,unit,
        Offset((cells.minOf { it.x }+cells.maxOf { it.x }+1)*unit/2,
            (cells.minOf { it.y }+cells.maxOf { it.y }+1)*unit/2),
        cells.maxOf { it.y }>cells.minOf { it.y })
}

@Composable fun FleetIllustration(modifier:Modifier=Modifier) {
    Canvas(modifier) {
        drawVessel(4,size.width/4.4f,Offset(size.width*.5f,size.height*.25f))
        drawVessel(2,size.width/4.9f,Offset(size.width*.55f,size.height*.73f))
    }
}
