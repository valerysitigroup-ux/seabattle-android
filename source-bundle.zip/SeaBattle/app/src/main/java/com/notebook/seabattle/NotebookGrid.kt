package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

private val pen = Color(0xFF173B88)
private val pencilGrid = Color(0xFF7498BE)
private val redPen = Color(0xFFCB292D)

/** One canvas per board keeps each multi-cell vessel a continuous silhouette. */
@Composable
fun NotebookGrid(
    ships: List<Set<Cell>>,
    shots: Map<Cell, Boolean>,
    enabled: Boolean,
    pending: Set<Cell> = emptySet(),
    sunkShips: List<Set<Cell>> = emptyList(),
    battleEffects: Boolean = false,
    cellInput:Boolean = true,
    onCell: (Cell) -> Unit
) {
    val sprites=LocalPirateSprites.current
    val blocked=remember(sunkShips) { surroundingCells(sunkShips) }
    val wrecks=remember(sunkShips) { sunkShips.flatten().toSet() }
    var previousShots by remember { mutableStateOf(shots.toMap()) }
    var previousSunk by remember { mutableIntStateOf(sunkShips.size) }
    var oldSunk by remember {mutableStateOf(sunkShips.toList())}
    val sinking=remember {mutableStateListOf<BoardSinking>()}
    val marks=remember {mutableStateMapOf<Cell,Animatable<Float,androidx.compose.animation.core.AnimationVector1D>>()}
    val blasts=remember { mutableStateListOf<ImpactBlast>() }
    val scope=rememberCoroutineScope()
    val audio=LocalGameAudio.current
    LaunchedEffect(shots,sunkShips,battleEffects) {
        val newWrecks=sunkShips.filter {it !in oldSunk}
        if(battleEffects) {
            newWrecks.forEach {cells->
                val event=BoardSinking(cells);sinking.add(event)
                scope.launch {try{event.progress.animateTo(1f,tween(3200,easing=LinearEasing))}finally{sinking.remove(event)}}
            }
            val newMarks=(shots.keys-previousShots.keys)+surroundingCells(newWrecks).filter {it !in surroundingCells(oldSunk)}
            newMarks.forEach {cell->
                val ink=Animatable(0f);marks[cell]=ink
                scope.launch {ink.animateTo(1f,tween(1000,easing=LinearEasing));marks.remove(cell)}
            }
        }
        oldSunk=sunkShips.toList()
        val fresh=shots.filter { (cell,_) -> cell !in previousShots }
        val hits=fresh.filterValues {it}.keys
        if(battleEffects && hits.isNotEmpty()) {
            audio?.impact(sunkShips.size>previousSunk)
            hits.forEach { cell ->
                val blast=ImpactBlast(cell)
                blasts.add(blast)
                scope.launch {
                    try { blast.progress.animateTo(1f,tween(700,easing=LinearEasing)) }
                    finally { blasts.remove(blast) }
                }
            }
        }
        if(battleEffects&&fresh.any {!it.value})audio?.splash()
        if(battleEffects)fresh.filterValues {!it}.keys.forEach {cell->
            val splash=ImpactBlast(cell,hit=false);blasts.add(splash)
            scope.launch {try{splash.progress.animateTo(1f,tween(500,easing=LinearEasing))}finally{blasts.remove(splash)}}
        }
        previousShots=shots.toMap();previousSunk=sunkShips.size
    }
    Box(Modifier.fillMaxWidth().aspectRatio(1f).clipToBounds()) {
        Canvas(Modifier.matchParentSize()) {
            val unit = size.width / 10f
            for(y in 0..9)for(x in 0..9) {
                val light=(x+y)%2==0
                drawRect(Brush.verticalGradient(if(light)listOf(Color(0xFFE6F2C7),Color(0xFFC2DDB6)) else listOf(Color(0xFF8BDEE0),Color(0xFF55B7C7)),startY=y*unit,endY=(y+1)*unit),Offset(x*unit,y*unit),Size(unit,unit))
                drawLine(Color.White.copy(alpha=.2f),Offset(x*unit+2f,y*unit+2f),Offset((x+1)*unit-2f,y*unit+2f),1.dp.toPx())
            }
            for (i in 0..10) {
                drawLine(Color(0xFF467E82).copy(alpha=.65f), Offset(i * unit, 0f), Offset(i * unit, size.height), 1.1.dp.toPx())
                drawLine(Color(0xFF467E82).copy(alpha=.65f), Offset(0f, i * unit), Offset(size.width, i * unit), 1.1.dp.toPx())
            }
            drawRect(Color(0xFF8D532F),style=Stroke(5.dp.toPx()))
            drawRect(Color(0xFFFFD18C),topLeft=Offset(2.dp.toPx(),2.dp.toPx()),size=Size(size.width-4.dp.toPx(),size.height-4.dp.toPx()),style=Stroke(1.dp.toPx()))
            ships.filter { it.isNotEmpty() && sinking.none {event->event.cells==it} }.forEach { drawPenShip(sprites,it, unit,it.all { c -> c in wrecks }) }
            blocked.forEach {c->pencilCross(c,unit,muted=true,progress=marks[c]?.value ?: 1f)}
            shots.forEach { (c, hit) ->
                val x = (c.x + .5f) * unit; val y = (c.y + .5f) * unit
                if (hit) {
                    val d = unit * .26f
                    val ink=marks[c]?.value ?: 1f
                    val first=(ink*2).coerceIn(0f,1f);val second=(ink*2-1).coerceIn(0f,1f)
                    if(first>0)drawLine(redPen,Offset(x-d,y-d),Offset(x-d+2*d*first,y-d+2*d*first),unit*.07f,StrokeCap.Round)
                    if(second>0)drawLine(redPen,Offset(x+d,y-d),Offset(x+d-2*d*second,y-d+2*d*second),unit*.07f,StrokeCap.Round)
                } else if(c !in blocked) pencilCross(c,unit,progress=marks[c]?.value ?: 1f)
            }
            pending.forEach { c ->
                drawCircle(pen.copy(alpha = .6f), unit * .15f,
                    Offset((c.x + .5f) * unit, (c.y + .5f) * unit), style = Stroke(1.dp.toPx()))
            }
            blasts.forEach {if(it.hit)drawImpact(it.cell,unit,it.progress.value) else drawSplash(it.cell,unit,it.progress.value)}
            sinking.forEach {drawBoardSinking(sprites,it.cells,unit,it.progress.value)}
        }
        if(sinking.isNotEmpty())Box(Modifier.matchParentSize().testTag("inline-sinking").semantics {stateDescription=sinking.joinToString("; "){"Палуб: ${it.cells.size}. Моряков: ${it.cells.size}"}})
        if(marks.isNotEmpty())Box(Modifier.matchParentSize().testTag("drawing-cross"))
        Column(Modifier.fillMaxSize()) {
            repeat(10) { y ->
                Row(Modifier.weight(1f)) {
                    repeat(10) { x ->
                        val cell = Cell(x, y)
                        val label = "${"АБВГДЕЖЗИК"[x]}${y + 1}"
                        val mark = when {
                            cell in wrecks -> "потопленный корабль"
                            cell in blocked -> "вокруг потопленного корабля, закрыто"
                            shots[cell] == true -> "попадание"
                            shots[cell] == false -> "мимо"
                            ships.any { cell in it } -> "корабль"
                            else -> "вода"
                        }
                        Box(Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = "$label, $mark" }
                            .then(if(cellInput)Modifier.clickable(enabled = enabled && cell !in shots && cell !in pending && cell !in blocked) { onCell(cell) } else Modifier.semantics {onClick {onCell(cell);true}}))
                    }
                }
            }
        }
    }
}

private class BoardSinking(val cells:Set<Cell>,val progress:Animatable<Float,androidx.compose.animation.core.AnimationVector1D> = Animatable(0f))

private class ImpactBlast(val cell:Cell,val progress:Animatable<Float,androidx.compose.animation.core.AnimationVector1D> = Animatable(0f),val hit:Boolean=true)

private fun DrawScope.drawSplash(cell:Cell,unit:Float,p:Float) {
    val center=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit)
    drawOval(Color(0xFFE5FFFF).copy(alpha=1-p),center-Offset(unit*(.15f+p*.35f),unit*.1f),Size(unit*(.3f+p*.7f),unit*.2f),style=Stroke(unit*.04f))
    repeat(8){i->val a=i*Math.PI/4;val d=Offset(cos(a).toFloat(),sin(a).toFloat());drawCircle(Color.White.copy(alpha=1-p),unit*.045f*(1-p),center+d*unit*p*.7f+Offset(0f,-unit*sin(p*Math.PI).toFloat()*.3f))}
}

private fun DrawScope.drawImpact(cell:Cell,unit:Float,progress:Float) {
    val center=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit)
    val fade=(1-progress).coerceIn(0f,1f)
    val star=Path().apply {
        repeat(24){i->val a=i*Math.PI/12;val radius=unit*(if(i%2==0).8f else .3f)*(1+progress*.8f);val p=center+Offset(cos(a).toFloat(),sin(a).toFloat())*radius;if(i==0)moveTo(p.x,p.y) else lineTo(p.x,p.y)}
        close()
    }
    drawPath(star,Color(0xFFFFD735).copy(alpha=fade));drawPath(star,Color(0xFFF06C21).copy(alpha=fade),style=Stroke(unit*.04f))
    drawCircle(Color(0xFF362D29).copy(alpha=fade*.45f),unit*(.22f+progress*.65f),center+Offset(0f,-unit*progress*.25f))
    drawCircle(Color(0xFFFF8A1D).copy(alpha=fade),unit*(.15f+sin(progress*Math.PI).toFloat()*.36f),center)
    drawCircle(Color(0xFFFFEAB0).copy(alpha=fade),unit*(.08f+(1-progress)*.18f),center)
    drawCircle(Color(0xFFEF501D).copy(alpha=fade),unit*(.3f+progress*.8f),center,style=Stroke(unit*.055f))
    repeat(10) { i ->
        val angle=i*Math.PI/5+.13
        val direction=Offset(cos(angle).toFloat(),sin(angle).toFloat())
        val distance=unit*(.2f+progress*(if(i%2==0)1f else .7f))
        drawLine(Color(0xFFFFA725).copy(alpha=fade),center+direction*distance,center+direction*(distance+unit*.18f*fade),unit*.06f,StrokeCap.Round)
    }
}

private fun DrawScope.drawPenShip(sprites:List<androidx.compose.ui.graphics.ImageBitmap>,cells:Set<Cell>,unit:Float,sunk:Boolean=false) {
    cartoonVessel(sprites,cells.size,unit,
        Offset((cells.minOf { it.x }+cells.maxOf { it.x }+1)*unit/2,
            (cells.minOf { it.y }+cells.maxOf { it.y }+1)*unit/2),
        cells.maxOf { it.y }>cells.minOf { it.y },sunk)
    if(sunk) cells.forEach { c ->
        val y=(c.y+.82f)*unit
        drawLine(pencilGrid,Offset((c.x+.06f)*unit,y),Offset((c.x+.94f)*unit,y),unit*.06f,StrokeCap.Round)
    }
}

@Composable fun FleetIllustration(modifier:Modifier=Modifier) {
    val sprites=LocalPirateSprites.current
    Canvas(modifier) {
        cartoonVessel(sprites,4,size.width/4.4f,Offset(size.width*.5f,size.height*.25f))
        cartoonVessel(sprites,2,size.width/4.9f,Offset(size.width*.55f,size.height*.73f))
    }
}
