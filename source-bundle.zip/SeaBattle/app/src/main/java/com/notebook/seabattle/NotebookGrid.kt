package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

private val pen = Color(0xFF173B88)
private val pencilGrid = Color(0xFF9BBCE5)
private val redPen = Color(0xFFCB292D)

/** One canvas per board keeps each multi-cell vessel a continuous silhouette. */
@Composable
fun NotebookGrid(
    ships: List<Set<Cell>>,
    shots: Map<Cell, Boolean>,
    enabled: Boolean,
    pending: Set<Cell> = emptySet(),
    sunkShips: List<Set<Cell>> = emptyList(),
    battleEffects: Boolean = false,
    onCell: (Cell) -> Unit
) {
    val blocked=remember(sunkShips) { surroundingCells(sunkShips) }
    val wrecks=remember(sunkShips) { sunkShips.flatten().toSet() }
    var previousShots by remember { mutableStateOf(shots.toMap()) }
    var previousSunk by remember { mutableIntStateOf(sunkShips.size) }
    val blasts=remember { mutableStateListOf<ImpactBlast>() }
    val scope=rememberCoroutineScope()
    val audio=LocalGameAudio.current
    LaunchedEffect(shots,sunkShips,battleEffects) {
        val hits=shots.filter { (cell,hit) -> hit && previousShots[cell] != true }.keys
        if(battleEffects && hits.isNotEmpty()) {
            audio?.impact(sunkShips.size>previousSunk)
            hits.forEach { cell ->
                val blast=ImpactBlast(cell)
                blasts.add(blast)
                scope.launch {
                    try { blast.progress.animateTo(1f,tween(700,easing=LinearEasing)) }
                    finally { blasts.remove(blast) }
                }
            }
        }
        previousShots=shots.toMap();previousSunk=sunkShips.size
    }
    Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
        Canvas(Modifier.matchParentSize()) {
            val unit = size.width / 10f
            for (i in 0..10) {
                drawLine(pencilGrid, Offset(i * unit, 0f), Offset(i * unit, size.height), .7.dp.toPx())
                drawLine(pencilGrid, Offset(0f, i * unit), Offset(size.width, i * unit), .7.dp.toPx())
            }
            ships.filter { it.isNotEmpty() }.forEach { drawPenShip(it, unit,it.all { c -> c in wrecks }) }
            blocked.forEach { c ->
                val center=Offset((c.x+.5f)*unit,(c.y+.5f)*unit)
                val d=unit*.18f
                drawLine(pen.copy(alpha=.4f),center-Offset(d,d),center+Offset(d,d),1.dp.toPx(),StrokeCap.Round)
                drawLine(pen.copy(alpha=.4f),center+Offset(d,-d),center+Offset(-d,d),1.dp.toPx(),StrokeCap.Round)
            }
            shots.forEach { (c, hit) ->
                val x = (c.x + .5f) * unit; val y = (c.y + .5f) * unit
                if (hit) {
                    val d = unit * .26f
                    drawLine(redPen, Offset(x-d, y-d), Offset(x+d, y+d), 2.dp.toPx(), StrokeCap.Round)
                    drawLine(redPen, Offset(x+d, y-d), Offset(x-d, y+d), 2.dp.toPx(), StrokeCap.Round)
                } else if(c !in blocked) drawCircle(pen, unit * .085f, Offset(x, y))
            }
            pending.forEach { c ->
                drawCircle(pen.copy(alpha = .6f), unit * .15f,
                    Offset((c.x + .5f) * unit, (c.y + .5f) * unit), style = Stroke(1.dp.toPx()))
            }
            blasts.forEach { drawImpact(it.cell,unit,it.progress.value) }
        }
        Column(Modifier.fillMaxSize()) {
            repeat(10) { y ->
                Row(Modifier.weight(1f)) {
                    repeat(10) { x ->
                        val cell = Cell(x, y)
                        val label = "${"АБВГДЕЖЗИК"[x]}${y + 1}"
                        val mark = when {
                            cell in wrecks -> "потопленный корабль"
                            cell in blocked -> "вокруг потопленного корабля, закрыто"
                            shots[cell] == true -> "попадание"
                            shots[cell] == false -> "мимо"
                            ships.any { cell in it } -> "корабль"
                            else -> "вода"
                        }
                        Box(Modifier.weight(1f).fillMaxHeight()
                            .semantics { contentDescription = "$label, $mark" }
                            .clickable(enabled = enabled && cell !in shots && cell !in pending && cell !in blocked) { onCell(cell) })
                    }
                }
            }
        }
    }
}

private class ImpactBlast(val cell:Cell,val progress:Animatable<Float,androidx.compose.animation.core.AnimationVector1D> = Animatable(0f))

private fun DrawScope.drawImpact(cell:Cell,unit:Float,progress:Float) {
    val center=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit)
    val fade=(1-progress).coerceIn(0f,1f)
    drawCircle(Color(0xFF362D29).copy(alpha=fade*.45f),unit*(.22f+progress*.65f),center+Offset(0f,-unit*progress*.25f))
    drawCircle(Color(0xFFFF8A1D).copy(alpha=fade),unit*(.15f+sin(progress*Math.PI).toFloat()*.36f),center)
    drawCircle(Color(0xFFFFEAB0).copy(alpha=fade),unit*(.08f+(1-progress)*.18f),center)
    drawCircle(Color(0xFFEF501D).copy(alpha=fade),unit*(.3f+progress*.8f),center,style=Stroke(unit*.055f))
    repeat(10) { i ->
        val angle=i*Math.PI/5+.13
        val direction=Offset(cos(angle).toFloat(),sin(angle).toFloat())
        val distance=unit*(.2f+progress*(if(i%2==0)1f else .7f))
        drawLine(Color(0xFFFFA725).copy(alpha=fade),center+direction*distance,center+direction*(distance+unit*.18f*fade),unit*.06f,StrokeCap.Round)
    }
}

private val inkPaths = (1..4).associateWith { length ->
    ShipSketch.shapes(length).map { shape -> shape to PathParser().parsePathString(shape.path).toPath() }
}

private fun DrawScope.drawVessel(length:Int,unit:Float,center:Offset,vertical:Boolean=false,sunk:Boolean=false) {
    withTransform({
        translate(center.x,center.y)
        if(vertical) rotate(90f,Offset.Zero)
        scale(unit,unit,Offset.Zero)
        translate(-length/2f,-.5f)
    }) {
        inkPaths.getValue(length).forEach { (shape,path) ->
            shape.fill?.let { drawPath(path,if(sunk) Color(0xFFB9B6A9) else Color(it),alpha=shape.alpha) }
            drawPath(path,if(sunk) Color(0xFF5D6265) else pen,alpha=shape.alpha,style=Stroke(shape.width,cap=StrokeCap.Round,join=StrokeJoin.Round))
        }
    }
}

private fun DrawScope.drawPenShip(cells:Set<Cell>,unit:Float,sunk:Boolean=false) {
    drawVessel(cells.size,unit,
        Offset((cells.minOf { it.x }+cells.maxOf { it.x }+1)*unit/2,
            (cells.minOf { it.y }+cells.maxOf { it.y }+1)*unit/2),
        cells.maxOf { it.y }>cells.minOf { it.y },sunk)
    if(sunk) cells.forEach { c ->
        val y=(c.y+.82f)*unit
        drawLine(pencilGrid,Offset((c.x+.06f)*unit,y),Offset((c.x+.94f)*unit,y),unit*.06f,StrokeCap.Round)
    }
}

@Composable fun FleetIllustration(modifier:Modifier=Modifier) {
    Canvas(modifier) {
        drawVessel(4,size.width/4.4f,Offset(size.width*.5f,size.height*.25f))
        drawVessel(2,size.width/4.9f,Offset(size.width*.55f,size.height*.73f))
    }
}
