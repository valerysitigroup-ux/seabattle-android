package com.notebook.seabattle

/** Cell-based vector artwork, shared by the game renderer and the SVG proof. */
data class InkShape(val path: String, val fill: Long? = null, val width: Float = .024f, val alpha: Float = 1f)

object ShipSketch {
    private val cache = (1..4).associateWith(::build)
    fun shapes(length: Int): List<InkShape> = requireNotNull(cache[length])

    private fun build(length: Int): List<InkShape> = buildList {
        val l=length.toFloat()
        fun line(d:String,w:Float=.024f,a:Float=1f) {add(InkShape(d,width=w,alpha=a))}
        fun plate(d:String,fill:Long=0xFFFFFCF0) {add(InkShape(d,fill=fill))}
        // A shallow stern, raised bow and curved keel: a recognisable side profile.
        plate("M .09 .59 L ${l-.09f} .59 Q ${l-.16f} .72 ${l-.35f} .83 L .28 .83 Q .16 .78 .09 .59 Z",0xFFF3F4ED)
        line("M .21 .70 L ${l-.25f} .70",.012f,.65f)
        line("M .3 .85 Q ${l*.5f} .87 ${l-.36f} .845",.012f,.3f)
        if(length==1) {
            plate("M .25 .58 L .25 .42 L .55 .42 L .65 .58 Z")
            line("M .32 .45 L .43 .45 M .48 .45 L .54 .45",.026f)
            line("M .46 .40 L .46 .21 L .63 .29 L .46 .30",.018f)
            line("M .69 .57 L .69 .48 L .84 .46",.02f)
        } else {
            val bridge=l*.52f
            // Bridge levels, windows and mast, kept distinct from the funnels.
            plate("M ${bridge-.24f} .58 L ${bridge-.24f} .38 L ${bridge+.12f} .38 L ${bridge+.23f} .48 L ${bridge+.23f} .58 Z")
            plate("M ${bridge-.13f} .38 L ${bridge-.13f} .28 L ${bridge+.09f} .28 L ${bridge+.12f} .38 Z")
            line("M ${bridge-.15f} .42 L ${bridge-.08f} .42 M ${bridge-.02f} .42 L ${bridge+.05f} .42 M ${bridge+.11f} .42 L ${bridge+.15f} .45",.022f)
            line("M $bridge .28 L $bridge .10 M ${bridge-.16f} .18 L ${bridge+.15f} .18 M $bridge .10 L ${bridge+.16f} .14 L $bridge .16",.017f)
            line("M ${bridge-.18f} .38 L $bridge .20 L ${bridge+.18f} .38",.01f,.6f)
            val funnel=bridge-.43f
            plate("M ${funnel-.09f} .58 L ${funnel-.09f} .32 L ${funnel+.07f} .32 L ${funnel+.12f} .58 Z")
            line("M ${funnel-.09f} .36 L ${funnel+.08f} .36",.022f)
            if(length>=3) {
                val back=funnel-.29f
                plate("M ${back-.07f} .58 L ${back-.07f} .37 L ${back+.08f} .37 L ${back+.12f} .58 Z")
                line("M ${back-.07f} .41 L ${back+.09f} .41",.018f)
            }
            fun turret(x:Float,forward:Boolean) {
                plate("M ${x-.13f} .58 L ${x-.10f} .47 L ${x+.09f} .47 L ${x+.14f} .58 Z")
                val tip=x+if(forward).35f else -.35f
                val start=x+if(forward).08f else -.08f
                line("M $start .50 L $tip .46 M $start .54 L $tip .50",.02f)
            }
            turret(l-.55f,true)
            if(length>=3)turret(.48f,false)
            if(length==4)turret(l-.99f,true)
            // Deck rails are lighter, so the profile remains readable at phone scale.
            line("M .21 .55 L ${bridge-.56f} .55 M ${bridge+.27f} .55 L ${l-.21f} .55",.01f,.5f)
            for(i in 0 until length*2) {
                val x=.3f+i*.4f
                if(x<l-.3f)line("M $x .55 L $x .59",.01f,.5f)
            }
        }
        for(i in 0 until length*4) {
            val x=.27f+i*.22f
            if(x<l-.3f) {
                line("M $x .75 L ${x+.055f} .80",.012f,.42f)
                line("M $x .65 L ${x+.035f} .65",.022f,.8f)
            }
        }
        // Broken water strokes suggest a pen sketch without obscuring the grid.
        line("M .13 .92 Q .25 .89 .38 .92 M ${l*.55f} .92 Q ${l*.68f} .95 ${l*.81f} .92",.013f,.28f)
    }
}
