package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import kotlin.math.roundToInt

@Composable internal fun SoundSettings(onBack:()->Unit) {
    val audio=LocalGameAudio.current ?: return
    BackHandler(onBack=onBack)
    Parchment(Modifier.fillMaxSize().testTag("sound-settings")) {
        Column(Modifier.fillMaxSize().padding(horizontal=58.dp,vertical=16.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Звук",fontSize=36.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(18.dp)) {
                TextButton(onClick={audio.enabled=!audio.enabled}){Text(if(audio.enabled)"Звук: вкл" else "Звук: выкл")}
                TextButton(onClick={audio.setGulls(!audio.gullsEnabled)}){Text(if(audio.gullsEnabled)"Чайки: вкл" else "Чайки: выкл")}
            }
            GameSound.entries.forEach {sound->
                Column(Modifier.widthIn(max=600.dp).fillMaxWidth().padding(vertical=6.dp)) {
                    Text("${sound.title}: ${(audio.level(sound)*100).roundToInt()}%",fontSize=24.sp)
                    Slider(audio.level(sound),{audio.updateLevel(sound,it)},modifier=Modifier.fillMaxWidth().testTag("sound-level-${sound.key}").semantics {contentDescription=sound.title})
                }
            }
        }
        PirateBackButton(onClick=onBack,modifier=Modifier.align(Alignment.TopStart).padding(4.dp))
    }
}

@Composable internal fun SoundSettingsDialog(onBack:()->Unit) {
    Dialog(onDismissRequest=onBack,properties=DialogProperties(usePlatformDefaultWidth=false,decorFitsSystemWindows=false)) {
        val view=LocalView.current
        DisposableEffect(view) {
            val window=(view.parent as? DialogWindowProvider)?.window
            window?.let {androidx.core.view.WindowInsetsControllerCompat(it,view).apply {
                systemBarsBehavior=androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }}
            onDispose{}
        }
        SoundSettings(onBack)
    }
}
