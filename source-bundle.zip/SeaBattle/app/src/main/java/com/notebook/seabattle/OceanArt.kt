package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import kotlin.math.*

@Composable fun OceanScene(content:@Composable BoxScope.()->Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.cartoon_sea_v17),null,Modifier.matchParentSize(),contentScale=ContentScale.Crop)
        val sea=rememberInfiniteTransition(label="ocean")
        val phase by sea.animateFloat(0f,1f,infiniteRepeatable(tween(6000,easing=LinearEasing)),label="foam")
        Canvas(Modifier.matchParentSize()) {
            repeat(6) { i ->
                val x=size.width*((i*.21f+phase*.06f)%1f)
                val y=size.height*(.55f+(i%3)*.18f)+sin(phase*2*PI+i).toFloat()*5f
                drawArc(Color.White.copy(alpha=.12f),10f,150f,false,Offset(x,y),Size(size.width*.09f,12f),style=Stroke(2f))
            }
        }
        content()
    }
}

private val HullInk=Color(0xFF422A2B)
/** Cell coordinates keep the ship footprint identical to the validated fleet. */
/** Shaded timber, visible deck, rigging and billowing canvas give the frigate a three-quarter view. */
internal fun DrawScope.cartoonVessel(length:Int,unit:Float,center:Offset,vertical:Boolean=false,wreck:Boolean=false) {
    withTransform({translate(center.x,center.y);if(vertical)rotate(90f,Offset.Zero);scale(unit,unit,Offset.Zero);translate(-length/2f,-.5f)}) {
        val l=length.toFloat();val ink=Color(0xFF35261E)
        val hull=Path().apply {moveTo(.06f,.51f);lineTo(.29f,.43f);lineTo(l-.19f,.43f);lineTo(l-.035f,.5f);quadraticTo(l-.19f,.82f,l-.43f,.9f);lineTo(.29f,.88f);quadraticTo(.09f,.73f,.06f,.51f);close()}
        drawOval(Color(0xFF033F52).copy(alpha=.35f),Offset(.03f,.79f),Size(l-.04f,.19f))
        drawPath(hull,Brush.verticalGradient(if(wreck)listOf(Color(0xFF64999B),Color(0xFF24596A)) else listOf(Color(0xFFB67C42),Color(0xFF744322),Color(0xFF36291E)),startY=.44f,endY=.93f))
        drawPath(hull,ink,style=Stroke(.025f,join=StrokeJoin.Round))
        for(row in 0..4) {
            val y=.59f+row*.055f
            drawLine((if(wreck)Color(0xFF356E7D) else Color(0xFFDBAF72)).copy(alpha=.65f),Offset(.18f+row*.018f,y),Offset(l-.21f-row*.035f,y+.04f),.012f)
            repeat(max(2,length*3)){i->val x=.24f+i*(l-.5f)/max(2,length*3);drawLine(ink.copy(alpha=.5f),Offset(x,y),Offset(x+.018f,y+.04f),.007f)}
        }
        if(!wreck) {
            val deck=Path().apply {moveTo(.07f,.51f);lineTo(.29f,.33f);quadraticTo(l*.6f,.27f,l-.2f,.37f);lineTo(l-.035f,.5f);lineTo(l-.37f,.65f);lineTo(.27f,.66f);close()}
            drawPath(deck,Brush.verticalGradient(listOf(Color(0xFFF1D5A2),Color(0xFFB6834E)),startY=.31f,endY=.67f))
            clipPath(deck) {
                repeat(8){i->val y=.32f+i*.045f;drawLine(Color(0xFF6D472A).copy(alpha=.55f),Offset(.05f,y),Offset(l-.05f,y+.025f),.009f)}
                repeat(length*4){i->val x=.18f+i*.22f;drawLine(Color(0xFF8A5D32).copy(alpha=.4f),Offset(x,.32f),Offset(x+.025f,.65f),.007f)}
            }
            drawPath(deck,ink,style=Stroke(.027f,join=StrokeJoin.Round))
            drawLine(Color(0xFFE5BA72),Offset(.18f,.64f),Offset(l-.3f,.64f),.035f,StrokeCap.Round)
            val stern=Path().apply {moveTo(.085f,.52f);lineTo(.1f,.36f);lineTo(.3f,.26f);lineTo(.5f,.34f);lineTo(.46f,.53f);close()}
            drawPath(stern,Brush.horizontalGradient(listOf(Color(0xFF4B3022),Color(0xFFA8753F)),startX=.08f,endX=.5f));drawPath(stern,ink,style=Stroke(.02f))
            drawLine(Color(0xFFEDCC85),Offset(.12f,.35f),Offset(.45f,.34f),.025f)
            repeat(2){i->drawRect(Color(0xFFD7B259),Offset(.17f+i*.13f,.38f),Size(.075f,.09f));drawLine(ink,Offset(.207f+i*.13f,.38f),Offset(.207f+i*.13f,.47f),.01f)}
            repeat(max(2,length*2)) {i->
                val x=.27f+i*(l-.57f)/max(1,length*2-1);val y=.735f
                drawRect(ink,Offset(x-.05f,y-.045f),Size(.1f,.1f));drawLine(Color(0xFF313638),Offset(x,y),Offset(x+.055f,y+.026f),.045f,StrokeCap.Round)
                drawLine(Color(0xFF929590),Offset(x,y-.018f),Offset(x+.045f,y+.008f),.009f,StrokeCap.Round)
            }
            repeat(length+2){i->val x=.21f+i*(l-.5f)/(length+1);drawLine(ink,Offset(x,.59f),Offset(x,.48f),.014f)}
            drawLine(Color(0xFF70482B),Offset(.18f,.49f),Offset(l-.24f,.48f),.025f)
            val masts=if(length>=3)3 else length
            repeat(masts){n->
                val x=.22f+(n+.43f)*(l-.55f)/masts;val top=.02f+(n%2)*.025f
                drawLine(Color(0xFF49341F),Offset(x,.56f),Offset(x,top),.028f,StrokeCap.Round)
                drawLine(Color(0xFFE2B875),Offset(x-.008f,.53f),Offset(x-.008f,top+.02f),.007f)
                drawLine(ink.copy(alpha=.75f),Offset(x,top+.035f),Offset((x-.38f).coerceAtLeast(.08f),.61f),.008f)
                drawLine(ink.copy(alpha=.65f),Offset(x,top+.035f),Offset((x+.4f).coerceAtMost(l-.12f),.61f),.008f)
                val sw=minOf(.75f,(l-.3f)/masts*.76f)
                for(level in 0..1) {
                    val sy=top+.055f+level*.19f;val width=sw*(if(level==0).75f else 1f)
                    val sail=Path().apply {moveTo(x-width*.42f,sy);quadraticTo(x+width*.3f,sy+.015f,x+width*.56f,sy+.03f);quadraticTo(x+width*.69f,sy+.13f,x+width*.46f,sy+.2f);quadraticTo(x,sy+.15f,x-width*.42f,sy+.16f);quadraticTo(x-width*.32f,sy+.07f,x-width*.42f,sy);close()}
                    drawPath(sail,Brush.horizontalGradient(listOf(Color(0xFFB39B70),Color(0xFFFFF1CE),Color(0xFFE1C99D),Color(0xFFA18B65)),startX=x-width*.42f,endX=x+width*.56f))
                    drawPath(sail,ink.copy(alpha=.85f),style=Stroke(.012f))
                    for(seam in 0..2){val sx=x-width*.28f+seam*width*.22f;drawLine(Color(0xFF8E7C5C).copy(alpha=.45f),Offset(sx,sy+.035f),Offset(sx+.035f,sy+.15f),.006f)}
                    drawLine(ink,Offset(x-width*.48f,sy),Offset(x+width*.59f,sy+.025f),.018f,StrokeCap.Round)
                }
                val flag=Path().apply {moveTo(x,top);lineTo(x+.2f,top+.015f);lineTo(x+.14f,top+.06f);lineTo(x+.025f,top+.075f);close()}
                drawPath(flag,Color(0xFF161B23));pirateSkull(Offset(x+.09f,top+.035f),.018f)
            }
            drawLine(Color(0xFF73502D),Offset(l-.28f,.48f),Offset(l-.01f,.22f),.03f,StrokeCap.Round)
            drawLine(Color(0xFFD7B477),Offset(l-.27f,.46f),Offset(l-.01f,.2f),.009f)
            drawLine(ink.copy(alpha=.7f),Offset(l-.04f,.23f),Offset(l-.55f,.59f),.008f)
            drawCircle(ink,.047f,Offset(l*.52f,.56f));drawCircle(Color(0xFFC69B55),.027f,Offset(l*.52f,.56f))
        } else drawLine(ink.copy(alpha=.55f),Offset(l*.5f,.61f),Offset(l*.58f,.34f),.025f)
        drawArc(Color(0xFFD9FFFF).copy(alpha=if(wreck).3f else .7f),0f,180f,false,Offset(.06f,.83f),Size(l-.13f,.12f),style=Stroke(.02f,cap=StrokeCap.Round))
    }
}

internal fun DrawScope.pencilCross(cell:Cell,unit:Float,muted:Boolean=false,progress:Float=1f) {
    val c=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit);val d=unit*.28f
    val color=Color(0xFF7434DC).copy(alpha=if(muted).72f else 1f)
    val first=(progress*2).coerceIn(0f,1f);val second=(progress*2-1).coerceIn(0f,1f)
    repeat(3) { i->
        val j=(i-1)*unit*.025f;val wiggle=((cell.x*7+cell.y*3+i)%5-2)*unit*.012f
        val ink=color.copy(alpha=color.alpha*(if(i==1)1f else .45f))
        val a=c+Offset(-d+j,-d+wiggle);val b=c+Offset(d+j,d-wiggle)
        val e=c+Offset(-d+j,d+wiggle);val f=c+Offset(d+j,-d-wiggle)
        if(first>0)drawLine(ink,a,a+(b-a)*first,unit*.065f,StrokeCap.Round)
        if(second>0)drawLine(ink,e,e+(f-e)*second,unit*.065f,StrokeCap.Round)
    }
}

internal fun DrawScope.pirateSkull(c:Offset,r:Float) {
    val bone=Color(0xFFFFF0CB)
    drawLine(bone,c+Offset(-r,r*.8f),c+Offset(r,r*1.65f),r*.25f,StrokeCap.Round)
    drawLine(bone,c+Offset(r,r*.8f),c+Offset(-r,r*1.65f),r*.25f,StrokeCap.Round)
    drawOval(bone,c-Offset(r,r*.9f),Size(2*r,1.6f*r))
    drawRect(bone,c+Offset(-r*.5f,r*.25f),Size(r,r*.65f))
    drawCircle(HullInk,r*.24f,c+Offset(-r*.38f,-r*.12f));drawCircle(HullInk,r*.24f,c+Offset(r*.38f,-r*.12f))
}
