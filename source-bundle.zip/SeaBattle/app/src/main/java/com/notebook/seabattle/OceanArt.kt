package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import kotlin.math.*

@Composable fun OceanScene(content:@Composable BoxScope.()->Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.cartoon_sea_v17),null,Modifier.matchParentSize(),contentScale=ContentScale.Crop)
        val sea=rememberInfiniteTransition(label="ocean")
        val phase by sea.animateFloat(0f,1f,infiniteRepeatable(tween(6000,easing=LinearEasing)),label="foam")
        Canvas(Modifier.matchParentSize()) {
            repeat(6) { i ->
                val x=size.width*((i*.21f+phase*.06f)%1f)
                val y=size.height*(.55f+(i%3)*.18f)+sin(phase*2*PI+i).toFloat()*5f
                drawArc(Color.White.copy(alpha=.12f),10f,150f,false,Offset(x,y),Size(size.width*.09f,12f),style=Stroke(2f))
            }
        }
        content()
    }
}

private val HullInk=Color(0xFF422A2B)
/** Cell coordinates keep the ship footprint identical to the validated fleet. */
internal fun DrawScope.cartoonVessel(length:Int,unit:Float,center:Offset,vertical:Boolean=false,wreck:Boolean=false) {
    withTransform({translate(center.x,center.y);if(vertical)rotate(90f,Offset.Zero);scale(unit,unit,Offset.Zero);translate(-length/2f,-.5f)}) {
        val l=length.toFloat()
        val hull=Path().apply {moveTo(.06f,.58f);quadraticTo(l*.48f,.43f,l-.05f,.46f);quadraticTo(l-.13f,.82f,l-.39f,.9f);lineTo(.3f,.9f);quadraticTo(.11f,.81f,.06f,.58f);close()}
        drawOval(Color(0xFF024C62).copy(alpha=if(wreck).25f else .28f),Offset(.03f,.78f),Size(l-.04f,.19f))
        drawPath(hull,Brush.verticalGradient(if(wreck)listOf(Color(0xFF437F83),Color(0xFF1A5767)) else listOf(Color(0xFFFFCE75),Color(0xFFC66E32),Color(0xFF70432F)),startY=.46f,endY=.94f))
        drawPath(hull,HullInk,style=Stroke(.045f,cap=StrokeCap.Round,join=StrokeJoin.Round))
        drawLine(if(wreck)Color(0xFF679B9D) else Color(0xFFFFDE91),Offset(.17f,.61f),Offset(l-.16f,.52f),.045f,StrokeCap.Round)
        for(row in 0..2)drawLine(HullInk.copy(alpha=.5f),Offset(.25f,.7f+row*.065f),Offset(l-.34f,.64f+row*.08f),.018f)
        if(!wreck) {
            val mast=l*.5f
            drawLine(HullInk,Offset(mast,.57f),Offset(mast,.08f),.05f,StrokeCap.Round)
            val sail=Path().apply {moveTo(mast+.04f,.13f);quadraticTo(min(l-.13f,mast+.68f),.11f,min(l-.12f,mast+.68f),.43f);quadraticTo(mast+.3f,.35f,mast+.04f,.47f);close()}
            drawPath(sail,Brush.horizontalGradient(listOf(Color(0xFFFFF4C9),Color(0xFFE3C894)),startX=mast,endX=mast+.7f))
            drawPath(sail,HullInk,style=Stroke(.03f,join=StrokeJoin.Round))
            drawLine(Color(0xFFE05739),Offset(mast+.15f,.16f),Offset(mast+.22f,.42f),.075f)
            val flag=Path().apply {moveTo(mast,.06f);lineTo(mast-.25f,.1f);lineTo(mast,.18f);close()}
            drawPath(flag,Color(0xFFEC5735));drawPath(flag,HullInk,style=Stroke(.025f))
            repeat(length) { i ->
                val x=.38f+i*(l-.7f)/max(1,length-1)
                drawCircle(HullInk,.061f,Offset(x,.75f));drawCircle(Color(0xFFFFD477),.033f,Offset(x-.009f,.74f))
            }
            drawLine(HullInk,Offset(.18f,.62f),Offset(.11f,.4f),.04f,StrokeCap.Round)
            drawLine(HullInk,Offset(l-.16f,.53f),Offset(l-.07f,.33f),.04f,StrokeCap.Round)
            repeat(3){i->val x=.25f+i*(l-.5f)/2;drawLine(Color(0xFFF8E0A5),Offset(x,.56f),Offset(x+.12f,.85f),.017f)}
        } else {
            drawLine(HullInk.copy(alpha=.7f),Offset(l*.5f,.6f),Offset(l*.58f,.3f),.035f)
        }
        drawArc(Color(0xFFE2FFFF).copy(alpha=if(wreck).3f else .8f),0f,180f,false,Offset(.08f,.81f),Size(l-.16f,.16f),style=Stroke(.025f,cap=StrokeCap.Round))
    }
}

internal fun DrawScope.pencilCross(cell:Cell,unit:Float,muted:Boolean=false) {
    val c=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit);val d=unit*.23f
    val color=Color(0xFF3D4554).copy(alpha=if(muted).42f else .84f)
    repeat(3) { i->
        val j=(i-1)*unit*.025f;val wiggle=((cell.x*7+cell.y*3+i)%5-2)*unit*.012f
        drawLine(color.copy(alpha=color.alpha*(if(i==1)1f else .45f)),c+Offset(-d+j,-d+wiggle),c+Offset(d+j,d-wiggle),unit*.027f,StrokeCap.Round)
        drawLine(color.copy(alpha=color.alpha*(if(i==1)1f else .45f)),c+Offset(-d+j,d+wiggle),c+Offset(d+j,-d-wiggle),unit*.027f,StrokeCap.Round)
    }
}
