package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import kotlin.math.*

@Composable fun OceanScene(content:@Composable BoxScope.()->Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.cartoon_sea_v17),null,Modifier.matchParentSize(),contentScale=ContentScale.Crop)
        val sea=rememberInfiniteTransition(label="ocean")
        val phase by sea.animateFloat(0f,1f,infiniteRepeatable(tween(6000,easing=LinearEasing)),label="foam")
        Canvas(Modifier.matchParentSize()) {
            repeat(6) { i ->
                val x=size.width*((i*.21f+phase*.06f)%1f)
                val y=size.height*(.55f+(i%3)*.18f)+sin(phase*2*PI+i).toFloat()*5f
                drawArc(Color.White.copy(alpha=.12f),10f,150f,false,Offset(x,y),Size(size.width*.09f,12f),style=Stroke(2f))
            }
        }
        content()
    }
}

private val HullInk=Color(0xFF422A2B)
internal val LocalPirateSprites=staticCompositionLocalOf<List<ImageBitmap>> {emptyList()}

internal fun vesselHeightScale(length:Int)=if(length==4)1.28f else .96f

/** Keep taller rigging inside board edges before the sinking movement begins. */
internal fun DrawScope.boardVesselCenter(cells:Set<Cell>,unit:Float):Offset {
    val vertical=cells.map {it.x}.distinct().size==1&&cells.size>1
    val center=Offset((cells.minOf {it.x}+cells.maxOf {it.x}+1)*unit/2,(cells.minOf {it.y}+cells.maxOf {it.y}+1)*unit/2)
    val half=unit*vesselHeightScale(cells.size)/2
    return if(vertical)center.copy(x=center.x.coerceIn(half,size.width-half)) else center.copy(y=center.y.coerceIn(half,size.height-half))
}

/** A full continuous sprite occupies the same cells as the validated ship. */
internal fun DrawScope.cartoonVessel(sprites:List<ImageBitmap>,length:Int,unit:Float,center:Offset,vertical:Boolean=false,wreck:Boolean=false,heightScale:Float=.96f) {
    val ship=sprites.getOrNull(length-1) ?: return
    val width=unit*length*.96f;val height=unit*heightScale
    withTransform({translate(center.x,center.y);if(vertical)rotate(90f,Offset.Zero)}) {
        drawOval(Color(0xFF063F51).copy(alpha=.25f),Offset(-width/2,height*.25f),Size(width,height*.28f))
        drawImage(ship,srcSize=androidx.compose.ui.unit.IntSize(ship.width,ship.height),
            dstOffset=androidx.compose.ui.unit.IntOffset((-width/2).roundToInt(),(-height/2).roundToInt()),
            dstSize=androidx.compose.ui.unit.IntSize(width.roundToInt().coerceAtLeast(1),height.roundToInt().coerceAtLeast(1)),
            alpha=if(wreck).62f else 1f,
            colorFilter=if(wreck)ColorFilter.tint(Color(0xFF31798B).copy(alpha=.72f),BlendMode.SrcAtop) else null,
            filterQuality=FilterQuality.Medium)
        drawArc(Color(0xFFE0FFFF).copy(alpha=if(wreck).25f else .55f),0f,180f,false,
            Offset(-width/2,height*.34f),Size(width,height*.15f),style=Stroke(unit*.016f,cap=StrokeCap.Round))
    }
}

internal fun DrawScope.pencilCross(cell:Cell,unit:Float,muted:Boolean=false,progress:Float=1f) {
    val c=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit);val d=unit*.28f
    val color=Color(0xFF7434DC).copy(alpha=if(muted).72f else 1f)
    val first=(progress*2).coerceIn(0f,1f);val second=(progress*2-1).coerceIn(0f,1f)
    repeat(3) { i->
        val j=(i-1)*unit*.025f;val wiggle=((cell.x*7+cell.y*3+i)%5-2)*unit*.012f
        val ink=color.copy(alpha=color.alpha*(if(i==1)1f else .45f))
        val a=c+Offset(-d+j,-d+wiggle);val b=c+Offset(d+j,d-wiggle)
        val e=c+Offset(-d+j,d+wiggle);val f=c+Offset(d+j,-d-wiggle)
        if(first>0)drawLine(ink,a,a+(b-a)*first,unit*.065f,StrokeCap.Round)
        if(second>0)drawLine(ink,e,e+(f-e)*second,unit*.065f,StrokeCap.Round)
    }
}

internal fun DrawScope.pirateSkull(c:Offset,r:Float) {
    val bone=Color(0xFFFFF0CB)
    drawLine(bone,c+Offset(-r,r*.8f),c+Offset(r,r*1.65f),r*.25f,StrokeCap.Round)
    drawLine(bone,c+Offset(r,r*.8f),c+Offset(-r,r*1.65f),r*.25f,StrokeCap.Round)
    drawOval(bone,c-Offset(r,r*.9f),Size(2*r,1.6f*r))
    drawRect(bone,c+Offset(-r*.5f,r*.25f),Size(r,r*.65f))
    drawCircle(HullInk,r*.24f,c+Offset(-r*.38f,-r*.12f));drawCircle(HullInk,r*.24f,c+Offset(r*.38f,-r*.12f))
}
