package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import kotlin.math.*

@Composable fun OceanScene(content:@Composable BoxScope.()->Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.cartoon_sea_v17),null,Modifier.matchParentSize(),contentScale=ContentScale.Crop)
        val sea=rememberInfiniteTransition(label="ocean")
        val phase by sea.animateFloat(0f,1f,infiniteRepeatable(tween(6000,easing=LinearEasing)),label="foam")
        Canvas(Modifier.matchParentSize()) {
            repeat(6) { i ->
                val x=size.width*((i*.21f+phase*.06f)%1f)
                val y=size.height*(.55f+(i%3)*.18f)+sin(phase*2*PI+i).toFloat()*5f
                drawArc(Color.White.copy(alpha=.12f),10f,150f,false,Offset(x,y),Size(size.width*.09f,12f),style=Stroke(2f))
            }
        }
        content()
    }
}

private val HullInk=Color(0xFF422A2B)
/** Cell coordinates keep the ship footprint identical to the validated fleet. */
internal fun DrawScope.cartoonVessel(length:Int,unit:Float,center:Offset,vertical:Boolean=false,wreck:Boolean=false) {
    withTransform({translate(center.x,center.y);if(vertical)rotate(90f,Offset.Zero);scale(unit,unit,Offset.Zero);translate(-length/2f,-.5f)}) {
        val l=length.toFloat()
        val hull=Path().apply {moveTo(.06f,.58f);quadraticTo(l*.48f,.43f,l-.05f,.46f);quadraticTo(l-.13f,.82f,l-.39f,.9f);lineTo(.3f,.9f);quadraticTo(.11f,.81f,.06f,.58f);close()}
        drawOval(Color(0xFF024C62).copy(alpha=if(wreck).25f else .28f),Offset(.03f,.78f),Size(l-.04f,.19f))
        drawPath(hull,Brush.verticalGradient(if(wreck)listOf(Color(0xFF437F83),Color(0xFF1A5767)) else listOf(Color(0xFFFFCE75),Color(0xFFC66E32),Color(0xFF70432F)),startY=.46f,endY=.94f))
        drawPath(hull,HullInk,style=Stroke(.045f,cap=StrokeCap.Round,join=StrokeJoin.Round))
        drawLine(if(wreck)Color(0xFF679B9D) else Color(0xFFFFDE91),Offset(.17f,.61f),Offset(l-.16f,.52f),.045f,StrokeCap.Round)
        for(row in 0..2)drawLine(HullInk.copy(alpha=.5f),Offset(.25f,.7f+row*.065f),Offset(l-.34f,.64f+row*.08f),.018f)
        if(!wreck) {
            // Raised deck and bevelled gunwale give the hull depth at board scale.
            val deck=Path().apply {moveTo(.08f,.57f);lineTo(.3f,.43f);lineTo(l-.21f,.37f);lineTo(l-.05f,.46f);lineTo(l-.3f,.61f);lineTo(.28f,.68f);close()}
            drawPath(deck,Brush.verticalGradient(listOf(Color(0xFFF9CF83),Color(0xFFB87439)),startY=.37f,endY=.68f))
            drawPath(deck,HullInk,style=Stroke(.035f,join=StrokeJoin.Round))
            drawLine(Color(0xFFFFE7A2),Offset(.24f,.66f),Offset(l-.25f,.6f),.055f,StrokeCap.Round)
            val masts=min(length,3)
            repeat(masts) { n ->
                val mast=if(masts==1).38f else .31f+n*(l-.94f)/(masts-1)
                val width=if(length==1).42f else .55f
                drawLine(HullInk,Offset(mast,.59f),Offset(mast,.025f),.045f,StrokeCap.Round)
                drawLine(Color(0xFFF3C37C),Offset(mast-.012f,.55f),Offset(mast-.012f,.06f),.012f)
                drawLine(HullInk.copy(alpha=.7f),Offset(mast,.07f),Offset((mast+width).coerceAtMost(l-.12f),.58f),.012f)
                val sail=Path().apply {moveTo(mast+.025f,.085f);quadraticTo(mast+width*.9f,.035f,mast+width,.38f);quadraticTo(mast+width*.5f,.34f,mast+.025f,.47f);close()}
                drawPath(sail,Brush.horizontalGradient(listOf(Color(0xFF1D2030),Color(0xFF515269),Color(0xFF181C2A)),startX=mast,endX=mast+width))
                drawPath(sail,HullInk,style=Stroke(.025f,join=StrokeJoin.Round))
                drawLine(Color(0xFF84818C),Offset(mast+.07f,.12f),Offset(mast+.08f,.4f),.012f)
                pirateSkull(Offset(mast+width*.5f,.25f),width*.18f)
                val flag=Path().apply {moveTo(mast,.02f);lineTo(mast-.2f,.04f);lineTo(mast-.13f,.09f);lineTo(mast,.12f);close()}
                drawPath(flag,Color(0xFFEC4037));drawPath(flag,HullInk,style=Stroke(.016f))
            }
            repeat(length) { i ->
                val x=.37f+i*(l-.7f)/max(1,length-1)
                drawCircle(Color(0xFFFFC351),.079f,Offset(x,.77f))
                drawCircle(HullInk,.057f,Offset(x,.77f))
                drawLine(Color(0xFF303341),Offset(x,.765f),Offset(x+.065f,.79f),.065f,StrokeCap.Round)
                drawLine(Color(0xFF949599),Offset(x,.743f),Offset(x+.05f,.768f),.012f,StrokeCap.Round)
            }
            drawLine(HullInk,Offset(.18f,.62f),Offset(.1f,.37f),.055f,StrokeCap.Round)
            drawLine(Color(0xFFFFCD62),Offset(l-.19f,.57f),Offset(l-.055f,.3f),.06f,StrokeCap.Round)
            drawLine(HullInk,Offset(l-.17f,.56f),Offset(l-.04f,.29f),.025f,StrokeCap.Round)
            drawLine(Color(0xFF5F3428),Offset(.3f,.88f),Offset(l-.4f,.88f),.045f,StrokeCap.Round)
        } else {
            drawLine(HullInk.copy(alpha=.7f),Offset(l*.5f,.6f),Offset(l*.58f,.3f),.035f)
        }
        drawArc(Color(0xFFE2FFFF).copy(alpha=if(wreck).3f else .8f),0f,180f,false,Offset(.08f,.81f),Size(l-.16f,.16f),style=Stroke(.025f,cap=StrokeCap.Round))
    }
}

internal fun DrawScope.pencilCross(cell:Cell,unit:Float,muted:Boolean=false) {
    val c=Offset((cell.x+.5f)*unit,(cell.y+.5f)*unit);val d=unit*.28f
    val color=Color(0xFF7434DC).copy(alpha=if(muted).72f else 1f)
    repeat(3) { i->
        val j=(i-1)*unit*.025f;val wiggle=((cell.x*7+cell.y*3+i)%5-2)*unit*.012f
        drawLine(color.copy(alpha=color.alpha*(if(i==1)1f else .45f)),c+Offset(-d+j,-d+wiggle),c+Offset(d+j,d-wiggle),unit*.065f,StrokeCap.Round)
        drawLine(color.copy(alpha=color.alpha*(if(i==1)1f else .45f)),c+Offset(-d+j,d+wiggle),c+Offset(d+j,-d-wiggle),unit*.027f,StrokeCap.Round)
    }
}

private fun DrawScope.pirateSkull(c:Offset,r:Float) {
    val bone=Color(0xFFFFF0CB)
    drawLine(bone,c+Offset(-r,r*.8f),c+Offset(r,r*1.65f),r*.25f,StrokeCap.Round)
    drawLine(bone,c+Offset(r,r*.8f),c+Offset(-r,r*1.65f),r*.25f,StrokeCap.Round)
    drawOval(bone,c-Offset(r,r*.9f),Size(2*r,1.6f*r))
    drawRect(bone,c+Offset(-r*.5f,r*.25f),Size(r,r*.65f))
    drawCircle(HullInk,r*.24f,c+Offset(-r*.38f,-r*.12f));drawCircle(HullInk,r*.24f,c+Offset(r*.38f,-r*.12f))
}
