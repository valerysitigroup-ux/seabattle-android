package com.notebook.seabattle

import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import kotlin.math.*

/** Moving water stays below fixed game coordinates and never invents hidden hull wakes. */
internal fun DrawScope.drawLivingWater(phase:Float) {
    val u=size.width/10;val t=phase*2*PI.toFloat()
    drawRect(Brush.verticalGradient(listOf(Color(0xFF075976),Color(0xFF167D97),Color(0xFF073E61))))
    for(y in 0..9)for(x in 0..9)drawRect(if((x+y)%2==0)Color(0xFF9CE9DF).copy(alpha=.12f)else Color(0xFF002D54).copy(alpha=.09f),Offset(x*u,y*u),Size(u,u))
    repeat(14){row->
        val crest=Path();val base=(row+.2f)*size.height/14
        repeat(49){i->
            val x=i*size.width/48
            val yy=base+sin(i*.34f+row*.95f-t)*u*.22f+sin(i*.15f+t*2)*u*.085f
            if(i==0)crest.moveTo(x,yy)else crest.lineTo(x,yy)
        }
        drawPath(crest,Color(0xFF00324E).copy(alpha=.36f),style=Stroke(u*.23f,cap=StrokeCap.Round))
        drawPath(crest,Color(0xFF63D6D5).copy(alpha=.35f),style=Stroke(u*.13f,cap=StrokeCap.Round))
        // Broken, bright crests roll over the darker body of each wave.
        repeat(4){part->
            val foam=Path();val from=part*12
            repeat(9){step->val i=from+step;val x=i*size.width/48
                val yy=base+sin(i*.34f+row*.95f-t)*u*.22f+sin(i*.15f+t*2)*u*.085f-u*.025f
                if(step==0)foam.moveTo(x,yy)else foam.lineTo(x,yy)}
            val a=(.26f+.16f*sin(t+row+part)).coerceIn(.08f,.45f)
            drawPath(foam,Color(0xFFD4FFF4).copy(alpha=a),style=Stroke(u*.026f,cap=StrokeCap.Round))
        }
    }
}

internal fun DrawScope.drawBoardSurf(phase:Float,visibleShips:List<Set<Cell>>) {
    val u=size.width/10;val t=phase*2*PI.toFloat()
    // Spray on the four sides of the board, independent of either fleet.
    repeat(4){edge->withTransform({rotate(edge*90f,center)}) {
        repeat(9){n->val x=(n+.5f)*size.width/9;val q=(phase*2+n*.137f)%1f
            val alpha=sin(q*PI.toFloat()).coerceAtLeast(0f)*.7f
            drawArc(Color(0xFFDBFFF7).copy(alpha=alpha),195f,140f,false,Offset(x-u*.4f,u*(-.14f+q*.16f)),Size(u*.8f,u*.27f),style=Stroke(u*.037f))
            repeat(3){k->drawCircle(Color.White.copy(alpha=alpha*.7f),u*(.012f+k*.004f),Offset(x+sin(n+k+t)*u*.24f,u*(.1f+q*.2f+k*.025f)))}
        }
    }}
    // Only already-visible vessels get bow spray; an opponent's hidden fleet has no wake.
    visibleShips.filter {it.isNotEmpty()}.forEach {cells->
        val vertical=cells.map {it.x}.distinct().size==1&&cells.size>1
        val c=boardVesselCenter(cells,u)
        withTransform({translate(c.x,c.y);if(vertical)rotate(90f,Offset.Zero)}) {
            val width=u*cells.size*.94f;val y=u*vesselHeightScale(cells.size)*.37f
            val pulse=(.5f+.5f*sin(t+cells.first().x*.7f+cells.first().y)).coerceIn(0f,1f)
            drawArc(Color(0xFFC8FFF3).copy(alpha=.25f+pulse*.4f),5f,170f,false,Offset(-width*.51f,y-u*.12f),Size(width*1.04f,u*(.24f+pulse*.1f)),style=Stroke(u*.025f))
            for(side in listOf(-1f,1f))repeat(5){k->
                val q=(phase*2+k*.17f)%1f
                drawCircle(Color.White.copy(alpha=(1-q)*.55f),u*(.012f+(k%2)*.008f),Offset(side*(width*.47f+q*u*.22f),y-sin(q*PI.toFloat())*u*.3f+k*u*.013f))
            }
        }
    }
}
