package com.notebook.seabattle

import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.*

/** Moving water stays below fixed game coordinates and never invents hidden hull wakes. */
internal val LocalBoardWater=staticCompositionLocalOf<ImageBitmap?> {null}

internal fun DrawScope.drawLivingWater(phase:Float,sea:ImageBitmap?) {
    val u=size.width/10;val t=phase*2*PI.toFloat()
    drawRect(Brush.verticalGradient(listOf(Color(0xFF075976),Color(0xFF167D97),Color(0xFF073E61))))
    // Use the illustrated sea itself, cropping out sky, islands and rocks at draw time.
    // Adjacent strips share vertices: a small periodic mesh deforms the painted wave
    // faces and foam, rather than sliding parallel sine lines across the game board.
    if(sea!=null) {
        val srcLeft=(sea.width*.21f).toInt();val srcTop=(sea.height*.34f).toInt()
        val srcWidth=(sea.width*.58f).toInt();val srcHeight=(sea.height*.47f).toInt()
        val rows=18;val pad=u*.42f
        fun boundary(i:Int)=i*(size.height+2*pad)/rows-pad+sin(t+i*.48f)*u*.12f
        repeat(rows){row->
            val top=boundary(row);val bottom=boundary(row+1)
            val sway=sin(t+row*.27f)*u*.18f
            drawImage(sea,srcOffset=IntOffset(srcLeft,srcTop+row*srcHeight/rows),
                srcSize=IntSize(srcWidth,((row+1)*srcHeight/rows-row*srcHeight/rows).coerceAtLeast(1)),
                dstOffset=IntOffset((-pad+sway).roundToInt(),floor(top).toInt()),
                dstSize=IntSize((size.width+2*pad).roundToInt(),ceil(bottom-top+1).toInt()),filterQuality=FilterQuality.Medium)
        }
    }
    for(y in 0..9)for(x in 0..9)drawRect(if((x+y)%2==0)Color(0xFFB8F3E4).copy(alpha=.09f)else Color(0xFF002D54).copy(alpha=.10f),Offset(x*u,y*u),Size(u,u))
}

internal fun DrawScope.drawBoardSurf(phase:Float,visibleShips:List<Set<Cell>>) {
    val u=size.width/10;val t=phase*2*PI.toFloat()
    // Spray on the four sides of the board, independent of either fleet.
    repeat(4){edge->withTransform({rotate(edge*90f,center)}) {
        repeat(7){n->val x=(n+.5f)*size.width/7;val q=(phase*2+n*.173f)%1f
            val surge=sin(q*PI.toFloat()).coerceAtLeast(0f);val reach=u*(.08f+.29f*surge)
            val foam=Path().apply {
                moveTo(x-u*.83f,-u*.05f)
                cubicTo(x-u*.48f,reach*.2f,x-u*.35f,reach*1.4f,x-u*.05f,reach*.8f)
                cubicTo(x+u*.12f,reach*1.6f,x+u*.29f,reach*.16f,x+u*.43f,reach*.65f)
                cubicTo(x+u*.59f,reach,x+u*.68f,0f,x+u*.85f,-u*.05f);close()
            }
            drawPath(foam,Brush.verticalGradient(listOf(Color(0xFFF1FFF8).copy(alpha=surge*.75f),Color(0xFF8FDDD9).copy(alpha=surge*.18f)),endY=reach))
            repeat(9){k->
                val a=(1-q)*surge*.8f
                val xx=x+sin(n*13f+k*3.7f)*u*.72f
                val yy=u*.03f+q*u*.52f*abs(sin(k*2.1f+n))
                drawCircle(Color(0xFFECFFF4).copy(alpha=a),u*(.009f+k%3*.009f),Offset(xx,yy))
            }
        }
    }}
    // Only already-visible vessels get bow spray; an opponent's hidden fleet has no wake.
    visibleShips.filter {it.isNotEmpty()}.forEach {cells->
        val vertical=cells.map {it.x}.distinct().size==1&&cells.size>1
        val c=boardVesselCenter(cells,u)
        withTransform({translate(c.x,c.y);if(vertical)rotate(90f,Offset.Zero)}) {
            val width=u*cells.size*.94f;val y=u*vesselHeightScale(cells.size)*.37f
            val pulse=(.5f+.5f*sin(t+cells.first().x*.7f+cells.first().y)).coerceIn(0f,1f)
            drawArc(Color(0xFFC8FFF3).copy(alpha=.25f+pulse*.4f),5f,170f,false,Offset(-width*.51f,y-u*.12f),Size(width*1.04f,u*(.24f+pulse*.1f)),style=Stroke(u*.025f))
            for(side in listOf(-1f,1f))repeat(5){k->
                val q=(phase*2+k*.17f)%1f
                drawCircle(Color.White.copy(alpha=(1-q)*.55f),u*(.012f+(k%2)*.008f),Offset(side*(width*.47f+q*u*.22f),y-sin(q*PI.toFloat())*u*.3f+k*u*.013f))
            }
        }
    }
}
