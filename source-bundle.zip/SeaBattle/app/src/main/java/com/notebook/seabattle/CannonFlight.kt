package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import kotlin.math.*

@Composable internal fun CannonFlightLayer(frame:ShotFrame?,progress:Animatable<Float,AnimationVector1D>,ownBounds:Rect,enemyBounds:Rect,ownZoom:BoardZoomState,enemyZoom:BoardZoomState) {
    if(frame==null)return
    val label="${if(frame.outgoing)"Ваш корабль" else "Соперник"}. Цель ${"АБВГДЕЖЗИК"[frame.target.x]}${frame.target.y+1}. ${if(frame.hit)"Попадание" else "Промах"}"
    Canvas(Modifier.fillMaxSize().testTag("cannon-flight").semantics {stateDescription=label}) {
        val p=progress.value
        val source=if(frame.outgoing)ownBounds else enemyBounds
        val target=if(frame.outgoing)enemyBounds else ownBounds
        val sourceZoom=if(frame.outgoing)ownZoom else enemyZoom
        val targetZoom=if(frame.outgoing)enemyZoom else ownZoom
        val unit=if(source.width>0)source.width/10 else size.height/12
        val ship=frame.firingShip
        val start=if(source.width<=0)Offset(if(frame.outgoing)size.width*.035f else size.width*.965f,size.height*.65f)
            else if(ship!=null) {
                val vertical=ship.map {it.x}.distinct().size==1&&ship.size>1
                val half=unit*vesselHeightScale(ship.size)/2
                val raw=Offset((ship.minOf {it.x}+ship.maxOf {it.x}+1)*unit/2,(ship.minOf {it.y}+ship.maxOf {it.y}+1)*unit/2)
                val c=if(vertical)raw.copy(x=raw.x.coerceIn(half,source.width-half)) else raw.copy(y=raw.y.coerceIn(half,source.height-half))
                val hull=c+if(vertical)Offset(-unit*.3f,0f) else Offset(0f,unit*.3f)
                boardLocalPoint(hull,source,sourceZoom.viewport)
            } else source.center+Offset(source.width*.38f,source.height*.08f)
        val end=if(target.width>0)boardCellPoint(frame.target,target,targetZoom.viewport) else Offset(if(frame.outgoing)size.width*.97f else size.width*.03f,size.height*.5f)
        val rise=minOf((end-start).getDistance()*.2f,size.height*.22f)
        if(p<.25f) {
            val fade=1-p/.25f
            val flash=Path().apply {repeat(16){i->val a=i*PI.toFloat()/8;val r=unit*(if(i%2==0).42f else .13f)*(.8f+p*3);val v=start+Offset(cos(a),sin(a))*r;if(i==0)moveTo(v.x,v.y)else lineTo(v.x,v.y)};close()}
            drawPath(flash,Color(0xFFFFCA39).copy(alpha=fade));drawCircle(Color(0xFFFFF3C1).copy(alpha=fade),unit*.12f,start)
        }
        if(p<.68f)repeat(4){i->drawCircle(Color(0xFFD2C8AF).copy(alpha=(1-p/.68f)*.28f),unit*(.11f+p*.25f),start+Offset(unit*(i-1.5f)*p*.32f,-unit*p*(.35f+i*.12f)))}
        val ball=cannonArcPoint(start,end,p,rise)
        val tail=cannonArcPoint(start,end,(p-.065f).coerceAtLeast(0f),rise)
        drawLine(Color(0xFFF5D6A3).copy(alpha=.7f),tail,ball,2.2.dp.toPx(),StrokeCap.Round)
        val radius=(unit*.075f).coerceIn(4.dp.toPx(),9.dp.toPx())
        drawCircle(Color(0xFF111A21),radius,ball)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF9CA7A5),Color(0xFF161E24)),center=ball-Offset(radius*.35f,radius*.35f),radius=radius*1.3f),radius*.8f,ball)
        drawCircle(Color.White.copy(alpha=.5f),radius*.15f,ball-Offset(radius*.35f,radius*.35f))
    }
}

internal fun DrawScope.drawLivingWater(phase:Float) {
    val unit=size.width/10
    drawRect(Brush.verticalGradient(listOf(Color(0xFF117A99),Color(0xFF249FB4),Color(0xFF086B8B))))
    for(y in 0..9)for(x in 0..9)drawRect(if((x+y)%2==0)Color(0xFFA4E9E3).copy(alpha=.14f) else Color(0xFF003D69).copy(alpha=.06f),Offset(x*unit,y*unit),Size(unit,unit))
    repeat(15){row->
        val wave=Path();val y=(row+.35f)*size.height/15
        repeat(33){i->val x=i*size.width/32;val yy=y+sin(i*.32f+row*1.7f+phase*2*PI.toFloat())*unit*.045f+sin(i*.18f-phase*2*PI.toFloat())*unit*.025f;if(i==0)wave.moveTo(x,yy) else wave.lineTo(x,yy)}
        drawPath(wave,Color(0xFFC5FFFF).copy(alpha=.12f+(row%3)*.018f),style=Stroke(unit*.013f,cap=StrokeCap.Round))
    }
}
