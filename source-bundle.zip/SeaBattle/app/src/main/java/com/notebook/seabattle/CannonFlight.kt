package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import kotlin.math.*

@Composable internal fun CannonFlightLayer(frame:ShotFrame?,progress:Animatable<Float,AnimationVector1D>,ownBounds:Rect,enemyBounds:Rect,ownZoom:BoardZoomState,enemyZoom:BoardZoomState) {
    if(frame==null)return
    val label="${if(frame.outgoing)"Ваш выстрел" else "Выстрел соперника"}. Источник скрыт. Цель ${"АБВГДЕЖЗИК"[frame.target.x]}${frame.target.y+1}. ${if(frame.hit)"Попадание" else "Промах"}"
    Canvas(Modifier.fillMaxSize().testTag("cannon-flight").semantics {stateDescription=label}) {
        val p=progress.value
        val target=if(frame.outgoing)enemyBounds else ownBounds
        val targetZoom=if(frame.outgoing)enemyZoom else ownZoom
        val unit=if(target.width>0)target.width/10 else size.height/12
        val start=concealedCannonOrigin(frame.outgoing,size)
        val end=if(target.width>0)boardCellPoint(frame.target,target,targetZoom.viewport) else Offset(if(frame.outgoing)size.width*.97f else size.width*.03f,size.height*.5f)
        val rise=minOf((end-start).getDistance()*.2f,size.height*.22f)
        val ball=cannonArcPoint(start,end,p,rise)
        val tail=cannonArcPoint(start,end,(p-.065f).coerceAtLeast(0f),rise)
        drawLine(Color(0xFFF5D6A3).copy(alpha=.7f),tail,ball,2.2.dp.toPx(),StrokeCap.Round)
        val radius=(unit*.075f).coerceIn(4.dp.toPx(),9.dp.toPx())
        drawCircle(Color(0xFF111A21),radius,ball)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF9CA7A5),Color(0xFF161E24)),center=ball-Offset(radius*.35f,radius*.35f),radius=radius*1.3f),radius*.8f,ball)
        drawCircle(Color.White.copy(alpha=.5f),radius*.15f,ball-Offset(radius*.35f,radius*.35f))
    }
}
