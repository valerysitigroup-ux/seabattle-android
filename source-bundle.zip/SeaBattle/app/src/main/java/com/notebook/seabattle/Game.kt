package com.notebook.seabattle

import kotlin.math.abs
import kotlin.random.Random

data class Cell(val x: Int, val y: Int)
data class Ship(val cells: Set<Cell>)
enum class ShotResult { MISS, HIT, SUNK, WIN, ALREADY_SHOT }

class Board private constructor(val ships: List<Ship>) {
    val shots = mutableSetOf<Cell>()
    fun shoot(cell: Cell): ShotResult {
        require(cell.x in 0..9 && cell.y in 0..9)
        if (!shots.add(cell)) return ShotResult.ALREADY_SHOT
        val ship = ships.firstOrNull { cell in it.cells } ?: return ShotResult.MISS
        if (ships.all { it.cells.all(shots::contains) }) return ShotResult.WIN
        return if (ship.cells.all(shots::contains)) ShotResult.SUNK else ShotResult.HIT
    }
    fun occupied(cell: Cell) = ships.any { cell in it.cells }
    companion object {
        val fleetLengths = listOf(4, 3, 3, 2, 2, 2, 1, 1, 1, 1)

        /** Builds a manually arranged fleet, rejecting overlap, touching and gaps. */
        fun placed(positions: List<Set<Cell>>): Board {
            require(positions.size == 10 && positions.map { it.size }.sortedDescending() == fleetLengths)
            val ships = positions.map { cells ->
                require(cells.all { it.x in 0..9 && it.y in 0..9 })
                val xs = cells.map { it.x }; val ys = cells.map { it.y }
                require((xs.distinct().size == 1 && ys.max() - ys.min() + 1 == cells.size) ||
                    (ys.distinct().size == 1 && xs.max() - xs.min() + 1 == cells.size))
                Ship(cells.toSet())
            }
            ships.forEachIndexed { i, ship ->
                require(ships.drop(i + 1).none { other ->
                    ship.cells.any { a -> other.cells.any { b -> abs(a.x - b.x) <= 1 && abs(a.y - b.y) <= 1 } }
                })
            }
            return Board(ships)
        }

        fun random(random: Random = Random.Default): Board {
            repeat(1000) {
                val ships = mutableListOf<Ship>()
                var success = true
                for (length in listOf(4, 3, 3, 2, 2, 2, 1, 1, 1, 1)) {
                    val candidates = (0..9).flatMap { y -> (0..9).flatMap { x ->
                        listOf(true, false).mapNotNull { horizontal ->
                            val cells = (0 until length).map { n -> Cell(x + if (horizontal) n else 0, y + if (horizontal) 0 else n) }.toSet()
                            if (cells.all { it.x in 0..9 && it.y in 0..9 } && ships.none { ship -> ship.cells.any { old -> cells.any { abs(it.x - old.x) <= 1 && abs(it.y - old.y) <= 1 } } }) cells else null
                        }
                    } }.shuffled(random)
                    if (candidates.isEmpty()) { success = false; break }
                    ships += Ship(candidates.first())
                }
                if (success) return Board(ships)
            }
            error("Не удалось разместить флот")
        }
    }
}
