package com.notebook.seabattle

/** Server snapshots describe shots received by us and shots fired at the enemy. */
data class OnlineState(
    val player: Int = -1,
    val turn: Int = -1,
    val accepted: List<Boolean> = listOf(false, false),
    val finished: Boolean = false,
    val ownShots: Map<Cell, Boolean> = emptyMap(),
    val enemyShots: Map<Cell, Boolean> = emptyMap(),
    val pending: Cell? = null
) {
    val fleetAccepted get() = player in 0..1 && accepted[player]
    val canShoot get() = player in 0..1 && accepted.all { it } && !finished && turn == player && pending == null
    fun fire(cell: Cell): OnlineState {
        require(canShoot && cell.x in 0..9 && cell.y in 0..9 && cell !in enemyShots)
        return copy(pending = cell)
    }
    fun snapshot(next: OnlineState): OnlineState {
        require(next.player in 0..1 && next.turn in 0..1 && next.accepted.size == 2)
        return next.copy(pending = pending?.takeUnless { it in next.enemyShots || next.finished || next.turn != next.player })
    }
}
