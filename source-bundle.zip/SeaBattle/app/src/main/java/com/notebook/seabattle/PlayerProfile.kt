package com.notebook.seabattle

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

data class PlayerProfile(val name:String,val ledger:MatchLedger)
class PlayerStore(context:Context) {
    val preferences:SharedPreferences=context.applicationContext.getSharedPreferences("captain",Context.MODE_PRIVATE)
    init {if(!preferences.contains("name"))preferences.edit().putString("name","Капитан ${Random.nextInt(1000,9999)}").apply()}
    fun read()=PlayerProfile(preferences.getString("name","").orEmpty(),MatchLedger.fromJson(preferences.getString("ledger",null)))
    fun rename(value:String) {value.trim().take(24).takeIf {it.isNotBlank()}?.let {preferences.edit().putString("name",it).apply()}}
    @Synchronized fun record(matchId:String,opponent:String,won:Boolean) {
        val before=read().ledger;val next=before.record(matchId,opponent,won)
        if(next!=before)preferences.edit().putString("ledger",next.toJson()).apply()
    }
}
@Composable internal fun rememberPlayerProfile():Pair<PlayerStore,PlayerProfile> {
    val context=LocalContext.current.applicationContext
    val store=remember(context){PlayerStore(context)}
    var state by remember(store){mutableStateOf(store.read())}
    DisposableEffect(store){
        val listener=SharedPreferences.OnSharedPreferenceChangeListener {_,_->state=store.read()}
        store.preferences.registerOnSharedPreferenceChangeListener(listener)
        onDispose{store.preferences.unregisterOnSharedPreferenceChangeListener(listener)}
    }
    return store to state
}
@Composable internal fun CaptainPage(profile:PlayerProfile,store:PlayerStore,statistics:Boolean,onBack:()->Unit) {
    androidx.activity.compose.BackHandler(onBack=onBack)
    Parchment(Modifier.fillMaxSize().testTag(if(statistics)"player-statistics" else "player-name")) {
        LargeMenuText {
            Column(Modifier.fillMaxSize().imePadding().padding(horizontal=60.dp,vertical=16.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text(if(statistics)"Победы и поражения" else "Твоё имя",fontSize=34.sp)
                if(statistics) {
                    Text("Побед: ${profile.ledger.wins} · Поражений: ${profile.ledger.losses}",Modifier.testTag("player-totals"),fontSize=28.sp)
                    if(profile.ledger.opponents.isEmpty())Text("Здесь появится счёт твоих игр с друзьями.",fontSize=24.sp)
                    profile.ledger.opponents.sortedBy {it.name.lowercase()}.forEach {score->
                        Column(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                            Text(score.name,fontSize=30.sp)
                            Text("Побед: ${score.wins} · Поражений: ${score.losses}",fontSize=26.sp)
                        }
                    }
                } else {
                    var text by remember(profile.name){mutableStateOf(profile.name)}
                    OutlinedTextField(text,{text=it.take(24)},label={Text("Твоё имя")},singleLine=true,modifier=Modifier.widthIn(max=420.dp).fillMaxWidth().testTag("captain-name-input"))
                    TextButton(onClick={store.rename(text);onBack()},enabled=text.isNotBlank(),modifier=Modifier.testTag("save-captain-name")){Text("Сохранить")}
                }
            }
        }
        PirateBackButton(onBack,Modifier.align(Alignment.TopStart).padding(4.dp))
    }
}
