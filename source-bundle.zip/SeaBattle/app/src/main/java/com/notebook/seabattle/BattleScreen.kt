package com.notebook.seabattle

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable fun SoundButton() {
    val audio=LocalGameAudio.current ?: return
    TextButton(onClick={audio.enabled=!audio.enabled}) { Text(if(audio.enabled) "Звук: вкл" else "Звук: выкл") }
}

@Composable fun BattleScreen(
    title:String, message:String, own:BattleView, enemy:BattleView, canShoot:Boolean,
    onBack:()->Unit, onShot:(Cell)->Unit, actions:@Composable RowScope.()->Unit = {}
) {
    Column(Modifier.fillMaxSize().background(Color(0xFFFFFCF0)).padding(horizontal=8.dp,vertical=2.dp)) {
        Row(Modifier.fillMaxWidth().heightIn(min=40.dp),verticalAlignment=Alignment.CenterVertically) {
            TextButton(onClick=onBack) { Text("‹ Меню") }
            Text(title,Modifier.weight(1f),style=MaterialTheme.typography.titleSmall,maxLines=1,overflow=TextOverflow.Ellipsis)
            actions()
            SoundButton()
        }
        Text(message,Modifier.fillMaxWidth().padding(horizontal=8.dp),style=MaterialTheme.typography.bodyMedium,maxLines=2,overflow=TextOverflow.Ellipsis)
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
            val side=minOf((maxWidth-24.dp)/2,maxHeight-26.dp).coerceAtLeast(1.dp)
            Row(horizontalArrangement=Arrangement.spacedBy(24.dp),verticalAlignment=Alignment.Top) {
                BattlePane("ВАШ ФЛОТ · ${own.sunk.size}/10 потоплено",own,side,false) { }
                BattlePane("ПРОТИВНИК · ${enemy.sunk.size}/10 потоплено",enemy,side,canShoot,onShot)
            }
        }
    }
}

@Composable private fun BattlePane(title:String,view:BattleView,side:androidx.compose.ui.unit.Dp,enabled:Boolean,onShot:(Cell)->Unit) {
    Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
        Text(title,Modifier.height(26.dp),style=MaterialTheme.typography.labelMedium,maxLines=1)
        NotebookGrid(view.ships,view.shots,enabled,pending=view.pending,sunkShips=view.sunk,battleEffects=true,onCell=onShot)
    }
}

@Composable fun FleetPreview(view:BattleView,modifier:Modifier=Modifier) {
    BoxWithConstraints(modifier.fillMaxHeight(),contentAlignment=Alignment.Center) {
        val side=minOf(maxWidth,maxHeight-26.dp).coerceAtLeast(1.dp)
        Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("ВАШ ФЛОТ",Modifier.height(26.dp),style=MaterialTheme.typography.labelMedium)
            NotebookGrid(view.ships,view.shots,false,sunkShips=view.sunk) { }
        }
    }
}
