package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun SoundButton() {
    val audio=LocalGameAudio.current ?: return
    TextButton(onClick={audio.enabled=!audio.enabled}) {Text(if(audio.enabled) "Звук: вкл" else "Звук: выкл")}
}

@Composable fun BattleScreen(
    title:String,message:String,own:BattleView,enemy:BattleView,canShoot:Boolean,
    onBack:()->Unit,onShot:(Cell)->Unit,boardKey:Any=Unit,showGreeting:Boolean=true,matchStarted:Boolean=true,
    onGreetingStarted:()->Unit={},actions:@Composable ()->Unit={}
) {
    val ownZoom=remember(boardKey){BoardZoomState()};val enemyZoom=remember(boardKey){BoardZoomState()}
    var expanded by remember(boardKey){mutableStateOf<String?>(null)}
    BackHandler(expanded!=null){expanded=null}
    OceanScene {
    Row(Modifier.fillMaxSize().padding(6.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Column(Modifier.width(124.dp).fillMaxHeight().background(NotebookPaper.copy(alpha=.94f),RoundedCornerShape(16.dp)).padding(6.dp).verticalScroll(rememberScrollState()).testTag("side-menu"),
            verticalArrangement=Arrangement.spacedBy(4.dp)) {
            TextButton(onClick=onBack) {Text("‹ Меню")}
            Text(title,style=MaterialTheme.typography.titleSmall,maxLines=2,overflow=TextOverflow.Ellipsis)
            actions()
            SoundButton()
            Text(message,style=MaterialTheme.typography.bodySmall)
            if(expanded==null) {
                TextButton(onClick={expanded="own"},modifier=Modifier.testTag("expand-own")){Text("Мой флот ⤢")}
                TextButton(onClick={expanded="enemy"},modifier=Modifier.testTag("expand-enemy")){Text("Поле врага ⤢")}
                Text("Масштаб — двумя пальцами",style=MaterialTheme.typography.bodySmall)
            } else {
                val selected=if(expanded=="own")ownZoom else enemyZoom
                Text("${(selected.viewport.scale*100).toInt()}%",modifier=Modifier.testTag("zoom-level"))
                Row {
                    TextButton(onClick={selected.zoom(1/1.35f)},modifier=Modifier.weight(1f).testTag("zoom-out")){Text("−",fontSize=24.sp)}
                    TextButton(onClick={selected.zoom(1.35f)},modifier=Modifier.weight(1f).testTag("zoom-in")){Text("+",fontSize=24.sp)}
                }
                TextButton(onClick={selected.reset()}){Text("Сбросить")}
                TextButton(onClick={expanded=if(expanded=="own")"enemy" else "own"}){Text(if(expanded=="own")"Поле врага" else "Мой флот")}
                TextButton(onClick={expanded=null},modifier=Modifier.testTag("two-boards")){Text("Два поля")}
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Column(Modifier.fillMaxWidth().background(NotebookPaper.copy(alpha=.92f),RoundedCornerShape(14.dp)),horizontalAlignment=Alignment.CenterHorizontally) {
                Text(if(canShoot)"Ваш ход" else message,Modifier.testTag("top-turn"),fontSize=30.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                if(matchStarted) MatchGreeting(showGreeting,onGreetingStarted,compact=true)
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().testTag("board-region"),contentAlignment=Alignment.Center) {
                val side=minOf(if(expanded==null)(maxWidth-16.dp)/2 else maxWidth,maxHeight-26.dp).coerceAtLeast(1.dp)
                key(boardKey) {
                    Row(horizontalArrangement=Arrangement.spacedBy(16.dp),verticalAlignment=Alignment.CenterVertically) {
                        if(expanded!="enemy")BattlePane("ВАШ ФЛОТ · ${own.sunk.size}/10",own,side,false,"own-board",ownZoom) { }
                        if(expanded!="own")BattlePane("ПРОТИВНИК · ${enemy.sunk.size}/10",enemy,side,canShoot,"enemy-board",enemyZoom,onShot)
                    }
                }
            }
        }
    }
    Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){SinkingCelebration(own.sunk,enemy.sunk)}
    }
}
@Composable private fun BattlePane(title:String,view:BattleView,side:androidx.compose.ui.unit.Dp,enabled:Boolean,tag:String,zoom:BoardZoomState,onShot:(Cell)->Unit) {
    Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
        Text(title,Modifier.height(26.dp).fillMaxWidth().background(NotebookPaper.copy(alpha=.92f),RoundedCornerShape(topStart=8.dp,topEnd=8.dp)),style=MaterialTheme.typography.labelMedium,maxLines=1,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
        ZoomableBoard(view,enabled,tag,zoom,onShot)
    }
}
@Composable fun FleetPreview(view:BattleView,modifier:Modifier=Modifier) {
    BoxWithConstraints(modifier.fillMaxHeight(),contentAlignment=Alignment.Center) {
        val side=minOf(maxWidth,maxHeight-26.dp).coerceAtLeast(1.dp)
        Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("ВАШ ФЛОТ",Modifier.height(26.dp),style=MaterialTheme.typography.labelMedium)
            NotebookGrid(view.ships,view.shots,false,sunkShips=view.sunk) { }
        }
    }
}
