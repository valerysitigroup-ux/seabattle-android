package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.positionInRoot

@Composable fun SoundButton() {
    val audio=LocalGameAudio.current ?: return
    TextButton(onClick={audio.enabled=!audio.enabled}) {Text(if(audio.enabled) "Звук: вкл" else "Звук: выкл")}
}

enum class BattleTurn { PLAYER, OPPONENT }

@Composable fun BattleScreen(
    title:String,message:String,own:BattleView,enemy:BattleView,canShoot:Boolean,
    onBack:()->Unit,onShot:(Cell)->Unit,boardKey:Any=Unit,onMatchFinished:()->Unit=onBack,activeTurn:BattleTurn?=if(canShoot)BattleTurn.PLAYER else BattleTurn.OPPONENT,actions:@Composable ()->Unit={}
) {
    var shownOwn by remember(boardKey){mutableStateOf(own)}
    var shownEnemy by remember(boardKey){mutableStateOf(enemy)}
    val planner=remember(boardKey){SalvoPlanner(own,enemy)}
    val events=remember(boardKey){Channel<ShotFrame>(Channel.UNLIMITED)}
    var queued by remember(boardKey){mutableIntStateOf(0)}
    var flight by remember(boardKey){mutableStateOf<ShotFrame?>(null)}
    val progress=remember(boardKey){Animatable(0f)}
    val audio=LocalGameAudio.current
    DisposableEffect(events){onDispose{events.close()}}
    LaunchedEffect(own,enemy,boardKey){
        val frames=planner.plan(own,enemy)
        if(frames.isEmpty()&&queued==0){shownOwn=own;shownEnemy=enemy}
        if(frames.isNotEmpty()){queued+=frames.size;frames.forEach {events.trySend(it)}}
    }
    LaunchedEffect(events){
        for(frame in events){
            progress.snapTo(0f);flight=frame;audio?.cannonShot()
            val whistle=if(!frame.hit)launch{delay(120);audio?.whistle()}else null
            progress.animateTo(1f,tween(CANNON_FLIGHT_MS,easing=LinearEasing))
            whistle?.join()
            shownOwn=frame.own;shownEnemy=frame.enemy;flight=null;queued--
        }
    }
    var ownBounds by remember{mutableStateOf(Rect.Zero)}
    var enemyBounds by remember{mutableStateOf(Rect.Zero)}
    var origin by remember{mutableStateOf(Offset.Zero)}
    val playing=shownOwn.sunk.size<10&&shownEnemy.sunk.size<10
    val turn=flight?.let {if(it.outgoing)BattleTurn.PLAYER else BattleTurn.OPPONENT} ?: activeTurn
    val ownZoom=remember(boardKey){BoardZoomState()};val enemyZoom=remember(boardKey){BoardZoomState()}
    var expanded by remember(boardKey){mutableStateOf<String?>(null)}
    var menu by remember {mutableStateOf(false)}
    BackHandler(menu||expanded!=null){if(menu)menu=false else expanded=null}
    OceanScene {
        BoxWithConstraints(Modifier.fillMaxSize().testTag("board-region").onGloballyPositioned {origin=it.positionInRoot()},contentAlignment=Alignment.Center) {
            // 10 + 1 + 10 cells, with at least one cell around the outside.
            // Preserve square cells; excess space stays symmetric on wide screens.
            val cell=minOf(maxWidth/(if(expanded==null)23 else 12),maxHeight/12).coerceAtLeast(1.dp)
            val side=cell*10
            key(boardKey) {
                Row(horizontalArrangement=Arrangement.spacedBy(cell),verticalAlignment=Alignment.CenterVertically) {
                    if(expanded!="enemy")BattlePane("ВАШ ФЛОТ · ${shownOwn.sunk.size}/10",shownOwn,side,false,"own-board",ownZoom,highlight=playing&&turn==BattleTurn.PLAYER,onBounds={ownBounds=it}) { }
                    if(expanded!="own")BattlePane("ПРОТИВНИК · ${shownEnemy.sunk.size}/10",shownEnemy,side,canShoot&&!menu&&queued==0,"enemy-board",enemyZoom,highlight=playing&&turn==BattleTurn.OPPONENT,onBounds={enemyBounds=it},onShot=onShot)
                }
            }
        }
        CannonFlightLayer(flight,progress,if(expanded=="enemy")Rect.Zero else ownBounds.translate(-origin),if(expanded=="own")Rect.Zero else enemyBounds.translate(-origin),ownZoom,enemyZoom)
        PirateMenuButton(onClick={menu=true},modifier=Modifier.align(Alignment.TopStart))
        TurnNotice(flight?.outgoing ?: canShoot,if(flight?.outgoing==false)"Соперник стреляет" else message,boardKey)

        if(menu) Parchment(Modifier.fillMaxSize().testTag("battle-menu")) {
            LargeMenuText {
                Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)) {
                    Text("МЕНЮ · $title",fontSize=36.sp,fontWeight=FontWeight.Bold)
                    TextButton(onClick={menu=false},modifier=Modifier.testTag("close-menu")){Text("Продолжить игру")}
                    Text(message,fontSize=24.sp)
                    actions()
                    SoundButton()
                    Row(horizontalArrangement=Arrangement.spacedBy(20.dp)) {
                        TextButton(onClick={expanded="own";menu=false},modifier=Modifier.testTag("expand-own")){Text("Мой флот ⤢")}
                        TextButton(onClick={expanded="enemy";menu=false},modifier=Modifier.testTag("expand-enemy")){Text("Поле врага ⤢")}
                    }
                    if(expanded!=null) {
                        val selected=if(expanded=="own")ownZoom else enemyZoom
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            TextButton(onClick={selected.zoom(1/1.35f)},modifier=Modifier.testTag("zoom-out")){Text("−")}
                            Text("${(selected.viewport.scale*100).toInt()}%",Modifier.testTag("zoom-level"),fontSize=30.sp)
                            TextButton(onClick={selected.zoom(1.35f)},modifier=Modifier.testTag("zoom-in")){Text("+")}
                            TextButton(onClick={selected.reset()}){Text("Сбросить")}
                        }
                        TextButton(onClick={expanded=null;menu=false},modifier=Modifier.testTag("two-boards")){Text("Два поля")}
                    }
                    Text("Приближайте поле двумя пальцами",fontSize=22.sp)
                    TextButton(onClick=onBack){Text("В главное меню")}
                }
            }
        }
        MatchFinale(when {shownEnemy.sunk.size==10->MatchOutcome.WIN;shownOwn.sunk.size==10->MatchOutcome.LOSS;else->null},onMatchFinished)
    }
}

/** Keep the current turn visible until a shot hands play to the opponent. */
@Composable internal fun BoxScope.TurnNotice(canShoot:Boolean,message:String,boardKey:Any=Unit) {
    Parchment(Modifier.align(Alignment.TopCenter).widthIn(max=360.dp)) {
        Text(if(canShoot)"Ваш ход" else message,Modifier.padding(horizontal=14.dp,vertical=2.dp).testTag("top-turn"),fontSize=28.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
    }
}

@Composable private fun BattlePane(title:String,view:BattleView,side:androidx.compose.ui.unit.Dp,enabled:Boolean,tag:String,zoom:BoardZoomState,highlight:Boolean=false,onBounds:(Rect)->Unit={},onShot:(Cell)->Unit) {
    Box(Modifier.size(side).onGloballyPositioned {onBounds(it.boundsInRoot())}) {
        Parchment(Modifier.align(Alignment.TopCenter).offset(y=(-21).dp).height(21.dp).fillMaxWidth()) {Text(title,Modifier.align(Alignment.Center),fontSize=15.sp,maxLines=1,textAlign=androidx.compose.ui.text.style.TextAlign.Center)}
        ZoomableBoard(view,enabled,tag,zoom,onShot)
        if(highlight)Canvas(Modifier.matchParentSize().testTag(if(tag=="own-board")"own-turn-glow" else "enemy-turn-glow")) {drawRect(Color(0xFFFFE06D).copy(alpha=.12f));drawRect(Color(0xFFFFC63B),style=Stroke(5.dp.toPx()))}
    }
}
@Composable fun FleetPreview(view:BattleView,modifier:Modifier=Modifier) {
    BoxWithConstraints(modifier.fillMaxHeight(),contentAlignment=Alignment.Center) {
        val side=minOf(maxWidth,maxHeight-26.dp).coerceAtLeast(1.dp)
        Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
            Parchment(Modifier.height(26.dp).fillMaxWidth()){Text("ВАШ ФЛОТ",Modifier.align(Alignment.Center),style=MaterialTheme.typography.labelMedium)}
            NotebookGrid(view.ships,view.shots,false,sunkShips=view.sunk) { }
        }
    }
}
