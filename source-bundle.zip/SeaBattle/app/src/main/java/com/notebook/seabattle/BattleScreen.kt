package com.notebook.seabattle

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable fun SoundButton() {
    val audio=LocalGameAudio.current ?: return
    TextButton(onClick={audio.enabled=!audio.enabled}) {Text(if(audio.enabled) "Звук: вкл" else "Звук: выкл")}
}

@Composable fun BattleScreen(
    title:String,message:String,own:BattleView,enemy:BattleView,canShoot:Boolean,
    onBack:()->Unit,onShot:(Cell)->Unit,boardKey:Any=Unit,showGreeting:Boolean=true,matchStarted:Boolean=true,
    onGreetingStarted:()->Unit={},actions:@Composable ()->Unit={}
) {
    Row(Modifier.fillMaxSize().background(NotebookPaper).padding(6.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Column(Modifier.width(124.dp).fillMaxHeight().verticalScroll(rememberScrollState()).testTag("side-menu"),
            verticalArrangement=Arrangement.spacedBy(4.dp)) {
            TextButton(onClick=onBack) {Text("‹ Меню")}
            Text(title,style=MaterialTheme.typography.titleSmall,maxLines=2,overflow=TextOverflow.Ellipsis)
            actions()
            SoundButton()
            Text(message,style=MaterialTheme.typography.bodySmall)
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            if(matchStarted) MatchGreeting(showGreeting,onGreetingStarted) else Spacer(Modifier.height(48.dp))
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().testTag("board-region"),contentAlignment=Alignment.Center) {
                val side=minOf((maxWidth-16.dp)/2,maxHeight-26.dp).coerceAtLeast(1.dp)
                key(boardKey) {
                    Row(horizontalArrangement=Arrangement.spacedBy(16.dp),verticalAlignment=Alignment.CenterVertically) {
                        BattlePane("ВАШ ФЛОТ · ${own.sunk.size}/10",own,side,false,"own-board") { }
                        BattlePane("ПРОТИВНИК · ${enemy.sunk.size}/10",enemy,side,canShoot,"enemy-board",onShot)
                    }
                }
            }
        }
    }
}
@Composable private fun BattlePane(title:String,view:BattleView,side:androidx.compose.ui.unit.Dp,enabled:Boolean,tag:String,onShot:(Cell)->Unit) {
    Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
        Text(title,Modifier.height(26.dp),style=MaterialTheme.typography.labelMedium,maxLines=1)
        Box(Modifier.testTag(tag)) {NotebookGrid(view.ships,view.shots,enabled,pending=view.pending,sunkShips=view.sunk,battleEffects=true,onCell=onShot)}
    }
}
@Composable fun FleetPreview(view:BattleView,modifier:Modifier=Modifier) {
    BoxWithConstraints(modifier.fillMaxHeight(),contentAlignment=Alignment.Center) {
        val side=minOf(maxWidth,maxHeight-26.dp).coerceAtLeast(1.dp)
        Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("ВАШ ФЛОТ",Modifier.height(26.dp),style=MaterialTheme.typography.labelMedium)
            NotebookGrid(view.ships,view.shots,false,sunkShips=view.sunk) { }
        }
    }
}
