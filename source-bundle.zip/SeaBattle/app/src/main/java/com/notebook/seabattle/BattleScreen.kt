package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable fun SoundButton() {
    val audio=LocalGameAudio.current ?: return
    TextButton(onClick={audio.enabled=!audio.enabled}) {Text(if(audio.enabled) "Звук: вкл" else "Звук: выкл")}
}

@Composable fun BattleScreen(
    title:String,message:String,own:BattleView,enemy:BattleView,canShoot:Boolean,
    onBack:()->Unit,onShot:(Cell)->Unit,boardKey:Any=Unit,actions:@Composable ()->Unit={}
) {
    val ownZoom=remember(boardKey){BoardZoomState()};val enemyZoom=remember(boardKey){BoardZoomState()}
    var expanded by remember(boardKey){mutableStateOf<String?>(null)}
    var menu by remember {mutableStateOf(false)}
    BackHandler(menu||expanded!=null){if(menu)menu=false else expanded=null}
    OceanScene {
        BoxWithConstraints(Modifier.fillMaxSize().padding(top=32.dp,start=4.dp,end=4.dp,bottom=3.dp).testTag("board-region"),contentAlignment=Alignment.Center) {
            val side=minOf(if(expanded==null)(maxWidth-8.dp)/2 else maxWidth,maxHeight-18.dp).coerceAtLeast(1.dp)
            key(boardKey) {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    if(expanded!="enemy")BattlePane("ВАШ ФЛОТ · ${own.sunk.size}/10",own,side,false,"own-board",ownZoom) { }
                    if(expanded!="own")BattlePane("ПРОТИВНИК · ${enemy.sunk.size}/10",enemy,side,canShoot&&!menu,"enemy-board",enemyZoom,onShot)
                }
            }
        }
        TextButton(onClick={menu=true},Modifier.align(Alignment.TopStart).height(32.dp).testTag("open-menu"),contentPadding=PaddingValues(horizontal=12.dp,vertical=0.dp)) {Text("Меню",fontSize=24.sp,fontWeight=FontWeight.Bold)}
        TurnNotice(canShoot,message,boardKey)
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){SinkingCelebration(own.sunk,enemy.sunk)}
        if(menu) Parchment(Modifier.fillMaxSize().testTag("battle-menu")) {
            LargeMenuText {
                Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)) {
                    Text("МЕНЮ · $title",fontSize=36.sp,fontWeight=FontWeight.Bold)
                    TextButton(onClick={menu=false},modifier=Modifier.testTag("close-menu")){Text("Продолжить игру")}
                    Text(message,fontSize=24.sp)
                    actions()
                    SoundButton()
                    Row(horizontalArrangement=Arrangement.spacedBy(20.dp)) {
                        TextButton(onClick={expanded="own";menu=false},modifier=Modifier.testTag("expand-own")){Text("Мой флот ⤢")}
                        TextButton(onClick={expanded="enemy";menu=false},modifier=Modifier.testTag("expand-enemy")){Text("Поле врага ⤢")}
                    }
                    if(expanded!=null) {
                        val selected=if(expanded=="own")ownZoom else enemyZoom
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            TextButton(onClick={selected.zoom(1/1.35f)},modifier=Modifier.testTag("zoom-out")){Text("−")}
                            Text("${(selected.viewport.scale*100).toInt()}%",Modifier.testTag("zoom-level"),fontSize=30.sp)
                            TextButton(onClick={selected.zoom(1.35f)},modifier=Modifier.testTag("zoom-in")){Text("+")}
                            TextButton(onClick={selected.reset()}){Text("Сбросить")}
                        }
                        TextButton(onClick={expanded=null;menu=false},modifier=Modifier.testTag("two-boards")){Text("Два поля")}
                    }
                    Text("Приближайте поле двумя пальцами",fontSize=22.sp)
                    TextButton(onClick=onBack){Text("В главное меню")}
                }
            }
        }
    }
}

/** No panel or layout space: a translucent announcement appears only at a turn change. */
@Composable internal fun BoxScope.TurnNotice(canShoot:Boolean,message:String,boardKey:Any=Unit) {
    key(canShoot,boardKey) {
        val opacity=remember {Animatable(.82f)}
        var visible by remember {mutableStateOf(true)}
        LaunchedEffect(Unit) {
            delay(1400);opacity.animateTo(0f,tween(1000));visible=false
        }
        if(visible)Text(if(canShoot)"Ваш ход" else message,Modifier.align(Alignment.TopCenter).alpha(opacity.value).testTag("top-turn"),fontSize=36.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
    }
}
@Composable private fun BattlePane(title:String,view:BattleView,side:androidx.compose.ui.unit.Dp,enabled:Boolean,tag:String,zoom:BoardZoomState,onShot:(Cell)->Unit) {
    Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
        Text(title,Modifier.height(18.dp).fillMaxWidth().background(NotebookPaper.copy(alpha=.85f),RoundedCornerShape(topStart=8.dp,topEnd=8.dp)),fontSize=16.sp,maxLines=1,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
        ZoomableBoard(view,enabled,tag,zoom,onShot)
    }
}
@Composable fun FleetPreview(view:BattleView,modifier:Modifier=Modifier) {
    BoxWithConstraints(modifier.fillMaxHeight(),contentAlignment=Alignment.Center) {
        val side=minOf(maxWidth,maxHeight-26.dp).coerceAtLeast(1.dp)
        Column(Modifier.width(side),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("ВАШ ФЛОТ",Modifier.height(26.dp),style=MaterialTheme.typography.labelMedium)
            NotebookGrid(view.ships,view.shots,false,sunkShips=view.sunk) { }
        }
    }
}
