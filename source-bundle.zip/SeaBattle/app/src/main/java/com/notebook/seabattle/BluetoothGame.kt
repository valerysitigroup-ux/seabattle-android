package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject

/** Two paired phones, selected private fleets, turn-based RFCOMM protocol. */
@SuppressLint("MissingPermission")
@Composable
fun BluetoothGame(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val manager = context.getSystemService(BluetoothManager::class.java)
    val adapter: BluetoothAdapter? = manager?.adapter
    var permission by remember { mutableStateOf(Build.VERSION.SDK_INT < 31 || context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permission = it }
    var status by remember { mutableStateOf("Выберите режим Bluetooth") }
    var connected by remember { mutableStateOf(false) }
    var hosting by remember { mutableStateOf(false) }
    var myTurn by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf(false) }
    var pendingCell by remember { mutableStateOf<Cell?>(null) }
    var peerReady by remember { mutableStateOf(false) }
    var localReady by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }
    var revision by remember { mutableIntStateOf(0) }
    var own by remember { mutableStateOf<Board?>(null) }
    if (own == null) {
        FleetPlacement(onBack = onBack, onReady = { own = it })
        return
    }
    val ownBoard = requireNotNull(own)
    val enemyShots = remember { mutableStateMapOf<Cell, ShotResult>() }
    val transport = remember(adapter) { adapter?.let { BluetoothTransport(it) } }
    fun send(obj: JSONObject) {
        try { transport?.send(obj.toString()) } catch (e: Exception) { status = "Ошибка отправки: ${e.message}" }
    }
    fun incoming(raw: String) {
        try {
            val msg = JSONObject(raw)
            when (msg.optString("type")) {
                "ready" -> { peerReady = true; if (localReady) { myTurn = hosting; status = if (myTurn) "Ваш ход" else "Ход соперника" } }
                "shot" -> {
                    val cell = Cell(msg.getInt("x"), msg.getInt("y"))
                    if (cell.x !in 0..9 || cell.y !in 0..9 || ended || !peerReady || !localReady || myTurn || pending) return
                    val result = ownBoard.shoot(cell)
                    revision++
                    send(JSONObject().put("type", "result").put("x", cell.x).put("y", cell.y).put("value", result.name))
                    if (result == ShotResult.WIN) { ended = true; status = "Ваш флот потоплен. Победил соперник." }
                    else if (result == ShotResult.MISS) { myTurn = true; status = "Соперник промахнулся. Ваш ход." }
                    else status = "Соперник попал. Он стреляет ещё."
                }
                "result" -> {
                    if (!pending) return
                    val cell = Cell(msg.getInt("x"), msg.getInt("y"))
                    if (cell != pendingCell || enemyShots[cell] != ShotResult.ALREADY_SHOT) return
                    val result = ShotResult.valueOf(msg.getString("value"))
                    if (result == ShotResult.ALREADY_SHOT) { enemyShots.remove(cell); status = "Повторный выстрел отклонён" }
                    else {
                        enemyShots[cell] = result
                        if (result == ShotResult.WIN) { ended = true; status = "Победа! Все корабли соперника потоплены." }
                        else if (result == ShotResult.MISS) { myTurn = false; status = "Мимо. Ход соперника." }
                        else status = "Попадание! Стреляйте ещё."
                    }
                    pending = false
                    pendingCell = null
                }
            }
        } catch (e: Exception) { status = "Ошибка протокола: ${e.message}" }
    }
    DisposableEffect(transport) { onDispose { transport?.close() } }
    val ownView=remember(ownBoard,revision) { ownBoard.battleView(true) }
    val enemyView=bluetoothBattleView(enemyShots.toMap())
    if(connected) {
        BattleScreen("ПО BLUETOOTH",status,ownView,enemyView,myTurn && peerReady && localReady && !pending && !ended,onBack,
            onShot={cell ->
                if(cell !in enemyShots && cell !in enemyView.blocked && myTurn && peerReady && localReady && !pending && !ended) {
                    enemyShots[cell]=ShotResult.ALREADY_SHOT;pending=true;pendingCell=cell
                    send(JSONObject().put("type","shot").put("x",cell.x).put("y",cell.y))
                }
            })
        return
    }
    Row(Modifier.fillMaxSize().background(Color(0xFFFFFCF0)).padding(8.dp),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("МОРСКОЙ БОЙ · BLUETOOTH", style = MaterialTheme.typography.headlineSmall)
        Text(status)
        if (adapter == null) Text("На устройстве нет Bluetooth")
        else if (!permission) Button(onClick = { if (Build.VERSION.SDK_INT >= 31) permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }) { Text("Разрешить Bluetooth") }
        else if (!adapter.isEnabled) Text("Включите Bluetooth в настройках телефона и вернитесь в игру.")
        else if (!connected) {
            Text("Сначала сопрягите телефоны в настройках Android. Один игрок создаёт игру, второй выбирает его из списка сопряжённых устройств.")
            Button(onClick = {
                hosting = true; status = "Ожидание второго телефона…"
                transport?.host(onMessage = { raw -> (context as android.app.Activity).runOnUiThread { incoming(raw) } }, onError = { e -> (context as android.app.Activity).runOnUiThread { status = "Соединение завершено: ${e.message}"; connected = false; peerReady = false; localReady = false; pending = false; pendingCell = null } }, onConnected = { (context as android.app.Activity).runOnUiThread { connected = true; localReady = true; status = "Ожидаем готовности соперника…" }; send(JSONObject().put("type", "ready")) })
            }) { Text("СОЗДАТЬ ИГРУ") }
            Text("ПОДКЛЮЧИТЬСЯ К ИГРОКУ")
            adapter.bondedDevices.forEach { device ->
                TextButton(onClick = {
                    hosting = false; status = "Подключение к ${device.name ?: "устройству"}…"
                    transport?.join(device, onMessage = { raw -> (context as android.app.Activity).runOnUiThread { incoming(raw) } }, onError = { e -> (context as android.app.Activity).runOnUiThread { status = "Соединение завершено: ${e.message}"; connected = false; peerReady = false; localReady = false; pending = false; pendingCell = null } }, onConnected = { (context as android.app.Activity).runOnUiThread { connected = true; localReady = true; status = "Ожидаем готовности соперника…" }; send(JSONObject().put("type", "ready")) })
                    // Send readiness after socket connects; see onConnected callback below.
                }) { Text(device.name ?: device.address) }
            }
        }
        TextButton(onClick = onBack) { Text("НАЗАД") }
    }
    FleetPreview(ownView,Modifier.weight(1f))
    }
}
