package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable internal fun SinkingCelebration(own:List<Set<Cell>>,enemy:List<Set<Cell>>) {
    var beforeOwn by remember {mutableStateOf(own.toList())}
    var beforeEnemy by remember {mutableStateOf(enemy.toList())}
    var event by remember {mutableStateOf<Set<Cell>?>(null)}
    var friendly by remember {mutableStateOf(false)}
    val progress=remember {Animatable(0f)}
    LaunchedEffect(own,enemy) {
        val lost=own.firstOrNull {it !in beforeOwn};val hit=enemy.firstOrNull {it !in beforeEnemy}
        beforeOwn=own.toList();beforeEnemy=enemy.toList()
        val fresh=hit ?: lost
        if(fresh!=null) {
            event=fresh;friendly=hit==null;progress.snapTo(0f)
            progress.animateTo(1f,tween(3600,easing=LinearEasing));event=null
        }
    }
    event?.let {SinkingScene(it.size,progress.value,friendly)}
}

/** A readable comic cutaway; all crew surface safely with life rings. */
@Composable internal fun SinkingScene(length:Int,progress:Float,friendly:Boolean=false) {
    Column(Modifier.widthIn(max=360.dp).fillMaxWidth(.85f).height(220.dp).clip(RoundedCornerShape(24.dp))
        .background(Color(0xFF073B57).copy(alpha=.94f),RoundedCornerShape(24.dp)).testTag("sinking-scene")
        .semantics {contentDescription="Корабль тонет, моряки прыгают в воду со спасательными кругами, пузыри поднимаются вверх"}
        .pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent().changes.forEach {it.consume()}}}},
        horizontalAlignment=Alignment.CenterHorizontally) {
        Text(if(friendly)"Наш корабль потоплен!" else "Потоплен!",color=Color(0xFFFFD76E),fontSize=30.sp,modifier=Modifier.height(40.dp))
        Canvas(Modifier.fillMaxWidth().weight(1f).clipToBounds().testTag("rescue-animation")) {
            val p=progress.coerceIn(0f,1f);val water=size.height*.55f
            val unit=size.width/(length+2.5f)
            val sink=((p-.16f)/.72f).coerceIn(0f,1f)
            val center=Offset(size.width*.5f,water-unit*.2f+sink*size.height*.58f)
            // Golden impact stars, then the vessel tilts below the waterline.
            if(p<.3f)repeat(14){i->val a=i*PI.toFloat()/7;val d=Offset(cos(a),sin(a));drawLine(Color(0xFFFFA331).copy(alpha=(1-p/.3f).coerceIn(0f,1f)),Offset(size.width/2,water-unit*.4f)+d*unit*(.5f+p*4),Offset(size.width/2,water-unit*.4f)+d*unit*(.85f+p*4),unit*.07f,StrokeCap.Round)}
            withTransform({rotate(-sink*24f,center)}) {cartoonVessel(length,unit,center)}
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0E9CB5).copy(alpha=.72f),Color(0xFF07516E))),Offset(0f,water),Size(size.width,size.height-water))
            repeat(4) {i->
                val start=.07f+i*.055f;val q=((p-start)/.38f).coerceIn(0f,1f)
                if(p>=start) {
                    val dir=if(i%2==0)-1f else 1f
                    val x=size.width*.5f+dir*unit*(.15f+q*(.95f+i*.22f))
                    val y=water-unit*.2f-sin(q*PI.toFloat())*unit*(.8f+i*.09f)+q*unit*.45f
                    sailor(Offset(x,y),unit*.17f,i,q>=.98f,p)
                    if(q>.75f)drawOval(Color(0xFFE1FFFF).copy(alpha=.7f),Offset(x-unit*.25f,water+unit*.1f),Size(unit*.5f,unit*.12f),style=Stroke(unit*.025f))
                }
            }
            repeat(16) {i->
                if(p>.36f){
                    val q=((p-.36f)*1.7f+i*.073f)%1f
                    val x=size.width*.5f+sin(i*2.7f+q)*unit*(.2f+(i%4)*.18f)
                    val y=size.height-q*(size.height-water+unit*.35f)
                    val r=unit*(.035f+(i%3)*.018f)
                    drawCircle(Color(0xFFB4FFFF).copy(alpha=(1-q)*.8f),r,Offset(x,y),style=Stroke(unit*.018f));drawCircle(Color.White.copy(alpha=.6f),r*.2f,Offset(x-r*.3f,y-r*.3f))
                }
            }
            repeat(14){i->val x=i*size.width/13;val y=water+sin(i*.9f+p*12)*unit*.05f;drawArc(Color(0xFFB9FFFF),0f,175f,false,Offset(x-unit*.13f,y),Size(unit*.35f,unit*.12f),style=Stroke(unit*.025f,cap=StrokeCap.Round))}
        }
    }
}
private fun DrawScope.sailor(c:Offset,r:Float,index:Int,floating:Boolean,p:Float) {
    val outline=Color(0xFF382D38);val bob=if(floating)sin(p*22+index)*r*.15f else 0f
    val head=c+Offset(0f,bob)
    drawCircle(outline,r*.5f,head);drawCircle(Color(0xFFFFD2A0),r*.42f,head)
    drawArc(Color(0xFFFFF1D5),180f,180f,true,head-Offset(r*.5f,r*.55f),Size(r,r*.7f))
    val body=head+Offset(0f,r*.85f)
    drawLine(if(index%2==0)Color(0xFFFC7650) else Color(0xFFFFD85A),head+Offset(0f,r*.5f),body,r*.65f,StrokeCap.Round)
    for(dir in listOf(-1f,1f)) {
        drawLine(outline,head+Offset(0f,r*.65f),head+Offset(dir*r,r*.05f),r*.13f,StrokeCap.Round)
        if(!floating)drawLine(outline,body,body+Offset(dir*r*.55f,r*.75f),r*.14f,StrokeCap.Round)
    }
    if(floating){drawOval(Color(0xFFFFBF54),body-Offset(r,r*.3f),Size(2*r,r*.8f),style=Stroke(r*.34f));drawOval(Color.White,body-Offset(r,r*.3f),Size(2*r,r*.8f),style=Stroke(r*.08f))}
}
