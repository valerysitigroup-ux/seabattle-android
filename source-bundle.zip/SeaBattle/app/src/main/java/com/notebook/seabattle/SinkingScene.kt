package com.notebook.seabattle

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import kotlin.math.*

/** The actual vessel sinks at its board coordinates; the whole effect follows board zoom. */
internal fun DrawScope.drawBoardSinking(cells:Set<Cell>,unit:Float,p:Float) {
    if(cells.isEmpty())return
    val length=cells.size
    val vertical=cells.map {it.x}.distinct().size==1&&length>1
    val center=Offset((cells.minOf {it.x}+cells.maxOf {it.x}+1)*unit/2,(cells.minOf {it.y}+cells.maxOf {it.y}+1)*unit/2)
    val sink=((p-.1f)/.85f).coerceIn(0f,1f)
    withTransform({rotate(if(vertical)90f else 0f,center)}) {
        val boatCenter=center+Offset(0f,unit*sink*.65f)
        withTransform({rotate(sink*17f,boatCenter);scale(1f,(1-sink*.85f).coerceAtLeast(.1f),boatCenter)}) {
            cartoonVessel(length,unit,boatCenter,wreck=p>.6f)
        }
    }
    // Water closes over the hull, with rising bubbles and one rescued pirate per deck.
    drawOval(Color(0xFF29C5D5).copy(alpha=.15f+sink*.32f),center-Offset(unit*(if(vertical).55f else length*.52f),unit*.15f),Size(unit*(if(vertical)1.1f else length*1.04f),unit*.65f*sink))
    repeat(length) {i->
        val q=((p-.08f-i*.055f)/.4f).coerceIn(0f,1f)
        if(p>=.08f+i*.055f) {
            val direction=if(i%2==0)-1 else 1
            val origin=if(vertical)center+Offset(0f,(i-(length-1)/2f)*unit*.65f) else center+Offset((i-(length-1)/2f)*unit*.65f,0f)
            val x=(origin.x+direction*unit*q*.58f).coerceIn(unit*.16f,size.width-unit*.16f)
            val y=(origin.y-sin(q*PI.toFloat())*unit*.8f+q*unit*.35f).coerceIn(unit*.2f,size.height-unit*.3f)
            pirateCrew(Offset(x,y),unit*.13f,i,q>.96f,p,hat=true)
        }
    }
    repeat(12) {i->
        if(p>.25f) {
            val q=((p-.25f)*1.8f+i*.081f)%1f
            val x=center.x+sin(i*2.4f)*unit*(.2f+(i%3)*.2f)
            val y=center.y+unit*.4f-q*unit*1.5f
            drawCircle(Color(0xFFE1FFFF).copy(alpha=(1-q)*.9f),unit*(.025f+(i%3)*.015f),Offset(x,y),style=Stroke(unit*.014f))
        }
    }
    repeat(7){i->val x=center.x+(i-3)*unit*.3f;drawArc(Color(0xFFD8FFFF).copy(alpha=.7f),0f,165f,false,Offset(x,center.y+unit*.2f+sin(p*15+i)*unit*.05f),Size(unit*.4f,unit*.12f),style=Stroke(unit*.02f,cap=StrokeCap.Round))}
}
internal fun DrawScope.pirateHat(c:Offset,r:Float) {
    val path=Path().apply {moveTo(c.x-r,c.y+r*.1f);lineTo(c.x-r*.65f,c.y-r*.5f);quadraticTo(c.x,c.y-r*.1f,c.x+r*.65f,c.y-r*.5f);lineTo(c.x+r,c.y+r*.1f);quadraticTo(c.x,c.y+r*.5f,c.x-r,c.y+r*.1f);close()}
    drawPath(path,Color(0xFF202331));drawPath(path,Color(0xFFF8D46B),style=Stroke(r*.1f))
}
internal fun DrawScope.pirateCrew(c:Offset,r:Float,index:Int,floating:Boolean,p:Float,hat:Boolean=false) {
    val ink=Color(0xFF382D38);val head=c+Offset(0f,if(floating)sin(p*22+index)*r*.13f else 0f)
    drawCircle(ink,r*.55f,head);drawCircle(Color(0xFFFFD2A0),r*.47f,head)
    if(hat)pirateHat(head-Offset(0f,r*.45f),r*.7f)
    drawLine(Color(0xFFB62A37),head-Offset(r*.45f,r*.35f),head+Offset(r*.4f,-r*.35f),r*.18f)
    val body=head+Offset(0f,r*1.3f)
    drawLine(if(index%2==0)Color(0xFFED5946) else Color(0xFFFFCC4C),head+Offset(0f,r*.55f),body,r*.85f,StrokeCap.Round)
    for(dir in listOf(-1f,1f)) {
        drawLine(ink,head+Offset(0f,r*.75f),head+Offset(dir*r,r*.1f),r*.16f,StrokeCap.Round)
        if(!floating)drawLine(ink,body,body+Offset(dir*r*.5f,r*.8f),r*.24f,StrokeCap.Round)
    }
    if(floating)drawOval(Color(0xFFFFCF54),body-Offset(r*1.2f,r*.4f),Size(r*2.4f,r),style=Stroke(r*.3f))
}
