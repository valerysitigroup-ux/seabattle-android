package com.notebook.seabattle

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import kotlin.math.*

/** The actual vessel sinks at its board coordinates; the whole effect follows board zoom. */
internal fun DrawScope.drawBoardSinking(cells:Set<Cell>,unit:Float,p:Float) {
    if(cells.isEmpty())return
    val length=cells.size
    val vertical=cells.map {it.x}.distinct().size==1&&length>1
    val center=Offset((cells.minOf {it.x}+cells.maxOf {it.x}+1)*unit/2,(cells.minOf {it.y}+cells.maxOf {it.y}+1)*unit/2)
    val sink=((p-.1f)/.85f).coerceIn(0f,1f)
    withTransform({rotate(if(vertical)90f else 0f,center)}) {
        val waterline=center.y+unit*.22f
        val boatCenter=center+Offset(0f,unit*sink*1.6f)
        val reach=unit*(length+3)
        val bounds=Rect(center.x-reach,center.y-reach,center.x+reach,center.y+reach)
        fun vessel() {
            withTransform({rotate(sin(sink*PI.toFloat()*.7f)*12f,boatCenter)}) {
                cartoonVessel(length,unit,boatCenter)
            }
        }
        // The full-sized vessel passes through a fixed water surface. Its submerged
        // portion is blue and loses visibility with depth; the dry portion is clipped.
        clipRect(bounds.left,waterline,bounds.right,bounds.bottom) {
            val underwater=Paint().apply {
                alpha=.65f*(1-sink)
                colorFilter=ColorFilter.tint(Color(0xFF1C799B).copy(alpha=.8f),BlendMode.SrcAtop)
            }
            drawContext.canvas.saveLayer(bounds,underwater)
            vessel()
            drawContext.canvas.restore()
        }
        clipRect(bounds.left,bounds.top,bounds.right,waterline) {vessel()}
        val wash=Path().apply {
            moveTo(center.x-unit*(length*.52f+.12f),waterline)
            repeat(25) {i->val x=center.x-unit*(length*.52f+.12f)+i*unit*(length*1.04f+.24f)/24
                lineTo(x,waterline+sin(i*.75f+p*17)*unit*.035f)}
            lineTo(center.x+unit*(length*.52f+.12f),waterline+unit*.85f)
            lineTo(center.x-unit*(length*.52f+.12f),waterline+unit*.85f);close()
        }
        drawPath(wash,Brush.verticalGradient(listOf(Color(0xFF159DBB).copy(alpha=.45f),Color(0xFF29C5D5).copy(alpha=0f)),startY=waterline,endY=waterline+unit*.85f))
        // The settled wreck becomes the permanent board marker after the mast vanishes.
        if(p>.82f) {
            drawContext.canvas.saveLayer(bounds,Paint().apply {alpha=((p-.82f)/.18f).coerceIn(0f,1f)})
            cartoonVessel(length,unit,center,wreck=true)
            drawContext.canvas.restore()
        }
        repeat(length*3+2) {i->
            val x=center.x-unit*(length*.5f+.1f)+i*unit*(length+ .2f)/(length*3+1)
            drawArc(Color(0xFFE6FFFF).copy(alpha=.85f),5f,165f,false,Offset(x,waterline-unit*.035f+sin(p*17+i)*unit*.025f),Size(unit*.3f,unit*.1f),style=Stroke(unit*.025f,cap=StrokeCap.Round))
        }
    }
    // One rescued pirate per deck stays at the surface while the vessel descends.
    repeat(length) {i->
        val q=((p-.08f-i*.055f)/.4f).coerceIn(0f,1f)
        if(p>=.08f+i*.055f) {
            val direction=if(i%2==0)-1 else 1
            val origin=if(vertical)center+Offset(0f,(i-(length-1)/2f)*unit*.65f) else center+Offset((i-(length-1)/2f)*unit*.65f,0f)
            val x=(origin.x+direction*unit*q*.58f).coerceIn(unit*.16f,size.width-unit*.16f)
            val y=(origin.y-sin(q*PI.toFloat())*unit*.8f+q*unit*.35f).coerceIn(unit*.2f,size.height-unit*.3f)
            pirateCrew(Offset(x,y),unit*.13f,i,q>.96f,p,hat=true)
        }
    }
    repeat(12) {i->
        if(p>.25f) {
            val q=((p-.25f)*1.8f+i*.081f)%1f
            val x=center.x+sin(i*2.4f)*unit*(.2f+(i%3)*.2f)
            val y=center.y+unit*.4f-q*unit*1.5f
            drawCircle(Color(0xFFE1FFFF).copy(alpha=(1-q)*.9f),unit*(.025f+(i%3)*.015f),Offset(x,y),style=Stroke(unit*.014f))
        }
    }
    repeat(7){i->val x=center.x+(i-3)*unit*.3f;drawArc(Color(0xFFD8FFFF).copy(alpha=.7f),0f,165f,false,Offset(x,center.y+unit*.2f+sin(p*15+i)*unit*.05f),Size(unit*.4f,unit*.12f),style=Stroke(unit*.02f,cap=StrokeCap.Round))}
}
internal fun DrawScope.pirateHat(c:Offset,r:Float) {
    val path=Path().apply {moveTo(c.x-r,c.y+r*.1f);lineTo(c.x-r*.65f,c.y-r*.5f);quadraticTo(c.x,c.y-r*.1f,c.x+r*.65f,c.y-r*.5f);lineTo(c.x+r,c.y+r*.1f);quadraticTo(c.x,c.y+r*.5f,c.x-r,c.y+r*.1f);close()}
    drawPath(path,Color(0xFF202331));drawPath(path,Color(0xFFF8D46B),style=Stroke(r*.1f))
}
internal fun DrawScope.pirateCrew(c:Offset,r:Float,index:Int,floating:Boolean,p:Float,hat:Boolean=false) {
    val ink=Color(0xFF382D38);val head=c+Offset(0f,if(floating)sin(p*22+index)*r*.13f else 0f)
    drawCircle(ink,r*.55f,head);drawCircle(Color(0xFFFFD2A0),r*.47f,head)
    if(hat)pirateHat(head-Offset(0f,r*.45f),r*.7f)
    drawLine(Color(0xFFB62A37),head-Offset(r*.45f,r*.35f),head+Offset(r*.4f,-r*.35f),r*.18f)
    val body=head+Offset(0f,r*1.3f)
    drawLine(if(index%2==0)Color(0xFFED5946) else Color(0xFFFFCC4C),head+Offset(0f,r*.55f),body,r*.85f,StrokeCap.Round)
    for(dir in listOf(-1f,1f)) {
        drawLine(ink,head+Offset(0f,r*.75f),head+Offset(dir*r,r*.1f),r*.16f,StrokeCap.Round)
        if(!floating)drawLine(ink,body,body+Offset(dir*r*.5f,r*.8f),r*.24f,StrokeCap.Round)
    }
    if(floating)drawOval(Color(0xFFFFCF54),body-Offset(r*1.2f,r*.4f),Size(r*2.4f,r),style=Stroke(r*.3f))
}
