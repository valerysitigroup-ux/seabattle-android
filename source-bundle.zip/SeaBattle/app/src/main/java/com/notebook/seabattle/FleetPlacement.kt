package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.abs

@Composable fun FleetPlacement(onBack:()->Unit,onReady:(Board)->Unit) {
    BackHandler(onBack=onBack)
    val lengths=Board.fleetLengths
    val placed=remember { mutableStateListOf<Set<Cell>>() }
    var horizontal by remember { mutableStateOf(true) }
    var warning by remember { mutableStateOf("") }
    val nextLength=lengths.getOrNull(placed.size)
    Row(Modifier.fillMaxSize().background(Color(0xFFFFFCF0)).padding(10.dp),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text("РАССТАНОВКА ФЛОТА",style=MaterialTheme.typography.titleLarge)
            Text("Кораблей: ${placed.size}/10. Нажмите начальную клетку.")
            Text(if(nextLength==null) "Все корабли расставлены" else "Следующий корабль: $nextLength кл.")
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick={horizontal=!horizontal}) { Text(if(horizontal) "Вдоль ↔" else "Поперёк ↕") }
                OutlinedButton(onClick={if(placed.isNotEmpty()) placed.removeAt(placed.lastIndex);warning=""}) {Text("Отменить")}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                TextButton(onClick={placed.clear();placed.addAll(Board.random().ships.map { it.cells });warning=""}) {Text("Случайно")}
                TextButton(onClick={placed.clear();warning=""}) {Text("Очистить")}
            }
            if(warning.isNotEmpty()) Text(warning,color=Color(0xFFBC2626))
            OutlinedButton(onClick={
                try {onReady(Board.placed(placed.toList()))}
                catch(_:IllegalArgumentException) {warning="Расставьте все 10 кораблей."}
            },enabled=placed.size==lengths.size) {Text("ГОТОВО — ИГРАТЬ")}
            TextButton(onClick=onBack) {Text("Назад")}
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxHeight(),contentAlignment=Alignment.Center) {
            val side=minOf(maxWidth,maxHeight)
            Box(Modifier.size(side)) {
                NotebookGrid(placed.toList(),emptyMap(),nextLength!=null) { cell ->
                    val length=lengths.getOrNull(placed.size)
                    if(length!=null) {
                        val occupied=placed.flatten().toSet()
                        val candidate=(0 until length).map { d -> Cell(cell.x+if(horizontal)d else 0,cell.y+if(horizontal)0 else d) }.toSet()
                        val valid=candidate.all { it.x in 0..9 && it.y in 0..9 } && candidate.none { c -> occupied.any { o -> abs(c.x-o.x)<=1 && abs(c.y-o.y)<=1 } }
                        if(valid) {placed.add(candidate);warning=""} else warning="Здесь корабль не помещается или касается другого."
                    }
                }
            }
        }
    }
}

