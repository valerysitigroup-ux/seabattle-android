package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable fun FleetPlacement(onBack:()->Unit,onReady:(Board)->Unit,initialFleet:Board?=null,subtitle:String="") {
    BackHandler(onBack=onBack)
    var layout by remember {mutableStateOf(FleetLayout(initialFleet?.ships?.map {it.cells} ?: emptyList()))}
    var horizontal by remember {mutableStateOf(true)}
    var warning by remember {mutableStateOf("")}
    var side by remember {mutableFloatStateOf(1f)}
    var dragging by remember {mutableIntStateOf(-1)}
    var dragOffset by remember {mutableStateOf(Offset.Zero)}
    val delta=Cell((dragOffset.x/side*10).roundToInt(),(dragOffset.y/side*10).roundToInt())
    val candidate=layout.ships.getOrNull(dragging)?.map {Cell(it.x+delta.x,it.y+delta.y)}?.toSet()
    val preview=layout.ships.mapIndexed {i,s->if(i==dragging&&candidate!=null)candidate else s}
    fun place(cell:Cell) {layout.place(cell,horizontal)?.let {layout=it;warning=""} ?: run {if(layout.ships.size<10)warning="Корабли не должны касаться друг друга."}}
    Parchment(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize().padding(10.dp),horizontalArrangement=Arrangement.spacedBy(14.dp)) {
            Column(Modifier.width(260.dp).fillMaxHeight().background(NotebookPaper,RoundedCornerShape(16.dp)).padding(10.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                Text("РАССТАНОВКА ФЛОТА",fontSize=30.sp,fontWeight=FontWeight.Bold)
                if(subtitle.isNotEmpty())Text(subtitle,fontSize=24.sp,fontWeight=FontWeight.Bold)
                Text("Кораблей: ${layout.ships.size}/10",fontSize=26.sp,fontWeight=FontWeight.Bold,modifier=Modifier.testTag("fleet-count"))
                Text("Тяните корабль пальцем. Двойное нажатие — поворот.",fontSize=24.sp,fontWeight=FontWeight.Bold)
                if(layout.ships.size<10)Text("Следующий: ${Board.fleetLengths[layout.ships.size]} палубы. Нажмите клетку.",fontSize=24.sp,fontWeight=FontWeight.Bold)
                LargeMenuText {
                    TextButton(onClick={layout=layout.shuffled();warning=""},modifier=Modifier.testTag("shuffle-fleet")){Text("Авторасстановка")}
                    TextButton(onClick={layout=FleetLayout();warning=""}){Text("Расставить самому")}
                    TextButton(onClick={horizontal=!horizontal}){Text(if(horizontal)"Новый корабль ↔" else "Новый корабль ↕")}
                    TextButton(onClick={if(layout.ships.isNotEmpty())layout=layout.copy(ships=layout.ships.dropLast(1))}){Text("Отменить корабль")}
                    if(warning.isNotEmpty())Text(warning,color=Color(0xFFB7262B),fontSize=24.sp,fontWeight=FontWeight.Bold)
                    OutlinedButton(onClick={onReady(Board.placed(layout.ships))},enabled=layout.ships.size==10){Text("ГОТОВО — ИГРАТЬ")}
                    TextButton(onClick=onBack){Text("Назад")}
                }
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxHeight(),contentAlignment=Alignment.Center) {
                val boardSide=minOf(maxWidth,maxHeight)
                Box(Modifier.size(boardSide).clipToBounds().testTag("placement-board")
                    .semantics {stateDescription=layout.ships.joinToString(";") {s->s.sortedWith(compareBy<Cell>{it.y}.thenBy{it.x}).joinToString(","){"${it.x}:${it.y}"}}}
                    .onSizeChanged {side=it.width.toFloat()}
                    .pointerInput(side) {
                        var lastTime=0L;var lastShip=-1
                        awaitEachGesture {
                            val down=awaitFirstDown(requireUnconsumed=false,pass=PointerEventPass.Initial)
                            val start=down.position
                            fun at(p:Offset)=Cell((p.x/side*10).toInt().coerceIn(0,9),(p.y/side*10).toInt().coerceIn(0,9))
                            val index=layout.shipAt(at(start));var moving=false;var cancelled=false
                            do {
                                val event=awaitPointerEvent(PointerEventPass.Initial)
                                val change=event.changes.firstOrNull {it.id==down.id} ?: break
                                if(event.changes.count {it.pressed}>1)cancelled=true
                                val travel=change.position-start
                                if(index>=0&&!cancelled&&(moving||travel.getDistance()>viewConfiguration.touchSlop)) {
                                    moving=true;dragging=index;dragOffset=travel;change.consume()
                                }
                                if(!change.pressed) {
                                    if(!cancelled) {
                                        if(moving) {
                                            val dx=(travel.x/side*10).roundToInt();val dy=(travel.y/side*10).roundToInt()
                                            val moved=layout.move(index,dx,dy)
                                            if(moved!=null){layout=moved;warning=""}else warning="Здесь корабль не помещается или касается другого."
                                            lastShip=-1;lastTime=0
                                        } else if(index>=0&&index==lastShip&&change.uptimeMillis-lastTime<=viewConfiguration.doubleTapTimeoutMillis) {
                                            val rotated=layout.rotate(index)
                                            if(rotated!=null){layout=rotated;warning=""}else warning="Для поворота нужно свободное место."
                                            lastShip=-1;lastTime=0
                                        } else {
                                            if(index<0)place(at(start))
                                            lastShip=index;lastTime=change.uptimeMillis
                                        }
                                    }
                                    dragging=-1;dragOffset=Offset.Zero
                                }
                            }while(event.changes.any {it.pressed})
                            dragging=-1;dragOffset=Offset.Zero
                        }
                    }) {
                    NotebookGrid(preview,emptyMap(),true,cellInput=false,onCell={place(it)})
                    if(candidate!=null)Canvas(Modifier.matchParentSize()) {
                        val unit=size.width/10;val valid=layout.canReplace(dragging,candidate)
                        candidate.forEach {c->drawRect((if(valid)Color(0xFFFFCF43) else Color.Red).copy(alpha=.24f),Offset(c.x*unit,c.y*unit),Size(unit,unit),style=Stroke(3.dp.toPx()))}
                    }
                }
            }
        }
    }
}
