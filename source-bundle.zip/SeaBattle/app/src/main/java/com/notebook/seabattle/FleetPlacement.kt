package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

private val blue = Color(0xFF173B88)
private val sheet = Color(0xFFFFFCF0)

/** Placement by tapping a ship's starting cell; rotation is user-controlled. */
@Composable
fun FleetPlacement(onBack: () -> Unit, onReady: (Board) -> Unit) {
    BackHandler(onBack = onBack)
    val lengths = Board.fleetLengths
    val placed = remember { mutableStateListOf<Set<Cell>>() }
    var horizontal by remember { mutableStateOf(true) }
    var warning by remember { mutableStateOf("") }
    val nextLength = lengths.getOrNull(placed.size)

    Column(Modifier.fillMaxSize().background(sheet).verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("РАССТАНОВКА ФЛОТА", color = blue, fontSize = 24.sp)
        Text("Кораблей: ${placed.size}/10. Нажмите начальную клетку корабля.", color = blue)
        Text(if (nextLength == null) "Все корабли расставлены" else "Следующий корабль: $nextLength кл.", color = blue)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { horizontal = !horizontal }) { Text(if (horizontal) "Горизонтально ↔" else "Вертикально ↕") }
            OutlinedButton(onClick = { if (placed.isNotEmpty()) placed.removeAt(placed.lastIndex); warning = "" }) { Text("Отменить") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(onClick = {
                placed.clear()
                placed.addAll(Board.random().ships.map { it.cells })
                warning = ""
            }) { Text("Случайно") }
            OutlinedButton(onClick = { placed.clear(); warning = "" }) { Text("Очистить") }
        }
        Spacer(Modifier.height(12.dp))
        NotebookGrid(placed.toList(), emptyMap(), nextLength != null) { cell ->
            val currentLength = lengths.getOrNull(placed.size)
            if (currentLength != null) {
                val occupied = placed.flatten().toSet()
                val candidate = (0 until currentLength).map { d ->
                    Cell(cell.x + if (horizontal) d else 0, cell.y + if (horizontal) 0 else d)
                }.toSet()
                val valid = candidate.all { it.x in 0..9 && it.y in 0..9 } &&
                    candidate.none { c -> occupied.any { o -> abs(c.x-o.x) <= 1 && abs(c.y-o.y) <= 1 } }
                if (valid) { placed.add(candidate); warning = "" }
                else warning = "Здесь корабль не помещается или касается другого."
            }
        }
        if (warning.isNotEmpty()) Text(warning, color = Color(0xFFBC2626))
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            try { onReady(Board.placed(placed.toList())) }
            catch (_: IllegalArgumentException) { warning = "Расставьте все 10 кораблей." }
        }, enabled = placed.size == lengths.size) { Text("ГОТОВО — НАЧАТЬ ИГРУ") }
        OutlinedButton(onClick = onBack) { Text("НАЗАД") }
        Text("Флот останется скрытым от соперника.", fontSize = 12.sp, color = blue)
    }
}
