package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable fun FleetPlacement(onBack:()->Unit,onReady:(Board)->Unit,initialFleet:Board?=null,subtitle:String="") {
    val sprites=LocalPirateSprites.current
    BackHandler(onBack=onBack)
    var layout by remember {mutableStateOf(FleetLayout(initialFleet?.ships?.map {it.cells} ?: emptyList()))}
    var boardBounds by remember {mutableStateOf(Rect.Zero)}
    var rootOrigin by remember {mutableStateOf(Offset.Zero)}
    var panelBounds by remember {mutableStateOf(Rect.Zero)}
    val stockBounds=remember {mutableStateMapOf<Int,Rect>()}
    var activeShip by remember {mutableIntStateOf(-1)}
    var activeStock by remember {mutableIntStateOf(-1)}
    var candidate by remember {mutableStateOf<Set<Cell>?>(null)}
    var finger by remember {mutableStateOf<Offset?>(null)}
    var rejected by remember {mutableIntStateOf(0)}
    var invalid by remember {mutableStateOf(false)}
    LaunchedEffect(rejected){if(rejected>0){invalid=true;delay(650);invalid=false}}
    val preview=layout.ships.mapIndexed {i,s->if(i==activeShip&&candidate!=null)candidate!! else s}+
        if(activeStock>=0&&candidate!=null)listOf(candidate!!) else emptyList()
    fun place(cell:Cell){layout.place(cell,true)?.let {layout=it} ?: run{rejected++}}
    OceanScene {
        BoxWithConstraints(Modifier.fillMaxSize().onGloballyPositioned {rootOrigin=it.positionInRoot()}
            .pointerInput(boardBounds.width,boardBounds.height) {
                var lastTime=0L;var lastShip=-1
                awaitEachGesture {
                    val down=awaitFirstDown(requireUnconsumed=false,pass=PointerEventPass.Initial)
                    val start=down.position+rootOrigin;val unit=boardBounds.width/10
                    fun at(p:Offset)=Cell(kotlin.math.floor((p.x-boardBounds.left)/unit).toInt(),kotlin.math.floor((p.y-boardBounds.top)/unit).toInt())
                    val index=if(unit>0&&boardBounds.contains(start))layout.shipAt(at(start)) else -1
                    val stock=stockBounds.entries.firstOrNull {e->
                        val length=Board.fleetLengths[e.key]
                        val ordinal=Board.fleetLengths.take(e.key).count {it==length}
                        e.value.contains(start)&&ordinal<layout.remaining(length)
                    }?.key ?: -1
                    val length=if(stock>=0)Board.fleetLengths[stock] else layout.ships.getOrNull(index)?.size ?: 0
                    val grab=if(stock>=0)((start.x-stockBounds.getValue(stock).left)/stockBounds.getValue(stock).width*length).toInt().coerceIn(0,length-1) else 0
                    var moving=false;var cancelled=false
                    if(index>=0||stock>=0)down.consume()
                    do {
                        val event=awaitPointerEvent(PointerEventPass.Initial)
                        val change=event.changes.firstOrNull {it.id==down.id} ?: break
                        if(event.changes.count {it.pressed}>1)cancelled=true
                        val point=change.position+rootOrigin;val travel=point-start
                        if(length>0&&!cancelled&&(moving||travel.getDistance()>viewConfiguration.touchSlop)) {
                            moving=true;activeShip=index;activeStock=stock;finger=point-rootOrigin
                            candidate=if(stock>=0){val cell=at(point);(0 until length).map {Cell(cell.x-grab+it,cell.y)}.toSet()}
                                else layout.ships[index].map {Cell(it.x+(travel.x/unit).roundToInt(),it.y+(travel.y/unit).roundToInt())}.toSet()
                            change.consume()
                        }
                        if(!change.pressed) {
                            if(!cancelled) {
                                if(moving) {
                                    val next=when {
                                        index>=0&&panelBounds.contains(point)->layout.remove(index)
                                        !boardBounds.contains(point)->null
                                        stock>=0&&candidate!=null->layout.add(length,Cell(candidate!!.minOf {it.x},candidate!!.minOf {it.y}))
                                        index>=0&&candidate!=null->layout.replace(index,candidate!!)
                                        else->null
                                    }
                                    if(next!=null)layout=next else rejected++
                                    lastShip=-1;lastTime=0
                                } else if(index>=0&&index==lastShip&&change.uptimeMillis-lastTime<=viewConfiguration.doubleTapTimeoutMillis) {
                                    layout.rotate(index)?.let {layout=it} ?: run {rejected++}
                                    lastShip=-1;lastTime=0
                                } else {
                                    if(index<0&&stock<0&&unit>0&&boardBounds.contains(start))place(at(start))
                                    lastShip=index;lastTime=change.uptimeMillis
                                }
                            }
                            activeShip=-1;activeStock=-1;candidate=null;finger=null
                        }
                    }while(event.changes.any {it.pressed})
                    activeShip=-1;activeStock=-1;candidate=null;finger=null
                }
            }) {
            val panelWidth=(maxWidth*.34f).coerceIn(220.dp,290.dp)
            Row(Modifier.fillMaxSize().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                Column(Modifier.width(panelWidth).fillMaxHeight().burntPaper().onGloballyPositioned {panelBounds=it.boundsInRoot()}.padding(14.dp).testTag("fleet-panel")
                    .semantics {stateDescription="Кораблей: "+layout.ships.size+"/10"},horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Тяните корабли на поле. Двойное нажатие — поворот.",modifier=Modifier.padding(top=36.dp),fontSize=21.sp,fontWeight=FontWeight.Bold)
                    Column(Modifier.weight(1f).fillMaxWidth().padding(vertical=4.dp)) {
                        for(length in 4 downTo 1)Row(Modifier.weight(1f).fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                            Board.fleetLengths.indices.filter {Board.fleetLengths[it]==length}.forEach {slot->
                                val ordinal=Board.fleetLengths.take(slot).count {it==length};val available=ordinal<layout.remaining(length)
                                Box(Modifier.weight(1f).fillMaxHeight().testTag("stock-"+slot).onGloballyPositioned {stockBounds[slot]=it.boundsInRoot()}
                                    .semantics {contentDescription="Корабль: "+length+" палубы";stateDescription=if(available)"В запасе" else "На поле"}) {
                                    Canvas(Modifier.matchParentSize()) {
                                        val unit=minOf(size.width/(length+.2f),size.height/.98f)
                                        drawContext.canvas.saveLayer(androidx.compose.ui.geometry.Rect(Offset.Zero,size),androidx.compose.ui.graphics.Paint().apply {alpha=if(available)1f else .16f})
                                        cartoonVessel(sprites,length,unit,Offset(size.width/2,size.height/2))
                                        drawContext.canvas.restore()
                                    }
                                }
                            }
                        }
                    }
                    TextButton(onClick={layout=layout.shuffled()},modifier=Modifier.testTag("shuffle-fleet").fillMaxWidth().height(43.dp)){Text("Авторасстановка",fontSize=27.sp)}
                    TextButton(onClick={onReady(Board.placed(layout.ships))},enabled=layout.ships.size==10,contentPadding=PaddingValues(horizontal=4.dp,vertical=4.dp),modifier=Modifier.testTag("ready-fleet").fillMaxWidth().height(43.dp)){Text("Готово играть",fontSize=27.sp,maxLines=1,softWrap=false)}
                }
                BoxWithConstraints(Modifier.weight(1f).fillMaxHeight(),contentAlignment=Alignment.Center) {
                    val side=minOf(maxWidth,maxHeight)
                    Box(Modifier.size(side).clipToBounds().testTag("placement-board").onGloballyPositioned {boardBounds=it.boundsInRoot()}
                        .semantics {stateDescription=layout.ships.joinToString(";") {s->s.sortedWith(compareBy<Cell>{it.y}.thenBy{it.x}).joinToString(","){it.x.toString()+":"+it.y}}}) {
                        NotebookGrid(preview,emptyMap(),true,cellInput=false,onCell={place(it)})
                        if(candidate!=null||invalid)Canvas(Modifier.matchParentSize()) {
                            val unit=size.width/10
                            if(invalid)drawRect(Color(0xFFDA3E30),style=Stroke(4.dp.toPx()))
                            candidate?.let {cells->val valid=layout.canReplace(activeShip,cells)
                                cells.forEach {c->drawRect((if(valid)Color(0xFFFFCF43) else Color.Red).copy(alpha=.5f),Offset(c.x*unit,c.y*unit),Size(unit,unit),style=Stroke(2.dp.toPx()))}}
                        }
                    }
                }
            }
            PirateBackButton(onClick=onBack,modifier=Modifier.align(Alignment.TopStart).padding(4.dp))
            if(activeStock>=0&&finger!=null&&!boardBounds.contains(finger!!+rootOrigin))Canvas(Modifier.matchParentSize()) {
                cartoonVessel(sprites,Board.fleetLengths[activeStock],boardBounds.width/10,finger!!)
            }
        }
    }
}
