package com.notebook.seabattle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.*

private data class FinaleArtwork(val ship:ImageBitmap,val accent:ImageBitmap)
@Composable private fun rememberFinaleArtwork(outcome:MatchOutcome):FinaleArtwork {
    val resources=LocalContext.current.resources
    return remember(resources,outcome) {
        val ids=if(outcome==MatchOutcome.WIN)R.drawable.victory_galleon_v25 to R.drawable.pirate_hat_v23 else R.drawable.defeat_galleon_v23 to R.drawable.sad_lifeboat_v23
        FinaleArtwork(ImageBitmap.imageResource(resources,ids.first),ImageBitmap.imageResource(resources,ids.second))
    }
}
private fun fitted(image:ImageBitmap,area:Rect):Rect {
    val scale=minOf(area.width/image.width,area.height/image.height)
    val size=Size(image.width*scale,image.height*scale)
    return Rect(area.center-Offset(size.width/2,size.height/2),size)
}
private fun DrawScope.sprite(image:ImageBitmap,rect:Rect,alpha:Float=1f,tint:ColorFilter?=null) {
    drawImage(image,dstOffset=IntOffset(rect.left.roundToInt(),rect.top.roundToInt()),dstSize=IntSize(rect.width.roundToInt().coerceAtLeast(1),rect.height.roundToInt().coerceAtLeast(1)),alpha=alpha,colorFilter=tint,filterQuality=FilterQuality.Medium)
}

@Composable internal fun RichPirateFinale(outcome:MatchOutcome,progress:Float) {
    val art=rememberFinaleArtwork(outcome)
    Canvas(Modifier.fillMaxSize().testTag(if(outcome==MatchOutcome.WIN)"pirate-victory" else "pirate-defeat").semantics {
        stateDescription=if(outcome==MatchOutcome.WIN)"Моряки на палубе и смотровой площадке бросают шляпы. Пушки стреляют. Салют." else "Подбитый корабль тонет. Грустные моряки сидят в лодке, опустив головы."
    }) {
        if(outcome==MatchOutcome.WIN)victoryArtwork(art,progress)else defeatArtwork(art,progress)
    }
    if(outcome==MatchOutcome.WIN)Box(Modifier.fillMaxSize().testTag("pirate-hand-throws").semantics {
        stateDescription=if(hatThrowPose(progress*15,0).released)"Шляпа отпущена рукой" else "Шляпа в руке"
    })
}
private fun DrawScope.victoryArtwork(art:FinaleArtwork,p:Float) {
    val w=size.width;val h=size.height;val seconds=p*15
    drawRect(Brush.verticalGradient(listOf(Color(0xFF071A32),Color(0xFF173952),Color(0xFF06516B))))
    // True glowing rocket trails, branching bursts, sparkling fragments and soft smoke.
    repeat(7){n->fireworkBurst(seconds-(.85f+n*1.9f),Offset(w*(.09f+(n%4)*.265f),h*(.14f+(n%3)*.09f)),n)}
    val bob=sin(seconds*2.4f)*h*.005f
    val rect=fitted(art.ship,Rect(w*.10f,h*.13f+bob,w*.90f,h*.955f+bob))
    drawThrowingCrew(art,rect,seconds)
    // Flash and smoke are anchored at mouths of the drawn ship's iron cannons.
    val cycle=((seconds-.7f)/2.7f).let {it-floor(it)}
    if(seconds>=.7f&&cycle<.29f) {
        val shotIndex=floor((seconds-.7f)/2.7f).toInt()
        val ports=listOf(Offset(.18f,.775f),Offset(.39f,.81f),Offset(.55f,.82f),Offset(.69f,.80f))
        val muzzle=rect.topLeft+Offset(ports[shotIndex%ports.size].x*rect.width,ports[shotIndex%ports.size].y*rect.height)
        val q=cycle/.29f
        if(q<.22f){val r=h*(.024f+q*.16f);drawCircle(Brush.radialGradient(listOf(Color(0xFFFFFBE0),Color(0xFFFFB227),Color(0x00FF8410)),muzzle,r*2),r*2,muzzle)}
        repeat(9){i->val smoke=muzzle+Offset((i-4)*q*h*.013f,-q*h*(.07f+i*.007f));drawCircle(Color(0xFFCBC4B2).copy(alpha=(1-q)*.22f),h*(.01f+q*.025f),smoke)}
    }
    finaleWaves(seconds,h*.91f,.24f)
}

/** The painted upper arms and forearms are articulated at shoulder and elbow.
 * Their original pixels are excluded from the static body, avoiding extra static arms. */
private fun DrawScope.drawThrowingCrew(art:FinaleArtwork,rect:Rect,seconds:Float) {
    data class Arm(val shoulder:Offset,val elbow:Offset,val wrist:Offset)
    fun point(x:Float,y:Float)=rect.topLeft+Offset(x/1536f*rect.width,y/1024f*rect.height)
    val arms=listOf(
        Arm(point(204f,527f),point(194f,559f),point(188f,593f)),
        Arm(point(401f,575f),point(393f,605f),point(383f,638f)),
        Arm(point(532f,577f),point(526f,609f),point(519f,644f)),
        Arm(point(778f,598f),point(771f,627f),point(766f,658f)),
        Arm(point(927f,601f),point(920f,633f),point(916f,661f)),
        Arm(point(1060f,603f),point(1054f,629f),point(1047f,659f)),
        Arm(point(1192f,591f),point(1185f,622f),point(1178f,655f)),
        Arm(point(698f,111f),point(686f,136f),point(681f,157f))
    )
    val scale=rect.width/1536f
    fun limb(a:Offset,b:Offset,ra:Float,rb:Float):Path {
        val d=b-a;val n=Offset(-d.y,d.x)/d.getDistance().coerceAtLeast(1f)
        return Path().apply {
            moveTo((a-n*ra).x,(a-n*ra).y);lineTo((b-n*rb).x,(b-n*rb).y)
            lineTo((b+n*rb).x,(b+n*rb).y);lineTo((a+n*ra).x,(a+n*ra).y);close()
            addOval(Rect(a-Offset(ra,ra),Size(ra*2,ra*2)))
            addOval(Rect(b-Offset(rb,rb),Size(rb*2,rb*2)))
        }
    }
    val upper=arms.map {limb(it.shoulder,it.elbow,10f*scale,8f*scale)}
    val lower=arms.map {limb(it.elbow,it.wrist,8f*scale,7f*scale)}
    val removed=Path().apply {upper.forEach {addPath(it)};lower.forEach {addPath(it)}}
    clipPath(removed,ClipOp.Difference){sprite(art.ship,rect)}
    arms.forEachIndexed {i,arm->
        val pose=hatThrowPose(seconds,i)
        withTransform({rotate(pose.shoulderDegrees,arm.shoulder)}) {
            clipPath(upper[i]){sprite(art.ship,rect)}
            withTransform({rotate(pose.elbowDegrees,arm.elbow)}){clipPath(lower[i]){sprite(art.ship,rect)}}
        }
        val hand=throwingHand(arm.shoulder,arm.elbow,arm.wrist,pose)
        val release=throwingHand(arm.shoulder,arm.elbow,arm.wrist,HatThrowPose(148f,-18f,true,0f))
        val hat=thrownHat(hand,release,pose,size.height*(if(i==7).10f else .22f),size.height*(if(i%2==0)-.035f else .035f))
        val side=size.height*(if(i==7).047f else .058f)
        withTransform({rotate(if(pose.released)pose.flight*300 else pose.shoulderDegrees*.15f,hat)}) {
            sprite(art.accent,Rect(hat-Offset(side/2,side/2),Size(side,side)))
        }
    }
}
private fun DrawScope.fireworkBurst(age:Float,center:Offset,index:Int) {
    if(age<-.6f||age>1.75f)return
    val h=size.height
    val colors=listOf(Color(0xFFFFD985),Color(0xFFFF6575),Color(0xFF8EF1E4),Color(0xFFC1A2FF))
    val color=colors[index%colors.size]
    if(age<0){val q=(age+.6f)/.6f;val head=Offset(center.x,center.y+(1-q)*h*.55f);drawLine(Color(0xFFFFDB9E).copy(alpha=.65f),head+Offset(0f,h*.06f),head,h*.003f,StrokeCap.Round);drawCircle(Color(0xFFFFF3CC),h*.004f,head);return}
    val q=age/1.75f;val fade=(1-q).coerceIn(0f,1f)
    drawCircle(Brush.radialGradient(listOf(color.copy(alpha=.16f*fade),Color.Transparent),center,h*.22f),h*.22f,center)
    repeat(84){i->
        val a=i*2*PI.toFloat()/84+index*.38f;val speed=h*(.085f+(i%9)*.014f)
        val direction=Offset(cos(a),sin(a));val radius=speed*(1-exp(-age*2.1f))
        val particle=center+direction*radius+Offset(0f,age*age*h*.035f)
        val tail=particle-direction*h*(.006f+fade*.015f)-Offset(0f,age*h*.006f)
        val sparkle=(.55f+.45f*sin(i*7f+age*29)).coerceIn(0f,1f)
        drawLine(color.copy(alpha=fade*(.55f+sparkle*.45f)),tail,particle,h*.0018f,StrokeCap.Round)
        if(i%3==0)drawCircle(Color(0xFFFFF4CA).copy(alpha=fade*sparkle),h*.002f,particle)
        if(i%12==0)drawCircle(color.copy(alpha=fade*.08f),h*.017f,particle)
    }
    if(age<.12f)drawCircle(Color(0xFFFFF9D7).copy(alpha=1-age/.12f),h*.025f,center)
}
private fun DrawScope.defeatArtwork(art:FinaleArtwork,p:Float) {
    val w=size.width;val h=size.height;val seconds=p*8
    drawRect(Brush.verticalGradient(listOf(Color(0xFF111D2C),Color(0xFF264554),Color(0xFF07556A))))
    val line=h*.64f
    val initial=fitted(art.ship,Rect(w*.025f,h*.09f,w*.73f,h*.92f))
    val falling=initial.translate(Offset(0f,p*h*.64f))
    fun DrawScope.wreck(alpha:Float,tint:ColorFilter?=null){withTransform({rotate(p*13f,falling.center)}){sprite(art.ship,falling,alpha,tint)}}
    clipRect(bottom=line){wreck(1f-p*.18f)}
    clipRect(top=line){wreck((1-p)*.45f,ColorFilter.tint(Color(0xFF18748C),BlendMode.SrcAtop))}
    drawRect(Brush.verticalGradient(listOf(Color(0xFF124B60).copy(alpha=.38f),Color(0xFF06394F).copy(alpha=.9f)),startY=line,endY=h),topLeft=Offset(0f,line),size=Size(w,h-line))
    repeat(17){i->val q=(p*2.5f+i*.083f)%1f;val x=w*(.12f+(i%7)*.065f)+sin(q*9+i)*h*.009f;val y=line+h*.21f-q*h*.28f
        if(y>=line-h*.02f)drawCircle(Color(0xFFBCF7FF).copy(alpha=(1-q)*.6f),h*(.003f+(i%3)*.002f),Offset(x,y),style=Stroke(h*.0015f))}
    finaleWaves(seconds,line,.85f)
    val boat=fitted(art.accent,Rect(w*.64f,h*.55f,w*.99f,h*.94f)).translate(Offset(0f,sin(seconds*2)*h*.008f))
    withTransform({rotate(sin(seconds*1.8f)*1.4f,boat.center)}){sprite(art.accent,boat)}
    finaleWaves(seconds+1.4f,h*.91f,.4f)
}
private fun DrawScope.finaleWaves(seconds:Float,waterline:Float,opacity:Float) {
    val w=size.width;val h=size.height
    repeat(4){row->val wave=Path();repeat(65){i->val x=i*w/64;val y=waterline+row*h*.027f+sin(i*.4f-seconds*2.3f+row)*h*.007f;if(i==0)wave.moveTo(x,y)else wave.lineTo(x,y)}
        drawPath(wave,Color(0xFF16758A).copy(alpha=opacity*.7f),style=Stroke(h*.018f,cap=StrokeCap.Round))
        drawPath(wave,Color(0xFFBAEEE8).copy(alpha=opacity*.7f),style=Stroke(h*.0024f,cap=StrokeCap.Round))
    }
}
