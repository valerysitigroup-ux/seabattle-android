package com.notebook.seabattle

import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*

internal data class BoardViewport(val scale:Float=1f,val offset:Offset=Offset.Zero) {
    fun transform(factor:Float,centroid:Offset,pan:Offset,side:Float):BoardViewport {
        if(!factor.isFinite()||!centroid.x.isFinite()||!centroid.y.isFinite()||!pan.x.isFinite()||!pan.y.isFinite()||!side.isFinite()||side<=0)return this
        val next=(scale*factor).coerceIn(1f,3f);val ratio=next/scale
        if(next==1f)return BoardViewport()
        val center=Offset(side/2,side/2)
        val translated=offset*ratio+(centroid-center)*(1-ratio)+pan
        val limit=side*(next-1)/2
        return BoardViewport(next,Offset(translated.x.coerceIn(-limit,limit),translated.y.coerceIn(-limit,limit)))
    }
}
@Stable internal class BoardZoomState {
    var viewport by mutableStateOf(BoardViewport());private set
    var side by mutableFloatStateOf(1f);private set
    fun resize(value:Float){if(value>0&&value.isFinite()){viewport=viewport.copy(offset=viewport.offset*(value/side));side=value}}
    fun gesture(factor:Float,centroid:Offset,pan:Offset)=run {viewport=viewport.transform(factor,centroid,pan,side)}
    fun zoom(factor:Float)=gesture(factor,Offset(side/2,side/2),Offset.Zero)
    fun reset(){viewport=BoardViewport()}
}
@Composable internal fun ZoomableBoard(view:BattleView,enabled:Boolean,tag:String,zoom:BoardZoomState,onShot:(Cell)->Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(1f).clipToBounds().testTag(tag)
        .onSizeChanged {zoom.resize(it.width.toFloat())}
        .semantics {stateDescription="Масштаб ${(zoom.viewport.scale*100).toInt()} процентов"}
        .pointerInput(zoom) {detectTransformGestures {centroid,pan,scale,_->zoom.gesture(scale,centroid,pan)}}) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            scaleX=zoom.viewport.scale;scaleY=zoom.viewport.scale
            translationX=zoom.viewport.offset.x;translationY=zoom.viewport.offset.y
        }) {
            NotebookGrid(view.ships,view.shots,enabled,pending=view.pending,sunkShips=view.sunk,battleEffects=true,onCell=onShot)
        }
    }
}
