package com.notebook.seabattle

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*

internal data class BoardViewport(val scale:Float=1f,val offset:Offset=Offset.Zero) {
    fun transform(factor:Float,centroid:Offset,pan:Offset,side:Float):BoardViewport {
        if(!factor.isFinite()||!centroid.x.isFinite()||!centroid.y.isFinite()||!pan.x.isFinite()||!pan.y.isFinite()||!side.isFinite()||side<=0)return this
        val next=(scale*factor).coerceIn(1f,3f);val ratio=next/scale
        if(next==1f)return BoardViewport()
        val center=Offset(side/2,side/2)
        val translated=offset*ratio+(centroid-center)*(1-ratio)+pan
        val limit=side*(next-1)/2
        return BoardViewport(next,Offset(translated.x.coerceIn(-limit,limit),translated.y.coerceIn(-limit,limit)))
    }
}
@Stable internal class BoardZoomState {
    var viewport by mutableStateOf(BoardViewport());private set
    var side by mutableFloatStateOf(1f);private set
    fun resize(value:Float){if(value>0&&value.isFinite()){viewport=viewport.copy(offset=viewport.offset*(value/side));side=value}}
    fun gesture(factor:Float,centroid:Offset,pan:Offset)=run {viewport=viewport.transform(factor,centroid,pan,side)}
    fun zoom(factor:Float)=gesture(factor,Offset(side/2,side/2),Offset.Zero)
    fun reset(){viewport=BoardViewport()}
}
@Composable internal fun ZoomableBoard(view:BattleView,enabled:Boolean,tag:String,zoom:BoardZoomState,onShot:(Cell)->Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(1f).clipToBounds().testTag(tag)
        .onSizeChanged {zoom.resize(it.width.toFloat())}
        .semantics {stateDescription="Масштаб ${(zoom.viewport.scale*100).toInt()} процентов"}
        .pointerInput(zoom) {
            // See multi-touch before child clickables can consume it. A tap remains
            // a normal cell click; a pinch or a drag never becomes a shot on release.
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed=false,pass=PointerEventPass.Initial)
                var transforming=false;var travel=Offset.Zero
                do {
                    val event=awaitPointerEvent(PointerEventPass.Initial)
                    val pressed=event.changes.count {it.pressed}
                    val pan=event.calculatePan()
                    travel+=pan
                    if(pressed>=2 || (zoom.viewport.scale>1f && travel.getDistance()>viewConfiguration.touchSlop))transforming=true
                    if(transforming) {
                        if(pressed>0)zoom.gesture(event.calculateZoom(),event.calculateCentroid(useCurrent=false),pan)
                        event.changes.forEach {it.consume()}
                    }
                } while(event.changes.any {it.pressed})
            }
        }) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            scaleX=zoom.viewport.scale;scaleY=zoom.viewport.scale
            translationX=zoom.viewport.offset.x;translationY=zoom.viewport.offset.y
        }) {
            NotebookGrid(view.ships,view.shots,enabled,pending=view.pending,sunkShips=view.sunk,battleEffects=true,onCell=onShot)
        }
    }
}
