package com.notebook.seabattle

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font

val GreenInk=Color(0xFF17643D)
val NotebookPaper=Color(0xFFE6C58A)
private val PenFont=FontFamily(Font(R.font.caveat_regular,FontWeight.Normal),Font(R.font.caveat_bold,FontWeight.Bold))
@Composable fun NotebookTheme(content:@Composable ()->Unit) {
    val t=Typography()
    MaterialTheme(colorScheme=lightColorScheme(primary=GreenInk,secondary=GreenInk,tertiary=GreenInk,
        background=NotebookPaper,surface=NotebookPaper,surfaceContainerHigh=NotebookPaper,surfaceContainer=NotebookPaper,onBackground=GreenInk,onSurface=GreenInk,
        onSurfaceVariant=GreenInk,outline=GreenInk.copy(alpha=.65f)),typography=Typography(
        headlineLarge=t.headlineLarge.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        headlineMedium=t.headlineMedium.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        headlineSmall=t.headlineSmall.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        titleLarge=t.titleLarge.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        titleMedium=t.titleMedium.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        titleSmall=t.titleSmall.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        bodyLarge=t.bodyLarge.copy(fontFamily=PenFont),bodyMedium=t.bodyMedium.copy(fontFamily=PenFont),
        bodySmall=t.bodySmall.copy(fontFamily=PenFont),labelLarge=t.labelLarge.copy(fontFamily=PenFont,fontWeight=FontWeight.Bold),
        labelMedium=t.labelMedium.copy(fontFamily=PenFont),labelSmall=t.labelSmall.copy(fontFamily=PenFont)),content={CompositionLocalProvider(LocalContentColor provides GreenInk,content=content)})
}
