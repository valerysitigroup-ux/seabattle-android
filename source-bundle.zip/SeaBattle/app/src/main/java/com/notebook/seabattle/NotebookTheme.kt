package com.notebook.seabattle

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val GreenInk=Color(0xFF17643D)
val NotebookPaper=Color(0xFFFFFCF0)
@Composable fun NotebookTheme(content:@Composable ()->Unit) {
    val t=Typography()
    MaterialTheme(colorScheme=lightColorScheme(primary=GreenInk,secondary=GreenInk,tertiary=GreenInk,
        background=NotebookPaper,surface=NotebookPaper,onBackground=GreenInk,onSurface=GreenInk,
        onSurfaceVariant=GreenInk,outline=GreenInk.copy(alpha=.65f)),typography=Typography(
        headlineLarge=t.headlineLarge.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        headlineMedium=t.headlineMedium.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        headlineSmall=t.headlineSmall.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        titleLarge=t.titleLarge.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        titleMedium=t.titleMedium.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        titleSmall=t.titleSmall.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        bodyLarge=t.bodyLarge.copy(fontFamily=FontFamily.Cursive),bodyMedium=t.bodyMedium.copy(fontFamily=FontFamily.Cursive),
        bodySmall=t.bodySmall.copy(fontFamily=FontFamily.Cursive),labelLarge=t.labelLarge.copy(fontFamily=FontFamily.Cursive,fontWeight=FontWeight.Bold),
        labelMedium=t.labelMedium.copy(fontFamily=FontFamily.Cursive),labelSmall=t.labelSmall.copy(fontFamily=FontFamily.Cursive)),content=content)
}
