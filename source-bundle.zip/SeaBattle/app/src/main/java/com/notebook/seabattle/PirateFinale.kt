package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlin.math.*

enum class MatchOutcome { WIN, LOSS }

@Composable fun PirateMenuButton(onClick:()->Unit,modifier:Modifier=Modifier) {
    PirateFlagButton(onClick,modifier,"open-menu","Пиратское меню")
}

/** The same black flag replaces written back buttons throughout the game. */
@Composable fun PirateBackButton(onClick:()->Unit,modifier:Modifier=Modifier) {
    PirateFlagButton(onClick,modifier,"back-flag","Назад")
}

@Composable private fun PirateFlagButton(onClick:()->Unit,modifier:Modifier,tag:String,label:String) {
    IconButton(onClick=onClick,modifier=modifier.size(48.dp).testTag(tag).semantics {contentDescription=label}) {
        Canvas(Modifier.size(36.dp)) {
            val u=size.width
            drawLine(Color(0xFFB98744),Offset(u*.17f,u*.12f),Offset(u*.17f,u*.92f),u*.07f,StrokeCap.Round)
            val flag=Path().apply {moveTo(u*.2f,u*.14f);cubicTo(u*.45f,u*.02f,u*.7f,u*.28f,u*.95f,u*.1f);lineTo(u*.92f,u*.63f);cubicTo(u*.7f,u*.8f,u*.45f,u*.48f,u*.2f,u*.62f);close()}
            drawPath(flag,Color(0xFF171A24));drawPath(flag,Color(0xFF675443),style=Stroke(u*.025f))
            withTransform({translate(u*.57f,u*.36f);scale(u*.11f,u*.11f,Offset.Zero)}){pirateSkull(Offset.Zero,1f)}
        }
    }
}

@Composable fun PirateHomeButton(onClick:()->Unit,modifier:Modifier=Modifier) {
    IconButton(onClick=onClick,modifier=modifier.size(50.dp).testTag("home-flag").semantics {contentDescription="Главное меню"}) {
        Canvas(Modifier.size(39.dp)) {
            val u=size.width
            drawLine(Color(0xFF9C733B),Offset(u*.15f,u*.1f),Offset(u*.15f,u*.94f),u*.06f,StrokeCap.Round)
            val f=Path().apply {moveTo(u*.19f,u*.13f);cubicTo(u*.5f,u*.01f,u*.7f,u*.25f,u*.96f,u*.1f);lineTo(u*.93f,u*.69f);cubicTo(u*.67f,u*.84f,u*.46f,u*.5f,u*.19f,u*.66f);close()}
            drawPath(f,Color(0xFF11151B));drawPath(f,Color(0xFF7D603D),style=Stroke(u*.025f))
            val house=Path().apply {moveTo(u*.34f,u*.39f);lineTo(u*.57f,u*.22f);lineTo(u*.8f,u*.42f);lineTo(u*.74f,u*.42f);lineTo(u*.74f,u*.61f);lineTo(u*.62f,u*.6f);lineTo(u*.62f,u*.45f);lineTo(u*.52f,u*.44f);lineTo(u*.52f,u*.58f);lineTo(u*.4f,u*.56f);lineTo(u*.4f,u*.39f);close()}
            drawPath(house,Color(0xFFF1E4C2))
        }
    }
}

internal const val VICTORY_DURATION_MS=15000
internal const val DEFEAT_DURATION_MS=8000

@Composable internal fun MatchFinale(outcome:MatchOutcome?,onHome:()->Unit) {
    val finish by rememberUpdatedState(onHome)
    var returned by remember(outcome){mutableStateOf(false)}
    val audio=LocalGameAudio.current
    val goHome={if(!returned){returned=true;audio?.stopFinaleEffects();finish()}}
    var visible by remember(outcome){mutableStateOf(false)}
    val progress=remember(outcome){Animatable(0f)}
    LaunchedEffect(outcome) {
        if(outcome==null)return@LaunchedEffect
        delay(3400)
        visible=true
        if(outcome==MatchOutcome.WIN) {
            audio?.victory()
            coroutineScope {
                val fireworks=launch {delay(850);repeat(7){audio?.firework();delay(1900)}}
                val cannons=launch {delay(700);repeat(6){audio?.cannonShot();delay(2700)}}
                progress.animateTo(1f,tween(VICTORY_DURATION_MS,easing=LinearEasing))
                fireworks.cancel();cannons.cancel()
            }
        } else {
            audio?.defeat();progress.animateTo(1f,tween(DEFEAT_DURATION_MS,easing=LinearEasing))
        }
        if(!returned){returned=true;audio?.stopFinaleEffects();finish()}
    }
    DisposableEffect(visible,audio){onDispose{if(visible)audio?.stopFinaleEffects()}}
    if(!visible||outcome==null)return
    Box(Modifier.fillMaxSize().testTag("match-finale").pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent()}}}) {
        RichPirateFinale(outcome,progress.value)
        if(outcome==MatchOutcome.WIN) {
            Parchment(Modifier.align(Alignment.TopCenter).padding(top=8.dp)) {Text("ЙО-ХО-ХО! ПОБЕДА!",Modifier.padding(horizontal=24.dp,vertical=8.dp),fontSize=40.sp,color=GreenInk)}
        } else {
            Parchment(Modifier.align(Alignment.TopCenter).padding(top=8.dp)) {Text("Флот потоплен…",Modifier.padding(horizontal=24.dp,vertical=8.dp),fontSize=40.sp,color=GreenInk)}
            Box(Modifier.matchParentSize().testTag("defeat-submersion").semantics {stateDescription=(progress.value*100).toInt().toString()+"%"})
        }
        PirateHomeButton(onClick=goHome,modifier=Modifier.align(Alignment.TopStart).padding(4.dp))
    }
}
