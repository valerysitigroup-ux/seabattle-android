package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlin.math.*

enum class MatchOutcome { WIN, LOSS }

@Composable fun PirateMenuButton(onClick:()->Unit,modifier:Modifier=Modifier) {
    IconButton(onClick=onClick,modifier=modifier.size(46.dp).testTag("open-menu").semantics {contentDescription="Пиратское меню"}) {
        Canvas(Modifier.size(36.dp)) {
            val u=size.width
            drawLine(Color(0xFFB98744),Offset(u*.17f,u*.12f),Offset(u*.17f,u*.92f),u*.07f,StrokeCap.Round)
            val flag=Path().apply {moveTo(u*.2f,u*.14f);cubicTo(u*.45f,u*.02f,u*.7f,u*.28f,u*.95f,u*.1f);lineTo(u*.92f,u*.63f);cubicTo(u*.7f,u*.8f,u*.45f,u*.48f,u*.2f,u*.62f);close()}
            drawPath(flag,Color(0xFF171A24));drawPath(flag,Color(0xFF675443),style=Stroke(u*.025f))
            withTransform({translate(u*.57f,u*.36f);scale(u*.11f,u*.11f,Offset.Zero)}){pirateSkull(Offset.Zero,1f)}
        }
    }
}

@Composable fun PirateHomeButton(onClick:()->Unit,modifier:Modifier=Modifier) {
    IconButton(onClick=onClick,modifier=modifier.size(50.dp).testTag("home-flag").semantics {contentDescription="Главное меню"}) {
        Canvas(Modifier.size(39.dp)) {
            val u=size.width
            drawLine(Color(0xFF9C733B),Offset(u*.15f,u*.1f),Offset(u*.15f,u*.94f),u*.06f,StrokeCap.Round)
            val f=Path().apply {moveTo(u*.19f,u*.13f);cubicTo(u*.5f,u*.01f,u*.7f,u*.25f,u*.96f,u*.1f);lineTo(u*.93f,u*.69f);cubicTo(u*.67f,u*.84f,u*.46f,u*.5f,u*.19f,u*.66f);close()}
            drawPath(f,Color(0xFF11151B));drawPath(f,Color(0xFF7D603D),style=Stroke(u*.025f))
            val house=Path().apply {moveTo(u*.34f,u*.39f);lineTo(u*.57f,u*.22f);lineTo(u*.8f,u*.42f);lineTo(u*.74f,u*.42f);lineTo(u*.74f,u*.61f);lineTo(u*.62f,u*.6f);lineTo(u*.62f,u*.45f);lineTo(u*.52f,u*.44f);lineTo(u*.52f,u*.58f);lineTo(u*.4f,u*.56f);lineTo(u*.4f,u*.39f);close()}
            drawPath(house,Color(0xFFF1E4C2))
        }
    }
}

@Composable internal fun MatchFinale(outcome:MatchOutcome?,onHome:()->Unit) {
    val finish by rememberUpdatedState(onHome)
    var returned by remember(outcome){mutableStateOf(false)}
    val goHome={if(!returned){returned=true;finish()}}
    val audio=LocalGameAudio.current
    var visible by remember(outcome){mutableStateOf(false)}
    val progress=remember(outcome){Animatable(0f)}
    LaunchedEffect(outcome) {
        if(outcome==null)return@LaunchedEffect
        delay(3400) // Finish sinking the last vessel on the board first.
        visible=true
        if(outcome==MatchOutcome.WIN) {
            audio?.victory()
            coroutineScope {
                launch {delay(2300);repeat(3){audio?.impact(true);delay(700)}}
                progress.animateTo(1f,tween(15000,easing=LinearEasing))
            }
        } else {
            audio?.defeat();progress.animateTo(1f,tween(3000,easing=LinearEasing))
        }
        if(!returned){returned=true;finish()}
    }
    if(!visible||outcome==null)return
    OceanScene {
        Box(Modifier.fillMaxSize().background(Color(0xFF073D61).copy(alpha=.18f)).testTag("match-finale").pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent()}}}
            .semantics {stateDescription=if(outcome==MatchOutcome.WIN)"Победа: пираты бросают шляпы, пушки и фейерверк" else "Поражение: короткая грустная музыка"}) {
            if(outcome==MatchOutcome.WIN) {
                Canvas(Modifier.matchParentSize().testTag("pirate-victory")) {
                    val p=progress.value;val w=size.width;val h=size.height
                    cartoonVessel(4,w*.15f,Offset(w*.5f,h*.82f))
                    repeat(6) {i->
                        val x=w*(.29f+i*.084f);val y=h*.7f
                        pirateCrew(Offset(x,y),h*.043f,i,false,p,hat=false)
                        val q=(p*6f+i*.08f)%1f
                        val hat=Offset(x+sin(q*PI.toFloat())*w*.025f,y-h*.08f-sin(q*PI.toFloat())*h*.38f)
                        withTransform({rotate(q*270f,hat)}){pirateHat(hat,h*.04f)}
                    }
                    for(dir in listOf(-1f,1f)) {
                        val x=if(dir<0)w*.11f else w*.89f;val y=h*.85f
                        drawCircle(Color(0xFF4A2D25),h*.07f,Offset(x,y))
                        drawLine(Color(0xFF252938),Offset(x,y-h*.03f),Offset(x-dir*h*.12f,y-h*.12f),h*.07f,StrokeCap.Round)
                        val q=(p*12)%1f
                        if(q<.5f)repeat(10){i->val a=i*PI.toFloat()/5;val d=Offset(cos(a),sin(a));drawLine(Color(0xFFFFD63D).copy(alpha=1-q*2),Offset(x-dir*h*.12f,y-h*.12f)+d*h*q*.35f,Offset(x-dir*h*.12f,y-h*.12f)+d*h*(q*.35f+.04f),h*.012f,StrokeCap.Round)}
                    }
                    val colors=listOf(Color(0xFFFFCF37),Color(0xFFFF617B),Color(0xFF76F1FF),Color(0xFFBE8DFF))
                    repeat(7){n->
                        val q=(p*7+n*.17f)%1f;val c=Offset(w*(.08f+n*.14f),h*(.15f+(n%3)*.12f))
                        repeat(18){i->val a=i*PI.toFloat()/9;val d=Offset(cos(a),sin(a));val radius=h*q*.2f
                            drawLine(colors[n%colors.size].copy(alpha=1-q),c+d*radius,c+d*(radius+h*.025f)+Offset(0f,q*q*h*.07f),h*.007f,StrokeCap.Round)}
                    }
                }
                Parchment(Modifier.align(Alignment.TopCenter).padding(top=8.dp)) {Text("ЙО-ХО-ХО! ПОБЕДА!",Modifier.padding(horizontal=24.dp,vertical=8.dp),fontSize=40.sp,color=GreenInk)}
            } else {
                Parchment(Modifier.align(Alignment.Center)){Column(Modifier.padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Флот потоплен…",fontSize=48.sp,color=GreenInk)
                    Text("Капитан, мы ещё вернёмся!",fontSize=32.sp,color=GreenInk)
                }}
            }
            PirateHomeButton(onClick=goHome,modifier=Modifier.align(Alignment.TopStart).padding(4.dp))
        }
    }
}
