package com.notebook.seabattle

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlin.math.*

enum class MatchOutcome { WIN, LOSS }

@Composable fun PirateMenuButton(onClick:()->Unit,modifier:Modifier=Modifier) {
    IconButton(onClick=onClick,modifier=modifier.size(46.dp).testTag("open-menu").semantics {contentDescription="Пиратское меню"}) {
        Canvas(Modifier.size(36.dp)) {
            val u=size.width
            drawLine(Color(0xFFB98744),Offset(u*.17f,u*.12f),Offset(u*.17f,u*.92f),u*.07f,StrokeCap.Round)
            val flag=Path().apply {moveTo(u*.2f,u*.14f);cubicTo(u*.45f,u*.02f,u*.7f,u*.28f,u*.95f,u*.1f);lineTo(u*.92f,u*.63f);cubicTo(u*.7f,u*.8f,u*.45f,u*.48f,u*.2f,u*.62f);close()}
            drawPath(flag,Color(0xFF171A24));drawPath(flag,Color(0xFF675443),style=Stroke(u*.025f))
            withTransform({translate(u*.57f,u*.36f);scale(u*.11f,u*.11f,Offset.Zero)}){pirateSkull(Offset.Zero,1f)}
        }
    }
}

@Composable internal fun MatchFinale(outcome:MatchOutcome?,onHome:()->Unit) {
    val finish by rememberUpdatedState(onHome)
    val audio=LocalGameAudio.current
    var visible by remember(outcome){mutableStateOf(false)}
    val progress=remember(outcome){Animatable(0f)}
    LaunchedEffect(outcome) {
        if(outcome==null)return@LaunchedEffect
        delay(3400) // Finish sinking the last vessel on the board first.
        visible=true
        if(outcome==MatchOutcome.WIN) {
            audio?.victory()
            coroutineScope {
                launch {delay(2300);repeat(3){audio?.impact(true);delay(700)}}
                progress.animateTo(1f,tween(6500,easing=LinearEasing))
            }
        } else {
            audio?.defeat();progress.animateTo(1f,tween(3000,easing=LinearEasing))
        }
        finish()
    }
    if(!visible||outcome==null)return
    OceanScene {
        Box(Modifier.fillMaxSize().background(Color(0xFF073D61).copy(alpha=.18f)).testTag("match-finale").pointerInput(Unit){awaitPointerEventScope {while(true){awaitPointerEvent()}}}
            .semantics {stateDescription=if(outcome==MatchOutcome.WIN)"Победа: пираты бросают шляпы, пушки и фейерверк" else "Поражение: короткая грустная музыка"}) {
            if(outcome==MatchOutcome.WIN) {
                Canvas(Modifier.matchParentSize().testTag("pirate-victory")) {
                    val p=progress.value;val w=size.width;val h=size.height
                    cartoonVessel(4,w*.15f,Offset(w*.5f,h*.82f))
                    repeat(6) {i->
                        val x=w*(.29f+i*.084f);val y=h*.7f
                        pirateCrew(Offset(x,y),h*.043f,i,false,p,hat=false)
                        val q=(p*2.5f+i*.08f)%1f
                        val hat=Offset(x+sin(q*PI.toFloat())*w*.025f,y-h*.08f-sin(q*PI.toFloat())*h*.38f)
                        withTransform({rotate(q*270f,hat)}){pirateHat(hat,h*.04f)}
                    }
                    for(dir in listOf(-1f,1f)) {
                        val x=if(dir<0)w*.11f else w*.89f;val y=h*.85f
                        drawCircle(Color(0xFF4A2D25),h*.07f,Offset(x,y))
                        drawLine(Color(0xFF252938),Offset(x,y-h*.03f),Offset(x-dir*h*.12f,y-h*.12f),h*.07f,StrokeCap.Round)
                        val q=(p*5)%1f
                        if(q<.5f)repeat(10){i->val a=i*PI.toFloat()/5;val d=Offset(cos(a),sin(a));drawLine(Color(0xFFFFD63D).copy(alpha=1-q*2),Offset(x-dir*h*.12f,y-h*.12f)+d*h*q*.35f,Offset(x-dir*h*.12f,y-h*.12f)+d*h*(q*.35f+.04f),h*.012f,StrokeCap.Round)}
                    }
                    val colors=listOf(Color(0xFFFFCF37),Color(0xFFFF617B),Color(0xFF76F1FF),Color(0xFFBE8DFF))
                    repeat(7){n->
                        val q=(p*3+n*.17f)%1f;val c=Offset(w*(.08f+n*.14f),h*(.15f+(n%3)*.12f))
                        repeat(18){i->val a=i*PI.toFloat()/9;val d=Offset(cos(a),sin(a));val radius=h*q*.2f
                            drawLine(colors[n%colors.size].copy(alpha=1-q),c+d*radius,c+d*(radius+h*.025f)+Offset(0f,q*q*h*.07f),h*.007f,StrokeCap.Round)}
                    }
                }
                Text("ЙО-ХО-ХО! ПОБЕДА!",Modifier.align(Alignment.TopCenter).padding(12.dp),fontSize=48.sp,color=Color(0xFFFFD95C))
            } else {
                Column(Modifier.align(Alignment.Center),horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Флот потоплен…",fontSize=48.sp,color=Color(0xFFFFD999))
                    Text("Капитан, мы ещё вернёмся!",fontSize=32.sp,color=Color(0xFFFFE6B8))
                }
            }
            TextButton(onClick=finish,modifier=Modifier.align(Alignment.BottomCenter)){Text("В главное меню",fontSize=28.sp,color=Color(0xFFFFE6A5))}
        }
    }
}
