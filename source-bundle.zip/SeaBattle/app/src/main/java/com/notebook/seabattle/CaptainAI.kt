package com.notebook.seabattle

import kotlin.math.abs
import kotlin.random.Random

/** Knows only the results of its own shots, never the opposing board. */
class CaptainAI(private val random: Random = Random.Default) {
    private val fired = linkedMapOf<Cell, ShotResult>()
    private val wounded = linkedSetOf<Cell>()
    private val excluded = mutableSetOf<Cell>()
    private val remaining = Board.fleetLengths.toMutableList()
    private var pending: Cell? = null
    private var won = false

    fun nextShot(): Cell {
        check(pending == null && !won)
        val available = (0..9).flatMap { y -> (0..9).map { x -> Cell(x,y) } }
            .filter { it !in fired && it !in excluded }
        check(available.isNotEmpty())
        val targets = if (wounded.isEmpty()) emptyList() else {
            val xs = wounded.map { it.x }; val ys = wounded.map { it.y }
            when {
                wounded.size > 1 && xs.distinct().size == 1 -> listOf(Cell(xs.first(),ys.min()-1), Cell(xs.first(),ys.max()+1))
                wounded.size > 1 && ys.distinct().size == 1 -> listOf(Cell(xs.min()-1,ys.first()), Cell(xs.max()+1,ys.first()))
                else -> wounded.flatMap { c -> listOf(Cell(c.x-1,c.y),Cell(c.x+1,c.y),Cell(c.x,c.y-1),Cell(c.x,c.y+1)) }
            }.filter { it in available }
        }
        val candidates = targets.ifEmpty { available }
        // Count legal placements of the remaining vessels: hunt without peeking.
        val scores = mutableMapOf<Cell, Int>()
        for (length in remaining) for (horizontal in listOf(true,false)) {
            for (y in 0..9) for (x in 0..9) {
                val cells = (0 until length).map { d -> Cell(x + if(horizontal)d else 0,y + if(horizontal)0 else d) }
                if (cells.any { it.x !in 0..9 || it.y !in 0..9 || it in excluded || fired[it] == ShotResult.MISS }) continue
                if (cells.any { fired[it] == ShotResult.SUNK || fired[it] == ShotResult.WIN }) continue
                if (wounded.isNotEmpty() && !cells.containsAll(wounded)) continue
                for (c in cells) if(c in candidates) scores[c] = (scores[c] ?: 0) + 1
            }
        }
        val best = candidates.maxOf { scores[it] ?: 0 }
        return candidates.filter { (scores[it] ?: 0) == best }.random(random).also { pending = it }
    }

    fun accept(cell: Cell, result: ShotResult) {
        require(cell == pending && result != ShotResult.ALREADY_SHOT)
        pending = null
        fired[cell] = result
        if (result == ShotResult.HIT || result == ShotResult.SUNK || result == ShotResult.WIN) wounded.add(cell)
        if (result == ShotResult.SUNK || result == ShotResult.WIN) {
            remaining.remove(wounded.size)
            wounded.forEach { hit ->
                for(dx in -1..1) for(dy in -1..1) excluded.add(Cell(hit.x+dx,hit.y+dy))
            }
            wounded.clear()
        }
        if(result == ShotResult.WIN) won = true
    }
}

enum class SoloTurn { PLAYER, COMPUTER }

class SoloMatch(
    val own: Board = Board.random(),
    val opponent: Board = Board.random(),
    private val captain: CaptainAI = CaptainAI()
) {
    var turn = SoloTurn.PLAYER
        private set
    var winner: SoloTurn? = null
        private set
    var message = "Ваш ход. Выберите клетку на поле противника."
        private set

    fun playerFire(cell: Cell): ShotResult? {
        if(turn != SoloTurn.PLAYER || winner != null) return null
        val result = opponent.shoot(cell)
        when(result) {
            ShotResult.MISS -> { turn=SoloTurn.COMPUTER; message="Мимо. Соперник выбирает цель…" }
            ShotResult.HIT -> message="Попадание! Стреляйте ещё."
            ShotResult.SUNK -> message="Корабль потоплен! Ваш ход."
            ShotResult.WIN -> { winner=SoloTurn.PLAYER; message="Победа! Весь флот противника потоплен." }
            ShotResult.ALREADY_SHOT -> message="Эта клетка уже проверена. Выберите другую."
        }
        return result
    }

    fun computerFire(): Pair<Cell, ShotResult>? {
        if(turn != SoloTurn.COMPUTER || winner != null) return null
        val cell=captain.nextShot()
        val result=own.shoot(cell)
        captain.accept(cell,result)
        when(result) {
            ShotResult.MISS -> { turn=SoloTurn.PLAYER; message="Соперник промахнулся. Ваш ход!" }
            ShotResult.HIT -> message="Ваш корабль подбит. Соперник стреляет ещё…"
            ShotResult.SUNK -> message="Ваш корабль потоплен. Соперник стреляет ещё…"
            ShotResult.WIN -> { winner=SoloTurn.COMPUTER; message="Ваш флот потоплен. Попробуем ещё раз?" }
            ShotResult.ALREADY_SHOT -> error("Captain repeated a shot")
        }
        return cell to result
    }
}
