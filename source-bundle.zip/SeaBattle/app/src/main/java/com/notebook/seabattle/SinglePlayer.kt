package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable fun SinglePlayerGame(onBack: () -> Unit) {
    var match by remember { mutableStateOf(SoloMatch()) }
    var revision by remember { mutableIntStateOf(0) }
    var arranging by remember { mutableStateOf(false) }
    var showOwn by remember { mutableStateOf(false) }
    BackHandler { if(arranging) arranging=false else onBack() }
    if(arranging) {
        FleetPlacement(onBack={arranging=false},onReady={match=SoloMatch(own=it);revision++;arranging=false})
        return
    }
    // Exactly one delayed AI shot per turn/revision. Leaving the screen cancels it.
    LaunchedEffect(match, revision) {
        if(match.turn == SoloTurn.COMPUTER && match.winner == null) {
            delay(650)
            match.computerFire()
            revision++
        }
    }
    Column(Modifier.fillMaxSize().background(Color(0xFFFFFCF0))
        .verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            TextButton(onClick=onBack) { Text("‹ Меню") }
            Text("ОДИНОЧНАЯ ИГРА",style=MaterialTheme.typography.titleMedium)
        }
        Text(match.message,style=MaterialTheme.typography.titleMedium)
        Text("Флот противника · ${match.opponent.ships.count { s -> s.cells.all { it in match.opponent.shots } }}/10 потоплено",
            style=MaterialTheme.typography.bodySmall)
        NotebookGrid(emptyList(),match.opponent.shots.associateWith { match.opponent.occupied(it) },
            match.turn==SoloTurn.PLAYER && match.winner==null) { cell ->
            if(match.playerFire(cell) != null) revision++
        }
        if(match.turn==SoloTurn.COMPUTER && match.winner==null) LinearProgressIndicator(Modifier.fillMaxWidth())
        OutlinedButton(onClick={showOwn=!showOwn},modifier=Modifier.fillMaxWidth()) {
            Text("${if(showOwn) "Скрыть" else "Мой флот"} · ${match.own.ships.count { s -> s.cells.any { it !in match.own.shots } }}/10 на плаву")
        }
        if(showOwn || match.winner!=null) NotebookGrid(match.own.ships.map { it.cells },
            match.own.shots.associateWith { match.own.occupied(it) },false) { }
        if(match.winner!=null) Button(onClick={match=SoloMatch();revision++},modifier=Modifier.fillMaxWidth()) { Text("Сыграть ещё") }
        else TextButton(onClick={arranging=true}) { Text("Расставить корабли самому") }
    }
}
