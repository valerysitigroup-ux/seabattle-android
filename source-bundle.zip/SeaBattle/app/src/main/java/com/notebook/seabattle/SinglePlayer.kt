package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable fun SinglePlayerGame(onBack: () -> Unit) {
    var match by remember { mutableStateOf(SoloMatch()) }
    var revision by remember { mutableIntStateOf(0) }
    var arranging by remember { mutableStateOf(true) }
    BackHandler(onBack=onBack)
    if(arranging) {
        FleetPlacement(onBack=onBack,onReady={match=SoloMatch(own=it);revision++;arranging=false})
        return
    }
    // Exactly one delayed AI shot per turn/revision. Leaving the screen cancels it.
    LaunchedEffect(match, revision) {
        if(match.turn == SoloTurn.COMPUTER && match.winner == null) {
            delay(650)
            match.computerFire()
            revision++
        }
    }
    val ownView=remember(match,revision) { match.own.battleView(true) }
    val enemyView=remember(match,revision) { match.opponent.battleView(false) }
    key(match) {
        BattleScreen("С КОМПЬЮТЕРОМ",match.message,ownView,enemyView,
            match.turn==SoloTurn.PLAYER && match.winner==null,onBack,
            onShot={ cell -> if(cell !in enemyView.blocked && match.playerFire(cell) != null) revision++ },
            actions={
                TextButton(onClick={arranging=true}) { Text(if(match.winner!=null) "Ещё раз" else "Новая") }
                if(match.winner==null) TextButton(onClick={arranging=true}) { Text("Флот") }
            })
    }
}

