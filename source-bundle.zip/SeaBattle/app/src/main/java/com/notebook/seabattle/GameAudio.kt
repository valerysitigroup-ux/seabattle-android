package com.notebook.seabattle

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.runtime.*
import java.util.concurrent.ConcurrentHashMap

val LocalGameAudio=staticCompositionLocalOf<GameAudio?> { null }

class GameAudio(context:Context) {
    private var soundEnabled by mutableStateOf(true)
    var enabled:Boolean
        get()=soundEnabled
        set(value){soundEnabled=value;if(!value){stopEffects();stopSea();stopAmbientStream()}else syncAmbience()}
    private val loaded=ConcurrentHashMap.newKeySet<Int>()
    private val pool=SoundPool.Builder().setMaxStreams(12).setAudioAttributes(AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private val hit:Int;private val sunk:Int;private val sea:Int;private val win:Int;private val loss:Int;private val miss:Int
    private val ambience:Int;private val cannon:Int;private val flyby:Int;private val fireworks:Int
    private var seaStream=0;private var ambientStream=0
    private var ambienceRequested=false;private var foreground=true
    @Volatile private var released=false
    private val effects=ArrayDeque<Int>()
    internal val ambientPlaying get()=ambientStream!=0&&!released&&foreground&&enabled
    init {
        pool.setOnLoadCompleteListener { _,id,status -> if(status==0&&!released){loaded.add(id);syncAmbience()} }
        hit=pool.load(context,R.raw.hit_explosion,1);sunk=pool.load(context,R.raw.sunk_explosion,1)
        sea=pool.load(context,R.raw.sea_wash,1);win=pool.load(context,R.raw.pirate_victory,1)
        loss=pool.load(context,R.raw.sad_pirate_v23,1);miss=pool.load(context,R.raw.water_miss,1)
        ambience=pool.load(context,R.raw.real_sea_gulls_v23,1);cannon=pool.load(context,R.raw.cannon_launch,1);flyby=pool.load(context,R.raw.cannon_whistle,1);fireworks=pool.load(context,R.raw.firework_real_v23,1)
    }
    private fun play(id:Int,volume:Float=.8f,priority:Int=1) {
        if(released||!enabled||!foreground||id !in loaded)return
        val stream=pool.play(id,volume,volume,priority,0,1f)
        if(stream!=0){effects.addLast(stream);if(effects.size>32)effects.removeFirst()}
    }
    fun impact(shipSunk:Boolean)=play(if(shipSunk)sunk else hit)
    fun splash()=play(miss)
    fun cannonShot()=play(cannon,.65f)
    fun whistle()=play(flyby,.58f)
    fun firework()=play(fireworks,.72f,2)
    fun victory(){stopSea();play(win,1f,2)}
    fun defeat(){stopSea();play(loss,.85f,2)}
    fun stopFinaleEffects()=stopEffects()
    fun startAmbience(){ambienceRequested=true;syncAmbience()}
    fun stopAmbience(){ambienceRequested=false;stopAmbientStream()}
    private fun syncAmbience(){
        if(released||!ambienceRequested||!foreground||!enabled||ambience !in loaded||ambientStream!=0)return
        ambientStream=pool.play(ambience,.11f,.11f,0,-1,1f)
    }
    private fun stopAmbientStream(){if(ambientStream!=0&&!released)pool.stop(ambientStream);ambientStream=0}
    private fun stopEffects(){if(!released)effects.forEach {pool.stop(it)};effects.clear()}
    fun pause(){foreground=false;stopEffects();stopSea();stopAmbientStream()}
    fun resume(){foreground=true;syncAmbience()}
    fun sea(){if(!released&&enabled&&foreground&&sea in loaded){stopSea();seaStream=pool.play(sea,.25f,.25f,0,0,1f)}}
    fun stopSea(){if(seaStream!=0&&!released)pool.stop(seaStream);seaStream=0}
    fun release(){if(released)return;pause();ambienceRequested=false;released=true;loaded.clear();pool.release()}
}
