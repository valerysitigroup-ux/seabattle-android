package com.notebook.seabattle

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.runtime.*
import java.util.concurrent.ConcurrentHashMap

val LocalGameAudio=staticCompositionLocalOf<GameAudio?> { null }
enum class GameSound(val key:String,val title:String) {
    SEA("sea","Море"),GULLS("gulls","Чайки"),CANNON("cannon","Выстрел"),HIT("hit","Попадание в корабль"),
    SPLASH("splash","Всплеск воды"),SINKING("sinking","Затопление корабля"),
    VICTORY("victory","Победная музыка"),DEFEAT("defeat","Грустная музыка"),FIREWORKS("fireworks","Салют")
}
class GameAudio(context:Context) {
    private val prefs=context.applicationContext.getSharedPreferences("sea-audio",Context.MODE_PRIVATE)
    private var soundEnabled by mutableStateOf(prefs.getBoolean("enabled",true))
    private val levels=mutableStateMapOf<GameSound,Float>().apply {
        GameSound.entries.forEach {put(it,prefs.getFloat("level-${it.key}",1f).coerceIn(0f,1f))}
    }
    fun level(sound:GameSound)=levels.getValue(sound)
    fun updateLevel(sound:GameSound,value:Float) {
        if(!value.isFinite())return
        levels[sound]=value.coerceIn(0f,1f);prefs.edit().putFloat("level-${sound.key}",level(sound)).apply()
        if(released)return
        fun adjust(id:Int,gain:Float,type:GameSound){if(id!=0){val v=gain*level(type);pool.setVolume(id,v,v)}}
        adjust(ambientStream,.055f,GameSound.SEA);adjust(gullStream,.09f/4f,GameSound.GULLS);adjust(seaStream,.25f,GameSound.SEA)
        effects.forEach {adjust(it.id,it.gain,it.sound)}
    }
    var gullsEnabled by mutableStateOf(prefs.getBoolean("gulls",true))
        private set
    fun setGulls(value:Boolean){gullsEnabled=value;prefs.edit().putBoolean("gulls",value).apply();if(!value)stopGullStream()else syncAmbience()}
    var enabled:Boolean
        get()=soundEnabled
        set(value){soundEnabled=value;prefs.edit().putBoolean("enabled",value).apply();if(!value){stopEffects();stopSea();stopAmbientStream()}else syncAmbience()}
    private val loaded=ConcurrentHashMap.newKeySet<Int>()
    private val pool=SoundPool.Builder().setMaxStreams(12).setAudioAttributes(AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private val hit:Int;private val sea:Int;private val win:Int;private val loss:Int;private val miss:Int
    private val ambience:Int;private val ocean:Int;private val cannon:Int;private val fireworks:Int;private val sinking:Int
    private var seaStream=0;private var ambientStream=0;private var gullStream=0
    private var ambienceRequested=false;private var foreground=true
    @Volatile private var released=false
    private data class Effect(val id:Int,val gain:Float,val sound:GameSound)
    private val effects=ArrayDeque<Effect>()
    internal val ambientPlaying get()=ambientStream!=0&&!released&&foreground&&enabled
    internal val gullsPlaying get()=gullStream!=0&&!released&&foreground&&enabled&&gullsEnabled
    init {
        pool.setOnLoadCompleteListener { _,id,status -> if(status==0&&!released){loaded.add(id);syncAmbience()} }
        hit=pool.load(context,R.raw.hit_real_v24,1)
        sea=pool.load(context,R.raw.sea_wash,1);win=pool.load(context,R.raw.pirate_victory,1)
        loss=pool.load(context,R.raw.sad_pirate_v23,1);miss=pool.load(context,R.raw.water_miss,1)
        ocean=pool.load(context,R.raw.sea_ambient_v26,1)
        ambience=pool.load(context,R.raw.real_sea_gulls_v23,1);cannon=pool.load(context,R.raw.cannon_launch,1);fireworks=pool.load(context,R.raw.firework_real_v23,1)
        sinking=pool.load(context,R.raw.ship_sinking_v24,1)
    }
    private fun play(id:Int,sound:GameSound,volume:Float=.8f,priority:Int=1) {
        if(released||!enabled||!foreground||id !in loaded)return
        val v=volume*level(sound);val stream=pool.play(id,v,v,priority,0,1f)
        if(stream!=0){effects.addLast(Effect(stream,volume,sound));if(effects.size>32)effects.removeFirst()}
    }
    fun impact(shipSunk:Boolean)=play(hit,GameSound.HIT)
    fun splash()=play(miss,GameSound.SPLASH)
    fun cannonShot()=play(cannon,GameSound.CANNON,.65f/3f)
    fun shipSinking()=play(sinking,GameSound.SINKING,.72f,2)
    fun firework()=play(fireworks,GameSound.FIREWORKS,.72f,2)
    fun victory(){stopSea();play(win,GameSound.VICTORY,1f,2)}
    fun defeat(){stopSea();play(loss,GameSound.DEFEAT,.85f,2)}
    fun stopFinaleEffects()=stopEffects()
    fun startAmbience(){ambienceRequested=true;syncAmbience()}
    fun stopAmbience(){ambienceRequested=false;stopAmbientStream()}
    private fun syncAmbience(){
        if(released||!ambienceRequested||!foreground||!enabled)return
        if(ocean in loaded&&ambientStream==0){val v=.055f*level(GameSound.SEA);ambientStream=pool.play(ocean,v,v,0,-1,1f)}
        if(gullsEnabled&&ambience in loaded&&gullStream==0){val v=.09f/4f*level(GameSound.GULLS);gullStream=pool.play(ambience,v,v,0,-1,1f)}
    }
    private fun stopGullStream(){if(gullStream!=0&&!released)pool.stop(gullStream);gullStream=0}
    private fun stopAmbientStream(){if(ambientStream!=0&&!released)pool.stop(ambientStream);ambientStream=0;stopGullStream()}
    private fun stopEffects(){if(!released)effects.forEach {pool.stop(it.id)};effects.clear()}
    fun pause(){foreground=false;stopEffects();stopSea();stopAmbientStream()}
    fun resume(){foreground=true;syncAmbience()}
    fun sea(){if(!released&&enabled&&foreground&&sea in loaded){stopSea();val v=.25f*level(GameSound.SEA);seaStream=pool.play(sea,v,v,0,0,1f)}}
    fun stopSea(){if(seaStream!=0&&!released)pool.stop(seaStream);seaStream=0}
    fun release(){if(released)return;pause();ambienceRequested=false;released=true;loaded.clear();pool.release()}
}
