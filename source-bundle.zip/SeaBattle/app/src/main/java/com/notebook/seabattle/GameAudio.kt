package com.notebook.seabattle

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.runtime.*
import java.util.concurrent.ConcurrentHashMap

val LocalGameAudio=staticCompositionLocalOf<GameAudio?> { null }

class GameAudio(context:Context) {
    var enabled by mutableStateOf(true)
    private val loaded=ConcurrentHashMap.newKeySet<Int>()
    private val pool=SoundPool.Builder().setMaxStreams(4).setAudioAttributes(AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private val hit:Int
    private val sunk:Int
    private var foreground=true
    init {
        pool.setOnLoadCompleteListener { _,id,status -> if(status==0) loaded.add(id) }
        hit=pool.load(context,R.raw.hit_explosion,1)
        sunk=pool.load(context,R.raw.sunk_explosion,1)
    }
    fun impact(shipSunk:Boolean) {
        val id=if(shipSunk) sunk else hit
        if(enabled && foreground && id in loaded) pool.play(id,.8f,.8f,1,0,1f)
    }
    fun pause() { foreground=false;pool.autoPause() }
    fun resume() { foreground=true }
    fun release() { loaded.clear(); pool.release() }
}
