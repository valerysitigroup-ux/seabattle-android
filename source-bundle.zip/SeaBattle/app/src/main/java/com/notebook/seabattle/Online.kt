package com.notebook.seabattle

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp

@Composable fun OnlineGame(onBack:()->Unit,onSolo:()->Unit=onBack,onGameFinished:()->Unit=onBack) {
    val context=LocalContext.current.applicationContext
    val factory=LocalOnlineFactory.current
    var attempt by remember {mutableIntStateOf(0)}
    val session=remember(context,attempt,factory){factory(context)}
    DisposableEffect(session){onDispose{session.close()}}
    LaunchedEffect(session){session.start()}
    BackHandler {if(session.phase==OnlinePhase.MANUAL)session.choice() else onBack()}
    if(session.phase==OnlinePhase.CHOICE||session.phase==OnlinePhase.MANUAL){
        key(session.room){FleetPlacement(onBack={session.leave()},onReady={session.ready(it)},subtitle="Соперник: "+session.opponent)}
        return
    }
    if(session.phase==OnlinePhase.BATTLE){
        key(session.room){BattleScreen("С ДРУГОМ",session.info,
            BattleView(session.board?.ships?.map{it.cells} ?: emptyList(),session.state.ownShots,session.state.ownSunk),
            BattleView(session.state.enemySunk,session.state.enemyShots,session.state.enemySunk,setOfNotNull(session.state.pending)),
            session.state.canShoot,onBack,onMatchFinished={session.leave();onGameFinished()},onShot={session.shoot(it)},activeTurn=if(session.state.finished)null else if(session.state.turn==session.state.player)BattleTurn.PLAYER else BattleTurn.OPPONENT,actions={TextButton(onClick={session.leave()}){Text("В лобби")}})}
        return
    }
    OceanScene {
    Row(Modifier.fillMaxSize().padding(12.dp),horizontalArrangement=Arrangement.spacedBy(20.dp)) {
        Column(Modifier.width(180.dp).fillMaxHeight().burntPaper().padding(8.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.height(36.dp))
            Text("ИГРА С ДРУГОМ",style=MaterialTheme.typography.titleMedium)
            SoundButton()
            Text(session.info,style=MaterialTheme.typography.bodySmall)
            when(session.phase){
                OnlinePhase.LOBBY->{
                    var editName by remember(session.name){mutableStateOf(session.name)}
                    OutlinedTextField(editName,{editName=it.take(24)},label={Text("Ваше имя")},singleLine=true,enabled=session.invitation==null)
                    TextButton(onClick={session.rename(editName)},enabled=session.invitation==null&&editName.isNotBlank()){Text("Сохранить имя")}
                }
                OnlinePhase.ERROR->{OutlinedButton(onClick={attempt++}){Text("Подключиться снова")};TextButton(onClick=onSolo){Text("С компьютером")}}
                OnlinePhase.WAITING->{CircularProgressIndicator();TextButton(onClick={session.leave()}){Text("Отменить матч")}}
                else->CircularProgressIndicator()
            }
        }
        Box(Modifier.weight(1f).fillMaxHeight(),contentAlignment=Alignment.Center) {
            when(session.phase){
                OnlinePhase.LOBBY->Column(Modifier.fillMaxSize().burntPaper().padding(12.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text("ИГРОКИ ОНЛАЙН",style=MaterialTheme.typography.titleLarge,modifier=Modifier.testTag("online-lobby"))
                    Text("Здесь игроки, которые открыли интернет-режим.",style=MaterialTheme.typography.bodySmall)
                    if(session.players.isEmpty())Text("Пока никого нет. Попросите друга открыть игру по интернету.")
                    session.players.forEach {p->Parchment(Modifier.fillMaxWidth()){
                        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f)){Text(p.name);Text("#${p.id.takeLast(4)} · ${if(p.status=="available")"Готов играть" else "Занят"}",style=MaterialTheme.typography.bodySmall)}
                            OutlinedButton(onClick={session.invite(p)},enabled=p.status=="available"&&session.invitation==null,modifier=Modifier.testTag("invite-${p.id}")){Text("Пригласить")}
                        }
                    }}
                }
                OnlinePhase.CHOICE->session.variants.getOrNull(session.selectedVariant)?.let {FleetPreview(BattleView(it.ships.map {s->s.cells}),Modifier.fillMaxSize())}
                OnlinePhase.WAITING->FleetPreview(BattleView(session.board?.ships?.map{it.cells} ?: emptyList()),Modifier.fillMaxSize())
                else->Parchment {Text(if(session.phase==OnlinePhase.CONNECTING)"Ищем игроков в море…" else "Можно попробовать ещё раз",Modifier.padding(18.dp),style=MaterialTheme.typography.titleLarge)}
            }
        }
    }
    }
    // Outside scrolling panels so the flag remains in the screen corner.
    // OceanScene above is finished; retain a small independent overlay here.
    Box(Modifier.fillMaxSize()) {PirateBackButton(onClick=onBack,modifier=Modifier.align(Alignment.TopStart).padding(4.dp))}
    session.invitation?.let {inv->androidx.compose.ui.window.Dialog(onDismissRequest={session.cancelInvite()}) {
        Parchment(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text(if(inv.incoming)"Приглашение в игру" else "Приглашение отправлено",style=MaterialTheme.typography.headlineSmall)
                Text(inv.player.name+" #"+inv.player.id.takeLast(4))
                Text(if(inv.incoming)"Приглашает вас сыграть. После принятия расставьте корабли." else "Ожидаем ответа. Друг должен принять приглашение.")
                Row {
                    if(inv.incoming)TextButton(onClick={session.answer(true)}){Text("Принять")}
                    TextButton(onClick={if(inv.incoming)session.answer(false) else session.cancelInvite()}){Text(if(inv.incoming)"Отклонить" else "Отменить")}
                }
            }
        }
    }}
}
