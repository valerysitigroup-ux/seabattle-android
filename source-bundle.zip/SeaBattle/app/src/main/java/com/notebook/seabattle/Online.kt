package com.notebook.seabattle

import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable fun OnlineGame(onBack: () -> Unit, onSolo: () -> Unit = onBack) {
    var fleet by remember { mutableStateOf<Board?>(Board.random()) }
    if (fleet == null) {
        FleetPlacement(onBack = onBack, onReady = { fleet = it })
        return
    }
    val board = requireNotNull(fleet)
    var serviceUrl by remember { mutableStateOf("") }
    var checking by remember { mutableStateOf(true) }
    var directoryAttempt by remember { mutableIntStateOf(0) }
    var joinCode by remember { mutableStateOf("") }
    var room by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("Готовим игру…") }
    var state by remember { mutableStateOf(OnlineState()) }
    var sendingFleet by remember { mutableStateOf(false) }
    var connecting by remember { mutableStateOf(false) }
    var socket by remember { mutableStateOf<WebSocket?>(null) }
    val ui = remember { Handler(Looper.getMainLooper()) }
    val client = remember { OkHttpClient.Builder().connectTimeout(8,TimeUnit.SECONDS).readTimeout(8,TimeUnit.SECONDS).pingInterval(20, TimeUnit.SECONDS).build() }
    fun disconnect() {
        val old = socket
        socket = null
        old?.close(1000, "exit")
        connecting = false; room = ""; sendingFleet = false; state = OnlineState()
    }
    DisposableEffect(client) {
        onDispose {
            val old = socket; socket = null
            old?.close(1000, "exit")
            client.connectionPool.evictAll()
            client.dispatcher.executorService.shutdown()
        }
    }
    LaunchedEffect(client,directoryAttempt) {
        checking=true
        serviceUrl=withContext(Dispatchers.IO) {
            ServerDirectory.usable(BuildConfig.MATCH_SERVER_URL) ?: runCatching {
                client.newCall(Request.Builder().url(BuildConfig.SERVER_DIRECTORY).build()).execute().use { response ->
                    if(response.isSuccessful) ServerDirectory.usable(JSONObject(response.body?.string() ?: "{}").optString("serverUrl")) else null
                }
            }.getOrNull()
        } ?: ""
        checking=false
        info=if(serviceUrl.isEmpty()) "Игра с другом пока недоступна. Можно сыграть с компьютером." else "Выберите соперника — флот уже готов."
    }
    BackHandler { onBack() }
    fun send(message: JSONObject): Boolean = socket?.send(message.toString()) == true
    fun connect(mode: String) {
        val address=ServerDirectory.usable(serviceUrl) ?: return
        val request = try { Request.Builder().url(address).build() }
        catch (_: IllegalArgumentException) { info = "Не удалось начать игру. Попробуйте позже."; return }
        val code = joinCode
        disconnect(); connecting = true; info = "Подключение…"
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                ui.post {
                    if (ws !== socket) return@post
                    connecting = false
                    val command = JSONObject().put("type", mode)
                    if (mode=="join") command.put("room", code)
                    if (!ws.send(command.toString())) { disconnect(); info = "Не удалось отправить запрос комнаты" }
                }
            }
            override fun onMessage(ws: WebSocket, text: String) {
                ui.post {
                    if (ws !== socket) return@post
                    try {
                        val j = JSONObject(text)
                        when (j.getString("type")) {
                            "state" -> {
                                val ready = j.getJSONArray("ready")
                                state = state.snapshot(OnlineState(
                                    player = j.getInt("player"), turn = j.getInt("turn"),
                                    accepted = listOf(ready.getBoolean(0), ready.getBoolean(1)),
                                    finished = j.getBoolean("finished"),
                                    ownShots = parseShots(j.getJSONArray("ownShots")),
                                    enemyShots = parseShots(j.getJSONArray("enemyShots"))
                                ))
                                room = j.getString("room")
                                if (state.fleetAccepted) sendingFleet = false
                                else if(!sendingFleet) {
                                    if(ws.send(JSONObject().put("type","fleet").put("ships",fleetJson(board)).toString())) sendingFleet=true
                                    else {disconnect();info="Не удалось начать игру. Попробуйте ещё раз.";return@post}
                                }
                                info = when {
                                    state.finished -> if (state.enemyShots.values.count { it } == 20) "Вы победили!" else "Соперник победил"
                                    !state.fleetAccepted -> "Готовим ваш флот…"
                                    !state.accepted.all { it } -> "Ждём соперника…"
                                    state.turn == state.player -> "Ваш ход"
                                    else -> "Ход соперника"
                                }
                            }
                            "closed" -> { disconnect(); info = "Соперник вышел. Начнём новую партию?" }
                            "error" -> {
                                state = state.copy(pending = null); sendingFleet = false
                                info = "Не удалось продолжить партию. Попробуйте ещё раз."
                                if (room.isEmpty()) disconnect()
                            }
                        }
                    } catch (_: Exception) {
                        disconnect(); info = "Связь прервалась. Попробуйте начать новую партию."
                    }
                }
            }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                ui.post { if (ws === socket) { disconnect(); info = "Соединение потеряно. Создайте новую партию" } }
            }
            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                ws.close(code, reason)
                ui.post { if (ws === socket) { disconnect(); info = "Соединение закрыто. Создайте новую партию" } }
            }
            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                ui.post { if (ws === socket) { disconnect(); info = "Соединение закрыто" } }
            }
        })
    }
    Column(Modifier.fillMaxSize().background(Color(0xFFFFFCF0)).verticalScroll(rememberScrollState()).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("ИГРА С ДРУГОМ", style = MaterialTheme.typography.titleLarge)
        Text(info)
        if(checking) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (socket == null && !checking) {
            if(serviceUrl.isNotEmpty()) {
                Button(onClick={connect("match")},modifier=Modifier.fillMaxWidth()) {Text("Найти соперника")}
                OutlinedButton(onClick={connect("create")},modifier=Modifier.fillMaxWidth()) {Text("Пригласить друга")}
                OutlinedTextField(joinCode,{joinCode=it.filter {c->c in '0'..'9'}.take(6)},label={Text("Код приглашения")},singleLine=true)
                Button(onClick={connect("join")},enabled=joinCode.length==6) {Text("Присоединиться")}
                TextButton(onClick={fleet=null}) {Text("Расставить корабли самому")}
            } else {
                Button(onClick=onSolo,modifier=Modifier.fillMaxWidth()) {Text("Сыграть с компьютером")}
                TextButton(onClick={directoryAttempt++;info="Проверяем доступность…"}) {Text("Попробовать ещё раз")}
            }
        } else if(socket!=null) {
            if(room.isNotEmpty()) Text("Код приглашения: $room")
            OutlinedButton(onClick={disconnect();info="Можно начать новую партию"}) {
                Text(if(connecting) "Отменить" else "Выйти из партии")
            }
        }
        Text("Ваши корабли")
        NotebookGrid(board.ships.map { it.cells }, state.ownShots, false) { }
        if (room.isNotEmpty()) {
            Text("Поле соперника")
            NotebookGrid(emptyList(), state.enemyShots, state.canShoot,
                pending = setOfNotNull(state.pending)) { cell ->
                if (state.canShoot && cell !in state.enemyShots) {
                    state = state.fire(cell)
                    if (!send(JSONObject().put("type", "shot").put("x", cell.x).put("y", cell.y))) {
                        disconnect(); info = "Не удалось отправить выстрел. Соединение закрыто"
                    }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Назад") }
    }
}

internal fun fleetJson(board: Board): JSONArray = JSONArray().apply {
    board.ships.forEach { ship -> put(JSONArray().apply {
        ship.cells.sortedWith(compareBy<Cell> { it.y }.thenBy { it.x }).forEach { put(JSONArray().put(it.x).put(it.y)) }
    }) }
}

private fun parseShots(a: JSONArray): Map<Cell, Boolean> = buildMap {
    for (i in 0 until a.length()) {
        val o = a.getJSONObject(i); val c = Cell(o.getInt("x"), o.getInt("y"))
        require(c.x in 0..9 && c.y in 0..9)
        put(c, o.getBoolean("hit"))
    }
}
