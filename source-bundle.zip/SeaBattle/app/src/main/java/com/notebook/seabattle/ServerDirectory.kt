package com.notebook.seabattle

import java.net.URI

object ServerDirectory {
    /** An invalid or unpublished directory never exposes setup fields to players. */
    fun usable(value:String):String? = runCatching {
        val url=URI(value.trim())
        if(url.scheme!="wss" || url.host.isNullOrBlank() || url.userInfo!=null || url.fragment!=null) null
        else url.toASCIIString()
    }.getOrNull()
}
