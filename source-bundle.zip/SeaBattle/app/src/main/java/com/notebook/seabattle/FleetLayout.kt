package com.notebook.seabattle

import kotlin.math.abs

data class FleetLayout(val ships:List<Set<Cell>> = emptyList()) {
    fun shipAt(cell:Cell)=ships.indexOfFirst {cell in it}
    fun canReplace(index:Int,candidate:Set<Cell>):Boolean = candidate.isNotEmpty() && candidate.all {it.x in 0..9&&it.y in 0..9} && ships.withIndex().filter {it.index!=index}.none {(_,old)->old.any {a->candidate.any {b->abs(a.x-b.x)<=1&&abs(a.y-b.y)<=1}}}
    fun replace(index:Int,candidate:Set<Cell>):FleetLayout? = if(index in ships.indices&&candidate.size==ships[index].size&&canReplace(index,candidate))copy(ships=ships.mapIndexed {i,s->if(i==index)candidate else s}) else null
    fun move(index:Int,dx:Int,dy:Int):FleetLayout? = ships.getOrNull(index)?.let {replace(index,it.map {c->Cell(c.x+dx,c.y+dy)}.toSet())}
    fun rotate(index:Int):FleetLayout? {
        val ship=ships.getOrNull(index) ?: return null
        val vertical=ship.map {it.x}.distinct().size==1&&ship.size>1
        val x=ship.minOf {it.x}.coerceAtMost(if(vertical)10-ship.size else 9)
        val y=ship.minOf {it.y}.coerceAtMost(if(vertical)9 else 10-ship.size)
        return replace(index,(0 until ship.size).map {Cell(x+if(vertical)it else 0,y+if(vertical)0 else it)}.toSet())
    }
    fun place(cell:Cell,horizontal:Boolean):FleetLayout? {
        val n=Board.fleetLengths.firstOrNull {length->ships.count {it.size==length}<Board.fleetLengths.count {it==length}} ?: return null
        return add(n,cell,horizontal)
    }
    fun remaining(length:Int)=Board.fleetLengths.count {it==length}-ships.count {it.size==length}
    /** Place the tapped reserve type without moving the fleet already arranged by the player. */
    fun placeAvailable(length:Int):FleetLayout? {
        if(remaining(length)<=0)return null
        for(horizontal in listOf(true,false))for(y in 0..9)for(x in 0..9) {
            add(length,Cell(x,y),horizontal)?.let {return it}
        }
        return null
    }
    fun add(length:Int,cell:Cell,horizontal:Boolean=true):FleetLayout? {
        if(remaining(length)<=0)return null
        val candidate=(0 until length).map {Cell(cell.x+if(horizontal)it else 0,cell.y+if(horizontal)0 else it)}.toSet()
        return if(canReplace(-1,candidate))copy(ships=ships+listOf(candidate)) else null
    }
    fun remove(index:Int)=if(index in ships.indices)copy(ships=ships.filterIndexed {i,_->i!=index}) else this
    fun shuffled():FleetLayout {
        var next:FleetLayout
        do {next=FleetLayout(Board.random().ships.map {it.cells})} while(next.ships==ships)
        return next
    }
}
