package com.notebook.seabattle

import androidx.activity.compose.BackHandler

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable fun SeaEntrance(onBack:()->Unit,content:@Composable ()->Unit) {
    var done by remember { mutableStateOf(false) }
    val audio=LocalGameAudio.current
    LaunchedEffect(Unit) { audio?.sea();delay(2200);done=true }
    DisposableEffect(Unit) { onDispose { audio?.stopSea() } }
    if(done) {content();return}
    BackHandler(onBack=onBack)
    val transition=rememberInfiniteTransition(label="sea")
    val phase by transition.animateFloat(0f,1f,infiniteRepeatable(tween(2500,easing=LinearEasing)),label="waves")
    OceanScene {
    Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            repeat(7) { row ->
                val path=Path()
                for(i in 0..100) {
                    val x=size.width*i/100f
                    val y=size.height*(.24f+row*.1f)+sin(i*.14f+phase*2*PI.toFloat()+row)*12.dp.toPx()
                    if(i==0)path.moveTo(x,y) else path.lineTo(x,y)
                }
                drawPath(path,Color(0xFF328F91).copy(alpha=.35f),style=Stroke(2.dp.toPx(),cap=StrokeCap.Round))
            }
        }
        Parchment {Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Море зовёт…",style=MaterialTheme.typography.headlineMedium)
            Text("Готовимся к игре с другом")
            TextButton(onClick=onBack) { Text("Назад") }
        }}
    }
    }
}

