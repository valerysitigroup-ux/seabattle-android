package com.notebook.seabattle

import androidx.activity.compose.BackHandler

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable fun SeaEntrance(onBack:()->Unit,content:@Composable ()->Unit) {
    var done by remember { mutableStateOf(false) }
    val audio=LocalGameAudio.current
    LaunchedEffect(Unit) { audio?.sea();delay(2200);done=true }
    DisposableEffect(Unit) { onDispose { audio?.stopSea() } }
    if(done) {content();return}
    BackHandler(onBack=onBack)
    val transition=rememberInfiniteTransition(label="sea")
    val phase by transition.animateFloat(0f,1f,infiniteRepeatable(tween(2500,easing=LinearEasing)),label="waves")
    Box(Modifier.fillMaxSize().background(NotebookPaper),contentAlignment=Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            repeat(7) { row ->
                val path=Path()
                for(i in 0..100) {
                    val x=size.width*i/100f
                    val y=size.height*(.24f+row*.1f)+sin(i*.14f+phase*2*PI.toFloat()+row)*12.dp.toPx()
                    if(i==0)path.moveTo(x,y) else path.lineTo(x,y)
                }
                drawPath(path,Color(0xFF328F91).copy(alpha=.35f),style=Stroke(2.dp.toPx(),cap=StrokeCap.Round))
            }
        }
        Column(Modifier.background(NotebookPaper.copy(alpha=.9f)).padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Море зовёт…",style=MaterialTheme.typography.headlineMedium)
            Text("Готовимся к игре с другом")
            TextButton(onClick=onBack) { Text("Назад") }
        }
    }
}

/** Runs once for a new match, independently from turns and incoming snapshots. */
@Composable fun MatchGreeting(enabled:Boolean=true,onStarted:()->Unit={}) {
    val audio=LocalGameAudio.current
    var stage by remember { mutableIntStateOf(if(enabled)0 else 3) }
    val burst=remember { Animatable(0f) }
    val flight=remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if(!enabled)return@LaunchedEffect
        onStarted();delay(10_000);stage=1;audio?.impact(false)
        burst.animateTo(1f,tween(650,easing=LinearEasing));stage=2
        flight.animateTo(1f,tween(1600,easing=LinearEasing));stage=3
    }
    Box(Modifier.fillMaxWidth().height(48.dp),contentAlignment=Alignment.Center) {
        when(stage) {
            0 -> Text("Чувак дай в долг)))",Modifier.testTag("match-greeting"),fontSize=22.sp,color=GreenInk)
            1 -> Canvas(Modifier.fillMaxSize().testTag("greeting-explosion")) {
                val p=burst.value;val center=Offset(size.width/2,size.height/2)
                drawCircle(Color(0xFFFF9C29).copy(alpha=1-p),18.dp.toPx()*(1+p),center)
                repeat(18) { i ->
                    val a=i*PI.toFloat()/9;val d=Offset(cos(a),sin(a))
                    drawLine(Color(0xFFE1731E).copy(alpha=1-p),center+d*(p*85.dp.toPx()),center+d*((p*85+10)*1.dp.toPx()),2.dp.toPx(),StrokeCap.Round)
                }
            }
            2 -> Text("😂",Modifier.testTag("laughing-face").offset {IntOffset(0,(-20.dp.toPx()*flight.value).roundToInt())}
                .alpha(1-flight.value*.7f).semantics {contentDescription="Жёлтый смеющийся смайлик"},fontSize=38.sp)
        }
    }
}
